#[macro_export]
macro_rules! unwrap_or_return {
    ($expr:expr) => {
        match $expr {
            AppFlow::Proceed(val) => val,
            AppFlow::Done => return AppFlow::Done,
            AppFlow::Fail(e) => return AppFlow::Fail(e),
        }
    };
}
