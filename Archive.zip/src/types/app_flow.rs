use std::error::Error;
use std::fmt;

pub enum AppFlow<T> {
    Proceed(T),
    Done,
    Fail(Box<dyn Error + Send + Sync>),
}

impl<T> AppFlow<T> {
    pub fn from_result<E>(res: Result<T, E>) -> Self
    where
    E: Into<Box<dyn Error + Send + Sync>>,
    {
        match res {
            Ok(val) => Self::Proceed(val),
            Err(e) => Self::Fail(e.into()),
        }
    }

    pub fn fail_str<S: Into<String>>(s: S) -> Self {
        Self::Fail(Box::new(AppError::from(s.into())))
    }
}

#[derive(Debug)]
pub struct AppError(String);

impl fmt::Display for AppError {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        write!(f, "{}", self.0)
    }
}

impl Error for AppError {}

impl From<String> for AppError {
    fn from(s: String) -> Self {
        AppError(s)
    }
}

/*
impl From<&str> for AppError {
    fn from(s: &str) -> Self {
        AppError(s.to_string())
    }
}
*/
