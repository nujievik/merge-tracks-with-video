pub(in crate::types::lang_code) static LIST_LANGS: &str = r#"
English language name                         | ISO 639-3 code | ISO 639-2 code | ISO 639-1 code 
----------------------------------------------+----------------+----------------+----------------
'Are'are                                      | alu            |                |                
'Auhelawa                                     | kud            |                |                
A'ou                                          | aou            |                |                
A-Pucikwar                                    | apq            |                |                
Aari                                          | aiw            |                |                
Aasáx                                         | aas            |                |                
Abadi                                         | kbt            |                |                
Abaga                                         | abg            |                |                
Abai Sungai                                   | abf            |                |                
Abanyom                                       | abm            |                |                
Abar                                          | mij            |                |                
Abau                                          | aau            |                |                
Abaza                                         | abq            |                |                
Abellen Ayta                                  | abp            |                |                
Abidji                                        | abi            |                |                
Abinomn                                       | bsa            |                |                
Abipon                                        | axb            |                |                
Abishira                                      | ash            |                |                
Abkhazian                                     | abk            | ab             |                
Abom                                          | aob            |                |                
Abon                                          | abo            |                |                
Abron                                         | abr            |                |                
Abu                                           | ado            |                |                
Abu' Arapesh                                  | aah            |                |                
Abua                                          | abn            |                |                
Abui                                          | abz            |                |                
Abun                                          | kgr            |                |                
Abure                                         | abu            |                |                
Abureni                                       | mgj            |                |                
Abé                                           | aba            |                |                
Acatepec Me'phaa                              | tpx            |                |                
Achagua                                       | aca            |                |                
Achang                                        | acn            |                |                
Ache                                          | yif            |                |                
Acheron                                       | acz            |                |                
Achi                                          | acr            |                |                
Achinese                                      | ace            |                |                
Achterhoeks                                   | act            |                |                
Achuar-Shiwiar                                | acu            |                |                
Achumawi                                      | acv            |                |                
Aché                                          | guq            |                |                
Acoli                                         | ach            |                |                
Acroá                                         | acs            |                |                
Adai                                          | xad            |                |                
Adamawa Fulfulde                              | fub            |                |                
Adamorobe Sign Language                       | ads            |                |                
Adang                                         | adn            |                |                
Adangbe                                       | adq            |                |                
Adangme                                       | ada            |                |                
Adap                                          | adp            |                |                
Adara                                         | kad            |                |                
Adasen                                        | tiu            |                |                
Adele                                         | ade            |                |                
Adhola                                        | adh            |                |                
Adi                                           | adi            |                |                
Adilabad Gondi                                | wsg            |                |                
Adioukrou                                     | adj            |                |                
Adithinngithigh                               | dth            |                |                
Adivasi Oriya                                 | ort            |                |                
Adiwasi Garasia                               | gas            |                |                
Adnyamathanha                                 | adt            |                |                
Adonara                                       | adr            |                |                
Aduge                                         | adu            |                |                
Adyghe                                        | ady            |                |                
Adzera                                        | adz            |                |                
Aeka                                          | aez            |                |                
Aekyom                                        | awi            |                |                
Aequian                                       | xae            |                |                
Aer                                           | aeq            |                |                
Afade                                         | aal            |                |                
Afar                                          | aar            | aa             |                
Afghan Sign Language                          | afg            |                |                
Afitti                                        | aft            |                |                
Afrihili                                      | afh            |                |                
Afrikaans                                     | afr            | af             |                
Afro-Asiatic languages                        | afa            |                |                
Afro-Seminole Creole                          | afs            |                |                
Agarabi                                       | agd            |                |                
Agariya                                       | agi            |                |                
Agatu                                         | agc            |                |                
Agavotaguerra                                 | avo            |                |                
Aghem                                         | agq            |                |                
Aghu Tharnggalu                               | ggr            |                |                
Aghu                                          | ahh            |                |                
Aghu-Tharnggala                               | gtu            |                |                
Aghul                                         | agx            |                |                
Aghwan                                        | xag            |                |                
Agi                                           | aif            |                |                
Agob                                          | kit            |                |                
Agoi                                          | ibm            |                |                
Aguacateco                                    | agu            |                |                
Aguano                                        | aga            |                |                
Aguaruna                                      | agr            |                |                
Aguna                                         | aug            |                |                
Agusan Manobo                                 | msm            |                |                
Agutaynen                                     | agn            |                |                
Agwagwune                                     | yay            |                |                
Ahanta                                        | aha            |                |                
Aheri Gondi                                   | esg            |                |                
Aheu                                          | thm            |                |                
Ahirani                                       | ahr            |                |                
Ahom                                          | aho            |                |                
Ahtena                                        | aht            |                |                
Ahwai                                         | nfd            |                |                
Ai-Cham                                       | aih            |                |                
Aighon                                        | aix            |                |                
Aikanã                                        | tba            |                |                
Aiklep                                        | mwg            |                |                
Aimaq                                         | aiq            |                |                
Aimele                                        | ail            |                |                
Aimol                                         | aim            |                |                
Ainbai                                        | aic            |                |                
Ainu (China)                                  | aib            |                |                
Ainu (Japan)                                  | ain            |                |                
Aiome                                         | aki            |                |                
Airoran                                       | air            |                |                
Aiton                                         | aio            |                |                
Aja (Benin)                                   | ajg            |                |                
Aja (South Sudan)                             | aja            |                |                
Ajawa                                         | ajw            |                |                
Ajië                                          | aji            |                |                
Ajumbu                                        | muc            |                |                
Ajyíninka Apurucayali                         | cpc            |                |                
Ak                                            | akq            |                |                
Aka                                           | soh            |                |                
Aka-Bea                                       | abj            |                |                
Aka-Bo                                        | akm            |                |                
Aka-Cari                                      | aci            |                |                
Aka-Jeru                                      | akj            |                |                
Aka-Kede                                      | akx            |                |                
Aka-Kol                                       | aky            |                |                
Aka-Kora                                      | ack            |                |                
Akan                                          | aka            | ak             |                
Akar-Bale                                     | acl            |                |                
Akaselem                                      | aks            |                |                
Akawaio                                       | ake            |                |                
Ake                                           | aik            |                |                
Akebu                                         | keu            |                |                
Akei                                          | tsr            |                |                
Akeu                                          | aeu            |                |                
Akha                                          | ahk            |                |                
Akhvakh                                       | akv            |                |                
Akkadian                                      | akk            |                |                
Akkala Sami                                   | sia            |                |                
Aklanon                                       | akl            |                |                
Akolet                                        | akt            |                |                
Akoose                                        | bss            |                |                
Akoye                                         | miw            |                |                
Akpa                                          | akf            |                |                
Akpes                                         | ibe            |                |                
Akrukay                                       | afi            |                |                
Akukem                                        | spm            |                |                
Akuku                                         | ayk            |                |                
Akum                                          | aku            |                |                
Akuntsu                                       | aqz            |                |                
Akurio                                        | ako            |                |                
Akwa                                          | akw            |                |                
Akyaung Ari Naga                              | nqy            |                |                
Al-Sayyid Bedouin Sign Language               | syy            |                |                
Alaba-K’abeena                                | alw            |                |                
Alabama                                       | akz            |                |                
Alabat Island Agta                            | dul            |                |                
Alacalufan languages                          | aqa            |                |                
Alacatlatzala Mixtec                          | mim            |                |                
Alago                                         | ala            |                |                
Alagwa                                        | wbj            |                |                
Alak                                          | alk            |                |                
Alamblak                                      | amp            |                |                
Alangan                                       | alj            |                |                
Alanic                                        | xln            |                |                
Alapmunte                                     | apv            |                |                
Alawa                                         | alh            |                |                
Albanian Sign Language                        | sqk            |                |                
Albanian languages                            | sqj            |                |                
Albanian                                      | alb            | sq             | sqi            
Albarradas Sign Language                      | lsc            |                |                
Albay Bicolano                                | bhk            |                |                
Alcozauca Mixtec                              | xta            |                |                
Alege                                         | alf            |                |                
Alekano                                       | gah            |                |                
Aleut                                         | ale            |                |                
Algerian Arabic                               | arq            |                |                
Algerian Jewish Sign Language                 | ajs            |                |                
Algerian Saharan Arabic                       | aao            |                |                
Algerian Sign Language                        | asp            |                |                
Algic languages                               | aql            |                |                
Algonquian languages                          | alg            |                |                
Algonquin                                     | alq            |                |                
Ali                                           | aiy            |                |                
Alladian                                      | ald            |                |                
Allar                                         | all            |                |                
Alngith                                       | aid            |                |                
Alo Phola                                     | ypo            |                |                
Alor                                          | aol            |                |                
Aloápam Zapotec                               | zaq            |                |                
Alsea                                         | aes            |                |                
Altaic languages                              | tut            |                |                
Alu Kurumba                                   | xua            |                |                
Alugu                                         | aub            |                |                
Alumu-Tesu                                    | aab            |                |                
Alune                                         | alp            |                |                
Aluo                                          | yna            |                |                
Alur                                          | alz            |                |                
Alutor                                        | alr            |                |                
Alviri-Vidari                                 | avd            |                |                
Alyawarr                                      | aly            |                |                
Ama (Papua New Guinea)                        | amm            |                |                
Ama (Sudan)                                   | nyi            |                |                
Amahai                                        | amq            |                |                
Amahuaca                                      | amc            |                |                
Amaimon                                       | ali            |                |                
Amal                                          | aad            |                |                
Amami Koniya Sign Language                    | jks            |                |                
Amanab                                        | amn            |                |                
Amanayé                                       | ama            |                |                
Amara                                         | aie            |                |                
Amarakaeri                                    | amr            |                |                
Amarasi                                       | aaz            |                |                
Amatlán Zapotec                               | zpo            |                |                
Amba (Solomon Islands)                        | utp            |                |                
Amba (Uganda)                                 | rwm            |                |                
Ambai                                         | amk            |                |                
Ambakich                                      | aew            |                |                
Ambala Ayta                                   | abc            |                |                
Ambelau                                       | amv            |                |                
Ambele                                        | ael            |                |                
Amblong                                       | alm            |                |                
Ambo                                          | amb            |                |                
Ambo-Pasco Quechua                            | qva            |                |                
Ambonese Malay                                | abs            |                |                
Ambrak                                        | aag            |                |                
Ambul                                         | apo            |                |                
Ambulas                                       | abt            |                |                
Amdang                                        | amj            |                |                
Amdo Tibetan                                  | adx            |                |                
Amele                                         | aey            |                |                
American Sign Language                        | ase            |                |                
Amganad Ifugao                                | ifa            |                |                
Amharic                                       | amh            | am             |                
Ami                                           | amy            |                |                
Amis                                          | ami            |                |                
Amo                                           | amo            |                |                
Amol                                          | alx            |                |                
Amoltepec Mixtec                              | mbz            |                |                
Ampanang                                      | apg            |                |                
Ampari Dogon                                  | aqd            |                |                
Amri Karbi                                    | ajz            |                |                
Amto                                          | amt            |                |                
Amundava                                      | adw            |                |                
Amurdak                                       | amg            |                |                
Ana Tinga Dogon                               | dti            |                |                
Anaang                                        | anw            |                |                
Anakalangu                                    | akg            |                |                
Anal                                          | anm            |                |                
Anam                                          | pda            |                |                
Anambé                                        | aan            |                |                
Anamgura                                      | imi            |                |                
Anasi                                         | bpo            |                |                
Ancient Hebrew                                | hbo            |                |                
Ancient Macedonian                            | xmk            |                |                
Ancient North Arabian                         | xna            |                |                
Ancient Zapotec                               | xzp            |                |                
Andaandi                                      | dgl            |                |                
Andai                                         | afd            |                |                
Andajin                                       | ajn            |                |                
Andalusian Arabic                             | xaa            |                |                
Andaman Creole Hindi                          | hca            |                |                
Andaqui                                       | ana            |                |                
Andarum                                       | aod            |                |                
Andegerebinha                                 | adg            |                |                
Andh                                          | anr            |                |                
Andi                                          | ani            |                |                
Andio                                         | bzb            |                |                
Andoa                                         | anb            |                |                
Andoque                                       | ano            |                |                
Andra-Hus                                     | anx            |                |                
Aneityum                                      | aty            |                |                
Anem                                          | anz            |                |                
Aneme Wake                                    | aby            |                |                
Anfillo                                       | myo            |                |                
Angaataha                                     | agm            |                |                
Angaité                                       | aqt            |                |                
Angal Enen                                    | aoe            |                |                
Angal Heneng                                  | akh            |                |                
Angal                                         | age            |                |                
Angami Naga                                   | njm            |                |                
Angguruk Yali                                 | yli            |                |                
Angika                                        | anp            |                |                
Angkamuthi                                    | avm            |                |                
Anglo-Norman                                  | xno            |                |                
Angloromani                                   | rme            |                |                
Angolar                                       | aoa            |                |                
Angor                                         | agg            |                |                
Angoram                                       | aog            |                |                
Angosturas Tunebo                             | tnd            |                |                
Anguthimri                                    | awg            |                |                
Ani Phowa                                     | ypn            |                |                
Anii                                          | blo            |                |                
Animere                                       | anf            |                |                
Anindilyakwa                                  | aoi            |                |                
Aninka                                        | aqk            |                |                
Anjam                                         | boj            |                |                
Ankave                                        | aak            |                |                
Anmatyerre                                    | amx            |                |                
Anong                                         | nun            |                |                
Anor                                          | anj            |                |                
Anserma                                       | ans            |                |                
Ansus                                         | and            |                |                
Antakarinya                                   | ant            |                |                
Antankarana Malagasy                          | xmv            |                |                
Antigua and Barbuda Creole English            | aig            |                |                
Anu-Hkongso Chin                              | anl            |                |                
Anuak                                         | anu            |                |                
Anufo                                         | cko            |                |                
Anuki                                         | aui            |                |                
Anus                                          | auq            |                |                
Anuta                                         | aud            |                |                
Anyin Morofo                                  | mtb            |                |                
Anyin                                         | any            |                |                
Ao Naga                                       | njo            |                |                
Aoheng                                        | pni            |                |                
Aore                                          | aor            |                |                
Ap Ma                                         | kbx            |                |                
Apache languages                              | apa            |                |                
Apalachee                                     | xap            |                |                
Apalaí                                        | apy            |                |                
Apali                                         | ena            |                |                
Apasco-Apoala Mixtec                          | mip            |                |                
Apatani                                       | apt            |                |                
Apiaká                                        | api            |                |                
Apinayé                                       | apn            |                |                
Apma                                          | app            |                |                
Aproumu Aizi                                  | ahp            |                |                
Apurinã                                       | apu            |                |                
Aputai                                        | apx            |                |                
Aquitanian                                    | xaq            |                |                
Arabana                                       | ard            |                |                
Arabela                                       | arl            |                |                
Arabic                                        | ara            | ar             |                
Aragonese                                     | arg            | an             |                
Araki                                         | akr            |                |                
Arakwal                                       | rkw            |                |                
Aralle-Tabulahan                              | atq            |                |                
Aramanik                                      | aam            |                |                
Arammba                                       | stk            |                |                
Aranadan                                      | aaf            |                |                
Aranama-Tamique                               | xrt            |                |                
Arandai                                       | jbj            |                |                
Araona                                        | aro            |                |                
Arapaho                                       | arp            |                |                
Arapaso                                       | arj            |                |                
Ararandewára                                  | xaj            |                |                
Arauan languages                              | auf            |                |                
Arawak                                        | arw            |                |                
Arawakan languages                            | awd            |                |                
Araweté                                       | awt            |                |                
Arawum                                        | awm            |                |                
Arbore                                        | arv            |                |                
Arbëreshë Albanian                            | aae            |                |                
Archi                                         | aqc            |                |                
Ardhamāgadhī Prākrit                          | pka            |                |                
Are                                           | mwc            |                |                
Areba                                         | aea            |                |                
Arem                                          | aem            |                |                
Arequipa-La Unión Quechua                     | qxu            |                |                
Argentine Sign Language                       | aed            |                |                
Argobba                                       | agj            |                |                
Arguni                                        | agf            |                |                
Arhuaco                                       | arh            |                |                
Arhâ                                          | aqr            |                |                
Arhö                                          | aok            |                |                
Ari                                           | aac            |                |                
Aribwatsa                                     | laz            |                |                
Aribwaung                                     | ylu            |                |                
Arifama-Miniafia                              | aai            |                |                
Arigidi                                       | aqg            |                |                
Arikapú                                       | ark            |                |                
Arikara                                       | ari            |                |                
Arikem                                        | ait            |                |                
Arin                                          | xrn            |                |                
Aringa                                        | luc            |                |                
Arma                                          | aoh            |                |                
Armazic                                       | xrm            |                |                
Armenian (family)                             | hyx            |                |                
Armenian Sign Language                        | aen            |                |                
Armenian                                      | arm            | hy             | hye            
Arop-Lokep                                    | apr            |                |                
Arop-Sissano                                  | aps            |                |                
Arosi                                         | aia            |                |                
Arpitan                                       | frp            |                |                
Arritinngithigh                               | rrt            |                |                
Arta                                          | atz            |                |                
Artificial languages                          | art            |                |                
Aruamu                                        | msy            |                |                
Aruek                                         | aur            |                |                
Aruop                                         | lsr            |                |                
Arutani                                       | atx            |                |                
Aruá (Amazonas State)                         | aru            |                |                
Aruá (Rodonia State)                          | arx            |                |                
Arvanitika Albanian                           | aat            |                |                
As                                            | asz            |                |                
Asaro'o                                       | mtv            |                |                
Asas                                          | asd            |                |                
Ashe                                          | ahs            |                |                
Ashkun                                        | ask            |                |                
Asho Chin                                     | csh            |                |                
Ashtiani                                      | atn            |                |                
Asháninka                                     | cni            |                |                
Ashéninka Pajonal                             | cjo            |                |                
Ashéninka Perené                              | prq            |                |                
Asilulu                                       | asl            |                |                
Askopan                                       | eiv            |                |                
Asoa                                          | asv            |                |                
Assamese                                      | asm            | as             |                
Assan                                         | xss            |                |                
Assangori                                     | sjg            |                |                
Assiniboine                                   | asb            |                |                
Assyrian Neo-Aramaic                          | aii            |                |                
Asturian                                      | ast            |                |                
Asu (Nigeria)                                 | aum            |                |                
Asu (Tanzania)                                | asa            |                |                
Asue Awyu                                     | psa            |                |                
Asumboa                                       | aua            |                |                
Asunción Mixtepec Zapotec                     | zoo            |                |                
Asuri                                         | asr            |                |                
Ata Manobo                                    | atd            |                |                
Ata                                           | atm            |                |                
Atakapa                                       | aqp            |                |                
Atampaya                                      | amz            |                |                
Atatláhuca Mixtec                             | mib            |                |                
Atauran                                       | adb            |                |                
Atayal                                        | tay            |                |                
Atemble                                       | ate            |                |                
Athapascan languages                          | ath            |                |                
Athpariya                                     | aph            |                |                
Ati                                           | atk            |                |                
Atikamekw                                     | atj            |                |                
Atlantic-Congo languages                      | alv            |                |                
Atohwaim                                      | aqm            |                |                
Atong (Cameroon)                              | ato            |                |                
Atong (India)                                 | aot            |                |                
Atorada                                       | aox            |                |                
Atsahuaca                                     | atc            |                |                
Atsam                                         | cch            |                |                
Atsugewi                                      | atw            |                |                
Attapady Kurumba                              | pkr            |                |                
Attié                                         | ati            |                |                
Atzingo Matlatzinca                           | ocu            |                |                
Au                                            | avt            |                |                
Aulua                                         | aul            |                |                
Aurá                                          | aux            |                |                
Aushi                                         | auh            |                |                
Aushiri                                       | avs            |                |                
Auslan                                        | asf            |                |                
Austral                                       | aut            |                |                
Australian Aborigines Sign Language           | asw            |                |                
Australian languages                          | aus            |                |                
Austrian Sign Language                        | asq            |                |                
Austro-Asiatic languages                      | aav            |                |                
Austronesian languages                        | map            |                |                
Auwe                                          | smf            |                |                
Auye                                          | auu            |                |                
Auyokawa                                      | auo            |                |                
Avaric                                        | ava            | av             |                
Avatime                                       | avn            |                |                
Avau                                          | avb            |                |                
Avestan                                       | ave            | ae             |                
Avikam                                        | avi            |                |                
Avokaya                                       | avu            |                |                
Avá-Canoeiro                                  | avv            |                |                
Awa (China)                                   | vwa            |                |                
Awa (Papua New Guinea)                        | awb            |                |                
Awa-Cuaiquer                                  | kwi            |                |                
Awabakal                                      | awk            |                |                
Awad Bing                                     | bcu            |                |                
Awadhi                                        | awa            |                |                
Awak                                          | awo            |                |                
Awar                                          | aya            |                |                
Awara                                         | awx            |                |                
Awbono                                        | awh            |                |                
Aweer                                         | bob            |                |                
Awera                                         | awr            |                |                
Awetí                                         | awe            |                |                
Awing                                         | azo            |                |                
Awiyaana                                      | auy            |                |                
Awjilah                                       | auj            |                |                
Awngi                                         | awn            |                |                
Awngthim                                      | gwm            |                |                
Awtuw                                         | kmn            |                |                
Awu                                           | yiu            |                |                
Awun                                          | aww            |                |                
Awutu                                         | afu            |                |                
Awyi                                          | auw            |                |                
Axamb                                         | ahb            |                |                
Axi Yi                                        | yix            |                |                
Ayabadhu                                      | ayd            |                |                
Ayacucho Quechua                              | quy            |                |                
Ayautla Mazatec                               | vmy            |                |                
Ayere                                         | aye            |                |                
Ayerrerenge                                   | axe            |                |                
Ayi (China)                                   | ayx            |                |                
Ayi (Papua New Guinea)                        | ayq            |                |                
Ayiwo                                         | nfl            |                |                
Ayizi                                         | yyz            |                |                
Ayizo Gbe                                     | ayb            |                |                
Aymara                                        | aym            | ay             |                
Ayoquesco Zapotec                             | zaf            |                |                
Ayoreo                                        | ayo            |                |                
Ayu                                           | ayu            |                |                
Ayutla Mixtec                                 | miy            |                |                
Azerbaijani                                   | aze            | az             |                
Azha                                          | aza            |                |                
Azhe                                          | yiz            |                |                
Azoyú Me'phaa                                 | tpc            |                |                
Baan                                          | bvj            |                |                
Baangi                                        | bqx            |                |                
Baatonum                                      | bba            |                |                
Baba Malay                                    | mbf            |                |                
Baba                                          | bbw            |                |                
Babalia Creole Arabic                         | bbz            |                |                
Babango                                       | bbm            |                |                
Babanki                                       | bbk            |                |                
Babatana                                      | baa            |                |                
Babine                                        | bcr            |                |                
Babuza                                        | bzg            |                |                
Bacama                                        | bcy            |                |                
Bacanese Malay                                | btj            |                |                
Bactrian                                      | xbc            |                |                
Bada (Indonesia)                              | bhz            |                |                
Bada (Nigeria)                                | bau            |                |                
Badaga                                        | bfq            |                |                
Bade                                          | bde            |                |                
Badeshi                                       | bdz            |                |                
Badimaya                                      | bia            |                |                
Badjiri                                       | jbi            |                |                
Badui                                         | bac            |                |                
Badyara                                       | pbp            |                |                
Baeggu                                        | bvd            |                |                
Baelelea                                      | bvc            |                |                
Baetora                                       | btr            |                |                
Bafanji                                       | bfj            |                |                
Bafaw-Balong                                  | bwt            |                |                
Bafia                                         | ksf            |                |                
Bafut                                         | bfd            |                |                
Baga Kaloum                                   | bqf            |                |                
Baga Koga                                     | bgo            |                |                
Baga Manduri                                  | bmd            |                |                
Baga Mboteni                                  | bgm            |                |                
Baga Pokur                                    | bcg            |                |                
Baga Sitemu                                   | bsp            |                |                
Baga Sobané                                   | bsv            |                |                
Bagheli                                       | bfy            |                |                
Bagirmi Fulfulde                              | fui            |                |                
Bagirmi                                       | bmi            |                |                
Bago-Kusuntu                                  | bqg            |                |                
Bagri                                         | bgq            |                |                
Bagupi                                        | bpi            |                |                
Bagusa                                        | bqb            |                |                
Bagvalal                                      | kva            |                |                
Baha Buyang                                   | yha            |                |                
Baham                                         | bdw            |                |                
Bahamas Creole English                        | bah            |                |                
Baharna Arabic                                | abv            |                |                
Bahau                                         | bhv            |                |                
Bahinemo                                      | bjh            |                |                
Bahing                                        | bhj            |                |                
Bahnar                                        | bdq            |                |                
Bahonsuai                                     | bsu            |                |                
Bai (South Sudan)                             | bdj            |                |                
Baibai                                        | bbf            |                |                
Baikeno                                       | bkx            |                |                
Baima                                         | bqh            |                |                
Baimak                                        | bmx            |                |                
Bainouk-Gunyaamolo                            | bcz            |                |                
Bainouk-Gunyuño                               | bab            |                |                
Bainouk-Samik                                 | bcb            |                |                
Baiso                                         | bsw            |                |                
Baissa Fali                                   | fah            |                |                
Bajan                                         | bjs            |                |                
Bajelani                                      | bjm            |                |                
Baka (Cameroon)                               | bkc            |                |                
Baka (South Sudan)                            | bdh            |                |                
Bakairí                                       | bkq            |                |                
Bakaka                                        | bqz            |                |                
Bakhtiari                                     | bqi            |                |                
Baki                                          | bki            |                |                
Bakoko                                        | bkh            |                |                
Bakole                                        | kme            |                |                
Bakpinka                                      | bbs            |                |                
Bakumpai                                      | bkr            |                |                
Bakwé                                         | bjw            |                |                
Balaesang                                     | bls            |                |                
Balaibalan                                    | zba            |                |                
Balangao                                      | blw            |                |                
Balangingi                                    | sse            |                |                
Balanta-Ganja                                 | bjt            |                |                
Balanta-Kentohe                               | ble            |                |                
Balantak                                      | blz            |                |                
Balau                                         | blg            |                |                
Baldemu                                       | bdn            |                |                
Bali (Democratic Republic of Congo)           | bcp            |                |                
Bali (Nigeria)                                | bcn            |                |                
Balinese Malay                                | mhp            |                |                
Balinese                                      | ban            |                |                
Balkan Gagauz Turkish                         | bgx            |                |                
Balkan Romani                                 | rmn            |                |                
Balo                                          | bqo            |                |                
Baloi                                         | biz            |                |                
Balti                                         | bft            |                |                
Baltic Romani                                 | rml            |                |                
Baltic languages                              | bat            |                |                
Baluan-Pam                                    | blq            |                |                
Baluchi                                       | bal            |                |                
Bamako Sign Language                          | bog            |                |                
Bamali                                        | bbq            |                |                
Bambalang                                     | bmo            |                |                
Bambam                                        | ptu            |                |                
Bambara                                       | bam            | bm             |                
Bambassi                                      | myf            |                |                
Bambili-Bambui                                | baw            |                |                
Bamenyam                                      | bce            |                |                
Bamileke languages                            | bai            |                |                
Bamu                                          | bcf            |                |                
Bamukumbit                                    | bqt            |                |                
Bamun                                         | bax            |                |                
Bamunka                                       | bvm            |                |                
Bamwe                                         | bmg            |                |                
Ban Khor Sign Language                        | bfk            |                |                
Bana                                          | bcw            |                |                
Banao Itneg                                   | bjx            |                |                
Banaro                                        | byz            |                |                
Banda (Indonesia)                             | bnd            |                |                
Banda Malay                                   | bpq            |                |                
Banda languages                               | bad            |                |                
Banda-Bambari                                 | liy            |                |                
Banda-Banda                                   | bpd            |                |                
Banda-Mbrès                                   | bqk            |                |                
Banda-Ndélé                                   | bfl            |                |                
Banda-Yangere                                 | yaj            |                |                
Bandi                                         | bza            |                |                
Bandial                                       | bqj            |                |                
Bandjalang                                    | bdy            |                |                
Bandjigali                                    | bjd            |                |                
Bangala                                       | bxg            |                |                
Bangandu                                      | bgf            |                |                
Bangba                                        | bbe            |                |                
Banggai                                       | bgz            |                |                
Banggarla                                     | bjb            |                |                
Bangi                                         | bni            |                |                
Bangime                                       | dba            |                |                
Bangka                                        | mfb            |                |                
Bangolan                                      | bgj            |                |                
Bangubangu                                    | bnx            |                |                
Bangwinji                                     | bsj            |                |                
Baniva                                        | bvv            |                |                
Baniwa                                        | bwi            |                |                
Banjar                                        | bjn            |                |                
Bankagooma                                    | bxw            |                |                
Bankal                                        | jjr            |                |                
Bankan Tey Dogon                              | dbw            |                |                
Bankon                                        | abb            |                |                
Bannoni                                       | bcm            |                |                
Bantawa                                       | bap            |                |                
Bantayanon                                    | bfx            |                |                
Bantik                                        | bnq            |                |                
Bantoanon                                     | bno            |                |                
Bantu languages                               | bnt            |                |                
Banyjima                                      | pnw            |                |                
Baoulé                                        | bci            |                |                
Bara Malagasy                                 | bhr            |                |                
Baraamu                                       | brd            |                |                
Barababaraba                                  | rbp            |                |                
Barai                                         | bbb            |                |                
Barakai                                       | baj            |                |                
Baram Kayan                                   | kys            |                |                
Barama                                        | bbg            |                |                
Barambu                                       | brm            |                |                
Baramu                                        | bmz            |                |                
Barapasi                                      | brp            |                |                
Baras                                         | brs            |                |                
Barasana-Eduria                               | bsn            |                |                
Barbacoas                                     | bpb            |                |                
Barbaram                                      | vmb            |                |                
Barbareño                                     | boi            |                |                
Barclayville Grebo                            | gry            |                |                
Bardi                                         | bcj            |                |                
Barein                                        | bva            |                |                
Bargam                                        | mlp            |                |                
Bari                                          | bfa            |                |                
Bariai                                        | bch            |                |                
Bariji                                        | bjc            |                |                
Barikanchi                                    | bxo            |                |                
Barikewa                                      | jbk            |                |                
Barok                                         | bjk            |                |                
Barombi                                       | bbi            |                |                
Barro Negro Tunebo                            | tbn            |                |                
Barrow Point                                  | bpt            |                |                
Baruga                                        | bjz            |                |                
Baruya                                        | byr            |                |                
Barwe                                         | bwg            |                |                
Barzani Jewish Neo-Aramaic                    | bjf            |                |                
Baré                                          | bae            |                |                
Barí                                          | mot            |                |                
Basa (Cameroon)                               | bas            |                |                
Basa (Nigeria)                                | bzw            |                |                
Basa-Gumna                                    | bsl            |                |                
Basa-Gurmana                                  | buj            |                |                
Basap                                         | bdb            |                |                
Basay                                         | byq            |                |                
Bashkardi                                     | bsg            |                |                
Bashkir                                       | bak            | ba             |                
Basketo                                       | bst            |                |                
Basque (family)                               | euq            |                |                
Basque                                        | baq            | eu             | eus            
Bassa                                         | bsq            |                |                
Bassa-Kontagora                               | bsr            |                |                
Bassari                                       | bsc            |                |                
Bassossi                                      | bsi            |                |                
Bata                                          | bta            |                |                
Batad Ifugao                                  | ifb            |                |                
Batak Alas-Kluet                              | btz            |                |                
Batak Angkola                                 | akb            |                |                
Batak Dairi                                   | btd            |                |                
Batak Karo                                    | btx            |                |                
Batak Mandailing                              | btm            |                |                
Batak Simalungun                              | bts            |                |                
Batak Toba                                    | bbc            |                |                
Batak languages                               | btk            |                |                
Batak                                         | bya            |                |                
Batanga                                       | bnm            |                |                
Batek                                         | btq            |                |                
Bateri                                        | btv            |                |                
Bathari                                       | bhm            |                |                
Bati (Cameroon)                               | btc            |                |                
Bati (Indonesia)                              | bvt            |                |                
Batjala                                       | xby            |                |                
Bats                                          | bbl            |                |                
Batu                                          | btu            |                |                
Batui                                         | zbt            |                |                
Batuley                                       | bay            |                |                
Bau Bidayuh                                   | sne            |                |                
Bau                                           | bbd            |                |                
Bauchi                                        | bsf            |                |                
Bauni                                         | bpe            |                |                
Baure                                         | brg            |                |                
Bauria                                        | bge            |                |                
Bauwaki                                       | bwk            |                |                
Bauzi                                         | bvz            |                |                
Bavarian                                      | bar            |                |                
Bawm Chin                                     | bgr            |                |                
Bay Miwok                                     | mkq            |                |                
Bayali                                        | bjy            |                |                
Baybayanon                                    | bvy            |                |                
Baygo                                         | byg            |                |                
Bayono                                        | byl            |                |                
Bayot                                         | bda            |                |                
Bayungu                                       | bxj            |                |                
Bazigar                                       | bfr            |                |                
Beami                                         | beo            |                |                
Beaver                                        | bea            |                |                
Beba                                          | bfp            |                |                
Bebele                                        | beb            |                |                
Bebeli                                        | bek            |                |                
Bebil                                         | bxp            |                |                
Bedjond                                       | bjv            |                |                
Bedoanas                                      | bed            |                |                
Beeke                                         | bkf            |                |                
Beele                                         | bxq            |                |                
Beembe                                        | beq            |                |                
Beezen                                        | bnz            |                |                
Befang                                        | bby            |                |                
Beginci                                       | ebc            |                |                
Beja                                          | bej            |                |                
Bekati'                                       | bei            |                |                
Bekwarra                                      | bkv            |                |                
Bekwel                                        | bkw            |                |                
Belait                                        | beg            |                |                
Belanda Bor                                   | bxb            |                |                
Belanda Viri                                  | bvi            |                |                
Belarusian                                    | bel            | be             |                
Belhariya                                     | byw            |                |                
Beli (Papua New Guinea)                       | bey            |                |                
Beli (South Sudan)                            | blm            |                |                
Belize Kriol English                          | bzj            |                |                
Bella Coola                                   | blc            |                |                
Bellari                                       | brw            |                |                
Belning                                       | glb            |                |                
Bemba (Democratic Republic of Congo)          | bmy            |                |                
Bemba (Zambia)                                | bem            |                |                
Bembe                                         | bmb            |                |                
Ben Tey Dogon                                 | dbt            |                |                
Bena (Nigeria)                                | yun            |                |                
Bena (Tanzania)                               | bez            |                |                
Benabena                                      | bef            |                |                
Benamanga                                     | egm            |                |                
Bench                                         | bcq            |                |                
Bende                                         | bdp            |                |                
Bendi                                         | bct            |                |                
Beng                                          | nhb            |                |                
Benga                                         | bng            |                |                
Bengali                                       | ben            | bn             |                
Benggoi                                       | bgy            |                |                
Bengkala Sign Language                        | bqy            |                |                
Bentong                                       | bnu            |                |                
Benyadu'                                      | byd            |                |                
Beothuk                                       | bue            |                |                
Bepour                                        | bie            |                |                
Berakou                                       | bxv            |                |                
Berau Malay                                   | bve            |                |                
Berber languages                              | ber            |                |                
Berbice Creole Dutch                          | brc            |                |                
Berik                                         | bkl            |                |                
Berinomo                                      | bit            |                |                
Berom                                         | bom            |                |                
Berta                                         | wti            |                |                
Berti                                         | byt            |                |                
Besisi                                        | mhe            |                |                
Besme                                         | bes            |                |                
Besoa                                         | bep            |                |                
Betaf                                         | bfe            |                |                
Betawi                                        | bew            |                |                
Bete                                          | byf            |                |                
Bete-Bendi                                    | btt            |                |                
Beti (Cameroon)                               | btb            |                |                
Beti (Côte d'Ivoire)                          | eot            |                |                
Betta Kurumba                                 | xub            |                |                
Bezhta                                        | kap            |                |                
Bhadrawahi                                    | bhd            |                |                
Bhalay                                        | bhx            |                |                
Bharia                                        | bha            |                |                
Bhatola                                       | btl            |                |                
Bhatri                                        | bgw            |                |                
Bhattiyali                                    | bht            |                |                
Bhaya                                         | bhe            |                |                
Bhele                                         | bhy            |                |                
Bhilali                                       | bhi            |                |                
Bhili                                         | bhb            |                |                
Bhojpuri                                      | bho            |                |                
Bhoti Kinnauri                                | nes            |                |                
Bhujel                                        | byh            |                |                
Bhunjia                                       | bhu            |                |                
Biafada                                       | bif            |                |                
Biage                                         | bdf            |                |                
Biak                                          | bhw            |                |                
Biali                                         | beh            |                |                
Bian Marind                                   | bpv            |                |                
Biangai                                       | big            |                |                
Biao Mon                                      | bmt            |                |                
Biao                                          | byk            |                |                
Biao-Jiao Mien                                | bje            |                |                
Biatah Bidayuh                                | bth            |                |                
Bibbulman                                     | xbp            |                |                
Bidhawal                                      | ihw            |                |                
Bidiyo                                        | bid            |                |                
Bidjara                                       | bym            |                |                
Bidyogo                                       | bjg            |                |                
Biem                                          | bmc            |                |                
Bierebo                                       | bnk            |                |                
Bieria                                        | brj            |                |                
Biete                                         | biu            |                |                
Big Nambas                                    | nmb            |                |                
Biga                                          | bhc            |                |                
Bigambal                                      | xbe            |                |                
Bih                                           | ibh            |                |                
Bihari languages                              | bih            | bh             |                
Bijim                                         | jbm            |                |                
Bijori                                        | bix            |                |                
Bikaru                                        | bic            |                |                
Bikol                                         | bik            |                |                
Bikya                                         | byb            |                |                
Bila                                          | bip            |                |                
Bilakura                                      | bql            |                |                
Bilaspuri                                     | kfs            |                |                
Bilba                                         | bpz            |                |                
Bilbil                                        | brz            |                |                
Bile                                          | bil            |                |                
Bilin                                         | byn            |                |                
Bilma Kanuri                                  | bms            |                |                
Biloxi                                        | bll            |                |                
Bilua                                         | blb            |                |                
Bilur                                         | bxf            |                |                
Bima                                          | bhp            |                |                
Bimin                                         | bhl            |                |                
Bimoba                                        | bim            |                |                
Bina (Nigeria)                                | byj            |                |                
Bina (Papua New Guinea)                       | bmn            |                |                
Binahari                                      | bxz            |                |                
Binandere                                     | bhg            |                |                
Bindal                                        | xbd            |                |                
Bine                                          | bon            |                |                
Bini                                          | bin            |                |                
Binji                                         | bpj            |                |                
Binongan Itneg                                | itb            |                |                
Bintauna                                      | bne            |                |                
Bintulu                                       | bny            |                |                
Binukid                                       | bkd            |                |                
Binumarien                                    | bjr            |                |                
Bipi                                          | biq            |                |                
Bira                                          | brf            |                |                
Birale                                        | bxe            |                |                
Birao                                         | brr            |                |                
Birgit                                        | btf            |                |                
Birhor                                        | biy            |                |                
Biri                                          | bzr            |                |                
Biritai                                       | bqq            |                |                
Birked                                        | brk            |                |                
Birri                                         | bvq            |                |                
Birrpayi                                      | xbj            |                |                
Birwa                                         | brl            |                |                
Biseni                                        | ije            |                |                
Bishnupriya                                   | bpy            |                |                
Bishuo                                        | bwh            |                |                
Bisis                                         | bnw            |                |                
Bislama                                       | bis            | bi             |                
Bisorio                                       | bir            |                |                
Bissa                                         | bib            |                |                
Bisu                                          | bzi            |                |                
Bit                                           | bgk            |                |                
Bitare                                        | brt            |                |                
Bitur                                         | mcc            |                |                
Biwat                                         | bwm            |                |                
Biyo                                          | byo            |                |                
Biyom                                         | bpm            |                |                
Blablanga                                     | blp            |                |                
Blafe                                         | bfh            |                |                
Blagar                                        | beu            |                |                
Blang                                         | blr            |                |                
Blissymbols                                   | zbl            |                |                
Bo (Laos)                                     | bgl            |                |                
Bo (Papua New Guinea)                         | bpw            |                |                
Bo-Rukul                                      | mae            |                |                
Bo-Ung                                        | mux            |                |                
Boano (Maluku)                                | bzn            |                |                
Boano (Sulawesi)                              | bzl            |                |                
Bobongko                                      | bgb            |                |                
Bobot                                         | bty            |                |                
Bodo (Central African Republic)               | boy            |                |                
Bodo (India)                                  | brx            |                |                
Bodo Gadaba                                   | gbj            |                |                
Bodo Parja                                    | bdv            |                |                
Bofi                                          | bff            |                |                
Boga                                          | bvw            |                |                
Bogaya                                        | boq            |                |                
Boghom                                        | bux            |                |                
Boguru                                        | bqu            |                |                
Bohtan Neo-Aramaic                            | bhn            |                |                
Boikin                                        | bzf            |                |                
Bokha                                         | ybk            |                |                
Boko (Benin)                                  | bqc            |                |                
Boko (Democratic Republic of Congo)           | bkp            |                |                
Bokobaru                                      | bus            |                |                
Bokoto                                        | bdt            |                |                
Bokyi                                         | bky            |                |                
Bola                                          | bnp            |                |                
Bolango                                       | bld            |                |                
Bole                                          | bol            |                |                
Bolgarian                                     | xbo            |                |                
Bolgo                                         | bvo            |                |                
Bolia                                         | bli            |                |                
Bolinao                                       | smk            |                |                
Bolivian Sign Language                        | bvl            |                |                
Boloki                                        | bkt            |                |                
Bolon                                         | bof            |                |                
Bolondo                                       | bzm            |                |                
Bolongan                                      | blj            |                |                
Bolyu                                         | ply            |                |                
Bom-Kim                                       | bmf            |                |                
Boma                                          | boh            |                |                
Bomboli                                       | bml            |                |                
Bomboma                                       | bws            |                |                
Bomitaba                                      | zmx            |                |                
Bomu                                          | bmq            |                |                
Bomwali                                       | bmw            |                |                
Bon Gula                                      | glc            |                |                
Bonan                                         | peh            |                |                
Bondei                                        | bou            |                |                
Bondo                                         | bfw            |                |                
Bondoukou Kulango                             | kzc            |                |                
Bondum Dom Dogon                              | dbu            |                |                
Bonerate                                      | bna            |                |                
Bonerif                                       | bnv            |                |                
Bonggi                                        | bdg            |                |                
Bonggo                                        | bpg            |                |                
Bongili                                       | bui            |                |                
Bongo                                         | bot            |                |                
Bongu                                         | bpu            |                |                
Bonjo                                         | bok            |                |                
Bonkeng                                       | bvg            |                |                
Bonkiman                                      | bop            |                |                
Bontok                                        | bnc            |                |                
Bookan                                        | bnb            |                |                
Boon                                          | bnl            |                |                
Boor                                          | bvf            |                |                
Bora                                          | boa            |                |                
Borana-Arsi-Guji Oromo                        | gax            |                |                
Border Kuna                                   | kvn            |                |                
Borei                                         | gai            |                |                
Borgu Fulfulde                                | fue            |                |                
Borna (Democratic Republic of Congo)          | bxx            |                |                
Boro (Ethiopia)                               | bwo            |                |                
Boro (Ghana)                                  | xxb            |                |                
Borong                                        | ksr            |                |                
Boruca                                        | brn            |                |                
Borôro                                        | bor            |                |                
Boselewa                                      | bwf            |                |                
Bosngun                                       | bqs            |                |                
Bosnian                                       | bos            | bs             |                
Bote-Majhi                                    | bmj            |                |                
Botlikh                                       | bph            |                |                
Botolan Sambal                                | sbl            |                |                
Bouna Kulango                                 | nku            |                |                
Bouni                                         | suo            |                |                
Bouyei                                        | pcc            |                |                
Bozaba                                        | bzo            |                |                
Bragat                                        | aof            |                |                
Brahui                                        | brh            |                |                
Braj                                          | bra            |                |                
Brao                                          | brb            |                |                
Brazilian Sign Language                       | bzs            |                |                
Brem                                          | buq            |                |                
Breri                                         | brq            |                |                
Breton                                        | bre            | br             |                
Bribri Sign Language                          | rib            |                |                
Bribri                                        | bzd            |                |                
Brithenig                                     | bzt            |                |                
British Sign Language                         | bfi            |                |                
Brokkat                                       | bro            |                |                
Brokpake                                      | sgt            |                |                
Brokskat                                      | bkk            |                |                
Brooke's Point Palawano                       | plw            |                |                
Broome Pearling Lugger Pidgin                 | bpl            |                |                
Brunca Sign Language                          | rnb            |                |                
Brunei Bisaya                                 | bsb            |                |                
Brunei                                        | kxd            |                |                
Bruny Island Tasmanian                        | xpz            |                |                
Bu (Bauchi State)                             | zbu            |                |                
Bu (Kaduna State)                             | jid            |                |                
Bu-Nao Bunu                                   | bwx            |                |                
Bua                                           | bub            |                |                
Bualkhaw Chin                                 | cbl            |                |                
Buamu                                         | box            |                |                
Bube                                          | bvb            |                |                
Bubi                                          | buw            |                |                
Bubia                                         | bbx            |                |                
Budeh Stieng                                  | stt            |                |                
Budibud                                       | btp            |                |                
Budong-Budong                                 | bdx            |                |                
Budu                                          | buu            |                |                
Budukh                                        | bdk            |                |                
Buduma                                        | bdm            |                |                
Budza                                         | bja            |                |                
Bugan                                         | bbh            |                |                
Bugawac                                       | buk            |                |                
Bughotu                                       | bgt            |                |                
Buginese                                      | bug            |                |                
Buglere                                       | sab            |                |                
Bugun                                         | bgg            |                |                
Buhi'non Bikol                                | ubl            |                |                
Buhid                                         | bku            |                |                
Buhutu                                        | bxh            |                |                
Bukar-Sadung Bidayuh                          | sdo            |                |                
Bukat                                         | bvk            |                |                
Bukharic                                      | bhh            |                |                
Bukit Malay                                   | bvu            |                |                
Bukitan                                       | bkn            |                |                
Bukiyip                                       | ape            |                |                
Buksa                                         | tkb            |                |                
Bukusu                                        | bxk            |                |                
Bukwen                                        | buz            |                |                
Bulgarian Sign Language                       | bqn            |                |                
Bulgarian                                     | bul            | bg             |                
Bulgebi                                       | bmp            |                |                
Buli (Ghana)                                  | bwu            |                |                
Buli (Indonesia)                              | bzq            |                |                
Bullom So                                     | buy            |                |                
Bulo Stieng                                   | sti            |                |                
Bulu (Cameroon)                               | bum            |                |                
Bulu (Papua New Guinea)                       | bjl            |                |                
Bum                                           | bmv            |                |                
Bumaji                                        | byp            |                |                
Bumang                                        | bvp            |                |                
Bumbita Arapesh                               | aon            |                |                
Bumthangkha                                   | kjz            |                |                
Bun                                           | buv            |                |                
Buna                                          | bvn            |                |                
Bunak                                         | bfn            |                |                
Bunama                                        | bdd            |                |                
Bundeli                                       | bns            |                |                
Bung                                          | bqd            |                |                
Bungain                                       | but            |                |                
Bunganditj                                    | xbg            |                |                
Bungku                                        | bkz            |                |                
Bungu                                         | wun            |                |                
Bunoge Dogon                                  | dgb            |                |                
Bunuba                                        | bck            |                |                
Bunun                                         | bnn            |                |                
Buol                                          | blf            |                |                
Bura-Pabir                                    | bwr            |                |                
Burak                                         | bys            |                |                
Buraka                                        | bkg            |                |                
Burarra                                       | bvr            |                |                
Burate                                        | bti            |                |                
Burduna                                       | bxn            |                |                
Bure                                          | bvh            |                |                
Buriat                                        | bua            |                |                
Burji                                         | bji            |                |                
Burmbar                                       | vrt            |                |                
Burmese                                       | bur            | my             | mya            
Burmeso                                       | bzu            |                |                
Buru (Indonesia)                              | mhs            |                |                
Buru (Nigeria)                                | bqw            |                |                
Burui                                         | bry            |                |                
Burumakok                                     | aip            |                |                
Burun                                         | bdi            |                |                
Burundian Sign Language                       | lsb            |                |                
Burunge                                       | bds            |                |                
Burushaski                                    | bsk            |                |                
Burusu                                        | bqr            |                |                
Buruwai                                       | asi            |                |                
Busa                                          | bqp            |                |                
Busam                                         | bxs            |                |                
Busami                                        | bsm            |                |                
Busang Kayan                                  | bfg            |                |                
Bushi                                         | buc            |                |                
Bushoong                                      | buf            |                |                
Buso                                          | bso            |                |                
Busoa                                         | bup            |                |                
Bussa                                         | dox            |                |                
Busuu                                         | bju            |                |                
Butbut Kalinga                                | kyb            |                |                
Butmas-Tur                                    | bnr            |                |                
Butuanon                                      | btw            |                |                
Buwal                                         | bhs            |                |                
Buya                                          | byy            |                |                
Buyu                                          | byi            |                |                
Buyuan Jinuo                                  | jiy            |                |                
Bwa                                           | bww            |                |                
Bwaidoka                                      | bwd            |                |                
Bwanabwana                                    | tte            |                |                
Bwatoo                                        | bwa            |                |                
Bwe Karen                                     | bwe            |                |                
Bwela                                         | bwl            |                |                
Bwile                                         | bwc            |                |                
Bwisi                                         | bwz            |                |                
Byangsi                                       | bee            |                |                
Byep                                          | mkk            |                |                
Bädi Kanum                                    | khd            |                |                
C'Lela                                        | dri            |                |                
Caac                                          | msq            |                |                
Cabiyarí                                      | cbb            |                |                
Cabécar                                       | cjp            |                |                
Cacaloxtepec Mixtec                           | miu            |                |                
Cacaopera                                     | ccr            |                |                
Cacgia Roglai                                 | roc            |                |                
Cacua                                         | cbv            |                |                
Caddo                                         | cad            |                |                
Caddoan languages                             | cdd            |                |                
Cafundo Creole                                | ccd            |                |                
Cagua                                         | cbh            |                |                
Cahuarano                                     | cah            |                |                
Cahuilla                                      | chl            |                |                
Cajamarca Quechua                             | qvc            |                |                
Cajatambo North Lima Quechua                  | qvl            |                |                
Cajonos Zapotec                               | zad            |                |                
Cajun French                                  | frc            |                |                
Caka                                          | ckx            |                |                
Cakchiquel-Quiché Mixed Language              | ckz            |                |                
Cakfem-Mushere                                | cky            |                |                
Calamian Tagbanwa                             | tbk            |                |                
Calderón Highland Quichua                     | qud            |                |                
Callawalla                                    | caw            |                |                
Caluyanun                                     | clu            |                |                
Caló                                          | rmq            |                |                
Caló                                          | rmr            |                |                
Cambodian Sign Language                       | csx            |                |                
Cameroon Mambila                              | mcu            |                |                
Cameroon Pidgin                               | wes            |                |                
Camling                                       | rab            |                |                
Campalagian                                   | cml            |                |                
Campidanese Sardinian                         | sro            |                |                
Camsá                                         | kbh            |                |                
Camtho                                        | cmt            |                |                
Camunic                                       | xcc            |                |                
Candoshi-Shapra                               | cbu            |                |                
Canela                                        | ram            |                |                
Canichana                                     | caz            |                |                
Cao Lan                                       | mlc            |                |                
Cao Miao                                      | cov            |                |                
Capanahua                                     | kaq            |                |                
Capiznon                                      | cps            |                |                
Cappadocian Greek                             | cpg            |                |                
Caquinte                                      | cot            |                |                
Car Nicobarese                                | caq            |                |                
Cara                                          | cfd            |                |                
Carabayo                                      | cby            |                |                
Caramanta                                     | crf            |                |                
Carapana                                      | cbc            |                |                
Carian                                        | xcr            |                |                
Caribbean Hindustani                          | hns            |                |                
Caribbean Javanese                            | jvn            |                |                
Carijona                                      | cbd            |                |                
Carolina Algonquian                           | crr            |                |                
Carolinian                                    | cal            |                |                
Carpathian Romani                             | rmc            |                |                
Carrier                                       | crx            |                |                
Cashibo-Cacataibo                             | cbr            |                |                
Cashinahua                                    | cbs            |                |                
Casiguran Dumagat Agta                        | dgc            |                |                
Casuarina Coast Asmat                         | asc            |                |                
Cataelano Mandaya                             | mst            |                |                
Catalan Sign Language                         | csc            |                |                
Catalan                                       | cat            | ca             |                
Catawba                                       | chc            |                |                
Cauca                                         | cca            |                |                
Caucasian languages                           | cau            |                |                
Cavineña                                      | cav            |                |                
Cayubaba                                      | cyb            |                |                
Cayuga                                        | cay            |                |                
Cayuse                                        | xcy            |                |                
Cañar Highland Quichua                        | qxr            |                |                
Ca̱hungwa̱rya̱                                   | nat            |                |                
Cebaara Senoufo                               | sef            |                |                
Cebuano                                       | ceb            |                |                
Celtiberian                                   | xce            |                |                
Celtic languages                              | cel            |                |                
Cemuhî                                        | cam            |                |                
Cen                                           | cen            |                |                
Central American Indian languages             | cai            |                |                
Central Asmat                                 | cns            |                |                
Central Atlas Tamazight                       | tzm            |                |                
Central Awyu                                  | awu            |                |                
Central Aymara                                | ayr            |                |                
Central Bai                                   | bca            |                |                
Central Berawan                               | zbc            |                |                
Central Bikol                                 | bcl            |                |                
Central Bontok                                | lbk            |                |                
Central Cagayan Agta                          | agt            |                |                
Central Grebo                                 | grv            |                |                
Central Hongshuihe Zhuang                     | zch            |                |                
Central Huasteca Nahuatl                      | nch            |                |                
Central Huishui Hmong                         | hmc            |                |                
Central Kanuri                                | knc            |                |                
Central Kurdish                               | ckb            |                |                
Central Maewo                                 | mwo            |                |                
Central Malay                                 | pse            |                |                
Central Malayo-Polynesian languages           | plf            |                |                
Central Masela                                | mxz            |                |                
Central Mashan Hmong                          | hmm            |                |                
Central Mazahua                               | maz            |                |                
Central Melanau                               | mel            |                |                
Central Mnong                                 | cmo            |                |                
Central Nahuatl                               | nhn            |                |                
Central Nicobarese                            | ncb            |                |                
Central Ojibwa                                | ojc            |                |                
Central Okinawan                              | ryu            |                |                
Central Palawano                              | plc            |                |                
Central Pame                                  | pbs            |                |                
Central Pashto                                | pst            |                |                
Central Pomo                                  | poo            |                |                
Central Puebla Nahuatl                        | ncx            |                |                
Central Sama                                  | sml            |                |                
Central Siberian Yupik                        | ess            |                |                
Central Sierra Miwok                          | csm            |                |                
Central Subanen                               | syb            |                |                
Central Sudanic languages                     | csu            |                |                
Central Tagbanwa                              | tgt            |                |                
Central Tarahumara                            | tar            |                |                
Central Tunebo                                | tuf            |                |                
Central Yupik                                 | esu            |                |                
Central-Eastern Niger Fulfulde                | fuq            |                |                
Centúúm                                       | cet            |                |                
Cerma                                         | cme            |                |                
Chabu                                         | sbf            |                |                
Chachapoyas Quechua                           | quk            |                |                
Chachi                                        | cbi            |                |                
Chadian Arabic                                | shu            |                |                
Chadian Sign Language                         | cds            |                |                
Chadic languages                              | cdc            |                |                
Chadong                                       | cdy            |                |                
Chagatai                                      | chg            |                |                
Chaima                                        | ciy            |                |                
Chak                                          | ckh            |                |                
Chakali                                       | cli            |                |                
Chakavian                                     | ckm            |                |                
Chakma                                        | ccp            |                |                
Chala                                         | cll            |                |                
Chaldean Neo-Aramaic                          | cld            |                |                
Chalikha                                      | tgf            |                |                
Chamacoco                                     | ceg            |                |                
Chamalal                                      | cji            |                |                
Chamari                                       | cdg            |                |                
Chambeali                                     | cdh            |                |                
Chambri                                       | can            |                |                
Chamic languages                              | cmc            |                |                
Chamicuro                                     | ccc            |                |                
Chamorro                                      | cha            | ch             |                
Chang Naga                                    | nbc            |                |                
Changriwa                                     | cga            |                |                
Changthang                                    | cna            |                |                
Chantyal                                      | chx            |                |                
Chané                                         | caj            |                |                
Chara                                         | cra            |                |                
Chaudangsi                                    | cdn            |                |                
Chaungtha                                     | ccq            |                |                
Chaura                                        | crv            |                |                
Chavacano                                     | cbk            |                |                
Chayahuita                                    | cbt            |                |                
Chayuco Mixtec                                | mih            |                |                
Chazumba Mixtec                               | xtb            |                |                
Che                                           | ruk            |                |                
Chechen                                       | che            | ce             |                
Cheke Holo                                    | mrn            |                |                
Chemakum                                      | xch            |                |                
Chenapian                                     | cjn            |                |                
Chenchu                                       | cde            |                |                
Chenoua                                       | cnu            |                |                
Chepang                                       | cdm            |                |                
Chepya                                        | ycp            |                |                
Cherepon                                      | cpn            |                |                
Cherokee                                      | chr            |                |                
Chesu                                         | ych            |                |                
Chetco                                        | ctc            |                |                
Chewong                                       | cwg            |                |                
Cheyenne                                      | chy            |                |                
Chhattisgarhi                                 | hne            |                |                
Chhintange                                    | ctn            |                |                
Chhulung                                      | cur            |                |                
Chiangmai Sign Language                       | csd            |                |                
Chiapanec                                     | cip            |                |                
Chibcha                                       | chb            |                |                
Chibchan languages                            | cba            |                |                
Chicahuaxtla Triqui                           | trs            |                |                
Chichicapan Zapotec                           | zpv            |                |                
Chichimeca-Jonaz                              | pei            |                |                
Chickasaw                                     | cic            |                |                
Chicomuceltec                                 | cob            |                |                
Chiga                                         | cgg            |                |                
Chigmecatitlán Mixtec                         | mii            |                |                
Chilcotin                                     | clc            |                |                
Chilean Quechua                               | cqu            |                |                
Chilean Sign Language                         | csg            |                |                
Chilisso                                      | clh            |                |                
Chiltepec Chinantec                           | csa            |                |                
Chimakum                                      | cmk            |                |                
Chimalapa Zoque                               | zoh            |                |                
Chimariko                                     | cid            |                |                
Chimborazo Highland Quichua                   | qug            |                |                
Chimila                                       | cbg            |                |                
China Buriat                                  | bxu            |                |                
Chinali                                       | cih            |                |                
Chinbon Chin                                  | cnb            |                |                
Chincha Quechua                               | qxc            |                |                
Chinese (family)                              | zhx            |                |                
Chinese Pidgin English                        | cpi            |                |                
Chinese Sign Language                         | csl            |                |                
Chinese                                       | chi            | zh             | zho            
Chinook jargon                                | chn            |                |                
Chinook                                       | chh            |                |                
Chipaya                                       | cap            |                |                
Chipewyan                                     | chp            |                |                
Chipiajes                                     | cbe            |                |                
Chippewa                                      | ciw            |                |                
Chiquihuitlán Mazatec                         | maq            |                |                
Chiquitano                                    | cax            |                |                
Chiquián Ancash Quechua                       | qxa            |                |                
Chiripá                                       | nhd            |                |                
Chiru                                         | cdf            |                |                
Chitimacha                                    | ctm            |                |                
Chitkuli Kinnauri                             | cik            |                |                
Chittagonian                                  | ctg            |                |                
Chitwania Tharu                               | the            |                |                
Choapan Zapotec                               | zpc            |                |                
Chocangacakha                                 | cgk            |                |                
Chochotec                                     | coz            |                |                
Choctaw                                       | cho            |                |                
Chodri                                        | cdi            |                |                
Chokri Naga                                   | nri            |                |                
Chokwe                                        | cjk            |                |                
Chol                                          | ctu            |                |                
Cholón                                        | cht            |                |                
Chong                                         | cog            |                |                
Choni                                         | cda            |                |                
Chonyi-Dzihana-Kauma                          | coh            |                |                
Chopi                                         | cce            |                |                
Chorasmian                                    | xco            |                |                
Chorotega                                     | cjr            |                |                
Chortí                                        | caa            |                |                
Chothe Naga                                   | nct            |                |                
Chrau                                         | crw            |                |                
Chru                                          | cje            |                |                
Chuanqiandian Cluster Miao                    | cqd            |                |                
Chuave                                        | cjv            |                |                
Chug                                          | cvg            |                |                
Chuj                                          | cac            |                |                
Chuka                                         | cuh            |                |                
Chukot                                        | ckt            |                |                
Chukwa                                        | cuw            |                |                
Chulym                                        | clw            |                |                
Chumburung                                    | ncu            |                |                
Chung                                         | cnq            |                |                
Churahi                                       | cdj            |                |                
Church Slavic                                 | chu            | cu             |                
Chut                                          | scb            |                |                
Chuukese                                      | chk            |                |                
Chuvantsy                                     | xcv            |                |                
Chuvash                                       | chv            | cv             |                
Chuwabu                                       | chw            |                |                
Chácobo                                       | cao            |                |                
Ci Gbe                                        | cib            |                |                
Cia-Cia                                       | cia            |                |                
Cibak                                         | ckl            |                |                
Cicipu                                        | awc            |                |                
Cimbrian                                      | cim            |                |                
Cinda-Regi-Tiyal                              | cdr            |                |                
Cineni                                        | cie            |                |                
Cinta Larga                                   | cin            |                |                
Cisalpine Gaulish                             | xcg            |                |                
Cishingini                                    | asg            |                |                
Citak                                         | txt            |                |                
Ciwogai                                       | tgd            |                |                
Clallam                                       | clm            |                |                
Classical Armenian                            | xcl            |                |                
Classical Mandaic                             | myz            |                |                
Classical Mongolian                           | cmg            |                |                
Classical Nahuatl                             | nci            |                |                
Classical Newari                              | nwc            |                |                
Classical Quechua                             | qwc            |                |                
Classical Syriac                              | syc            |                |                
Classical Tibetan                             | xct            |                |                
Coahuilteco                                   | xcw            |                |                
Coast Miwok                                   | csi            |                |                
Coastal Kadazan                               | kzj            |                |                
Coastal Konjo                                 | kjc            |                |                
Coatecas Altas Zapotec                        | zca            |                |                
Coatepec Nahuatl                              | naz            |                |                
Coatlán Mixe                                  | mco            |                |                
Coatlán Zapotec                               | zps            |                |                
Coatzospan Mixtec                             | miz            |                |                
Cocama-Cocamilla                              | cod            |                |                
Cochimi                                       | coj            |                |                
Cocopa                                        | coc            |                |                
Cocos Islands Malay                           | coa            |                |                
Coeur d'Alene                                 | crd            |                |                
Cofán                                         | con            |                |                
Cogui                                         | kog            |                |                
Col                                           | liw            |                |                
Colombian Sign Language                       | csn            |                |                
Colonia Tovar German                          | gct            |                |                
Colorado                                      | cof            |                |                
Columbia-Wenatchi                             | col            |                |                
Comaltepec Chinantec                          | cco            |                |                
Comanche                                      | com            |                |                
Comecrudo                                     | xcm            |                |                
Como Karim                                    | cfg            |                |                
Comox                                         | coo            |                |                
Con                                           | cno            |                |                
Congo Swahili                                 | swc            |                |                
Coos                                          | csz            |                |                
Copainalá Zoque                               | zoc            |                |                
Copala Triqui                                 | trc            |                |                
Coptic                                        | cop            |                |                
Coquille                                      | coq            |                |                
Cori                                          | cry            |                |                
Cornish                                       | cor            | kw             |                
Corongo Ancash Quechua                        | qwa            |                |                
Corsican                                      | cos            | co             |                
Costa Rican Sign Language                     | csr            |                |                
Cotabato Manobo                               | mta            |                |                
Cotoname                                      | xcn            |                |                
Cowlitz                                       | cow            |                |                
Coxima                                        | kox            |                |                
Coyaima                                       | coy            |                |                
Coyotepec Popoloca                            | pbf            |                |                
Coyutla Totonac                               | toc            |                |                
Cree                                          | cre            | cr             |                
Creek                                         | mus            |                |                
Creoles and pidgins                           | crp            |                |                
Creoles and pidgins, English based            | cpe            |                |                
Creoles and pidgins, French-based             | cpf            |                |                
Creoles and pidgins, Portuguese-based         | cpp            |                |                
Crimean Tatar                                 | crh            |                |                
Croatia Sign Language                         | csq            |                |                
Croatian                                      | hrv            | hr             |                
Cross River Mbembe                            | mfn            |                |                
Crow                                          | cro            |                |                
Cruzeño                                       | crz            |                |                
Cua                                           | cua            |                |                
Cuba Sign Language                            | csf            |                |                
Cubeo                                         | cub            |                |                
Cuiba                                         | cui            |                |                
Cuitlatec                                     | cuy            |                |                
Culina                                        | cul            |                |                
Cumanagoto                                    | cuo            |                |                
Cumbric                                       | xcb            |                |                
Cumeral                                       | cum            |                |                
Cun                                           | cuq            |                |                
Cuneiform Luwian                              | xlu            |                |                
Cung                                          | cug            |                |                
Cupeño                                        | cup            |                |                
Curonian                                      | xcu            |                |                
Curripaco                                     | kpc            |                |                
Cusco Quechua                                 | quz            |                |                
Cushitic languages                            | cus            |                |                
Cutchi-Swahili                                | ccl            |                |                
Cuvok                                         | cuv            |                |                
Cuyamecalco Mixtec                            | xtu            |                |                
Cuyonon                                       | cyo            |                |                
Cwi Bwamu                                     | bwy            |                |                
Cypriot Arabic                                | acy            |                |                
Czech Sign Language                           | cse            |                |                
Czech                                         | cze            | cs             | ces            
Côông                                         | cnc            |                |                
Da'a Kaili                                    | kzf            |                |                
Daai Chin                                     | dao            |                |                
Daakaka                                       | bpa            |                |                
Daantanai'                                    | lni            |                |                
Daasanach                                     | dsh            |                |                
Daatsʼíin                                     | dtn            |                |                
Daba                                          | dbq            |                |                
Dabarre                                       | dbr            |                |                
Dabe                                          | dbe            |                |                
Dacian                                        | xdc            |                |                
Dadi Dadi                                     | dda            |                |                
Dadibi                                        | mps            |                |                
Dadiya                                        | dbd            |                |                
Daga                                          | dgz            |                |                
Dagaari Dioula                                | dgd            |                |                
Dagba                                         | dgk            |                |                
Dagbani                                       | dag            |                |                
Dagik                                         | dec            |                |                
Dagoman                                       | dgn            |                |                
Dahalik                                       | dlk            |                |                
Dahalo                                        | dal            |                |                
Daho-Doo                                      | das            |                |                
Dai Zhuang                                    | zhd            |                |                
Dai                                           | dij            |                |                
Dair                                          | drb            |                |                
Dakka                                         | dkk            |                |                
Dakota                                        | dak            |                |                
Dakpakha                                      | dka            |                |                
Dalabon                                       | ngk            |                |                
Dalmatian                                     | dlm            |                |                
Daloa Bété                                    | bev            |                |                
Dama                                          | dmm            |                |                
Damakawa                                      | dam            |                |                
Damal                                         | uhn            |                |                
Dambi                                         | dac            |                |                
Dameli                                        | dml            |                |                
Dampelas                                      | dms            |                |                
Dan                                           | daf            |                |                
Dan                                           | dnj            |                |                
Danaru                                        | dnr            |                |                
Danau                                         | dnu            |                |                
Dandami Maria                                 | daq            |                |                
Dangaléat                                     | daa            |                |                
Dangaura Tharu                                | thl            |                |                
Danish Sign Language                          | dsl            |                |                
Danish                                        | dan            | da             |                
Dano                                          | aso            |                |                
Danu                                          | dnv            |                |                
Dao                                           | daz            |                |                
Daonda                                        | dnd            |                |                
Dar Daju Daju                                 | djc            |                |                
Dar Fur Daju                                  | daj            |                |                
Dar Sila Daju                                 | dau            |                |                
Darai                                         | dry            |                |                
Dargwa                                        | dar            |                |                
Dari                                          | prs            |                |                
Darkhat                                       | drh            |                |                
Darkinyung                                    | xda            |                |                
Darlong                                       | dln            |                |                
Darmiya                                       | drd            |                |                
Daro-Matu Melanau                             | dro            |                |                
Darwazi                                       | drw            |                |                
Dass                                          | dot            |                |                
Datooga                                       | tcc            |                |                
Daungwurrung                                  | dgw            |                |                
Daur                                          | dta            |                |                
Davawenyo                                     | daw            |                |                
Dawawa                                        | dww            |                |                
Dawera-Daweloor                               | ddw            |                |                
Dawik Kui                                     | dwk            |                |                
Dawro                                         | dwr            |                |                
Day                                           | dai            |                |                
Dayi                                          | dax            |                |                
Daza                                          | dzd            |                |                
Dazaga                                        | dzg            |                |                
Deccan                                        | dcc            |                |                
Dedua                                         | ded            |                |                
Defaka                                        | afn            |                |                
Defi Gbe                                      | gbh            |                |                
Deg                                           | mzw            |                |                
Degaru                                        | dgu            |                |                
Degema                                        | deg            |                |                
Degenan                                       | dge            |                |                
Degexit'an                                    | ing            |                |                
Dehu                                          | dhv            |                |                
Dehwari                                       | deh            |                |                
Dek                                           | dek            |                |                
Dela-Oenale                                   | row            |                |                
Delaware                                      | del            |                |                
Delo                                          | ntr            |                |                
Dem                                           | dem            |                |                
Dema                                          | dmx            |                |                
Demisa                                        | dei            |                |                
Demta                                         | dmy            |                |                
Dendi (Benin)                                 | ddn            |                |                
Dendi (Central African Republic)              | deq            |                |                
Dengese                                       | dez            |                |                
Dengka                                        | dnk            |                |                
Deno                                          | dbb            |                |                
Denya                                         | anv            |                |                
Dení                                          | dny            |                |                
Deori                                         | der            |                |                
Dera (Indonesia)                              | kbv            |                |                
Dera (Nigeria)                                | kna            |                |                
Desano                                        | des            |                |                
Desiya                                        | dso            |                |                
Dewas Rai                                     | dwz            |                |                
Dewoin                                        | dee            |                |                
Dezfuli                                       | def            |                |                
Dghwede                                       | dgh            |                |                
Dhaiso                                        | dhs            |                |                
Dhalandji                                     | dhl            |                |                
Dhangu-Djangu                                 | dhg            |                |                
Dhanki                                        | dhn            |                |                
Dhanwar (India)                               | dha            |                |                
Dhanwar (Nepal)                               | dhw            |                |                
Dhao                                          | nfa            |                |                
Dharawal                                      | tbh            |                |                
Dhargari                                      | dhr            |                |                
Dharuk                                        | xdk            |                |                
Dharumbal                                     | xgm            |                |                
Dhatki                                        | mki            |                |                
Dhimal                                        | dhi            |                |                
Dhivehi                                       | div            | dv             |                
Dhodia                                        | dho            |                |                
Dhofari Arabic                                | adf            |                |                
Dhudhuroa                                     | ddr            |                |                
Dhundari                                      | dhd            |                |                
Dhungaloo                                     | dhx            |                |                
Dhurga                                        | dhu            |                |                
Dhuwal                                        | duj            |                |                
Dhuwal                                        | dwu            |                |                
Dhuwaya                                       | dwy            |                |                
Dia                                           | dia            |                |                
Dibabawon Manobo                              | mbd            |                |                
Dibiyaso                                      | dby            |                |                
Dibo                                          | dio            |                |                
Dibole                                        | bvx            |                |                
Dicamay Agta                                  | duy            |                |                
Didinga                                       | did            |                |                
Dido                                          | ddo            |                |                
Dieri                                         | dif            |                |                
Digaro-Mishmi                                 | mhu            |                |                
Digo                                          | dig            |                |                
Dii                                           | dur            |                |                
Dijim-Bwilim                                  | cfa            |                |                
Dilling                                       | dil            |                |                
Dima                                          | jma            |                |                
Dimasa                                        | dis            |                |                
Dimbong                                       | dii            |                |                
Dime                                          | dim            |                |                
Dimli (individual language)                   | diq            |                |                
Ding                                          | diz            |                |                
Dinka                                         | din            |                |                
Dirari                                        | dit            |                |                
Dirasha                                       | gdl            |                |                
Diri                                          | dwa            |                |                
Diriku                                        | diu            |                |                
Dirim                                         | dir            |                |                
Disa                                          | dsi            |                |                
Ditammari                                     | tbz            |                |                
Ditidaht                                      | dtd            |                |                
Diuwe                                         | diy            |                |                
Diuxi-Tilantongo Mixtec                       | xtd            |                |                
Dixon Reef                                    | dix            |                |                
Dizin                                         | mdx            |                |                
Djabugay                                      | dyy            |                |                
Djabwurrung                                   | tjw            |                |                
Djadjawurrung                                 | dja            |                |                
Djambarrpuyngu                                | djr            |                |                
Djamindjung                                   | djd            |                |                
Djangun                                       | djf            |                |                
Djawi                                         | djw            |                |                
Djeebbana                                     | djj            |                |                
Djimini Senoufo                               | dyi            |                |                
Djinang                                       | dji            |                |                
Djinba                                        | djb            |                |                
Djiwarli                                      | djl            |                |                
Djiwarli                                      | dze            |                |                
Dobel                                         | kvo            |                |                
Dobu                                          | dob            |                |                
Doe                                           | doe            |                |                
Doga                                          | dgg            |                |                
Doghoro                                       | dgx            |                |                
Dogoso                                        | dgs            |                |                
Dogosé                                        | dos            |                |                
Dogri (individual language)                   | dgo            |                |                
Dogri (macrolanguage)                         | doi            |                |                
Dogrib                                        | dgr            |                |                
Dogul Dom Dogon                               | dbg            |                |                
Doka                                          | dbi            |                |                
Doko-Uyanga                                   | uya            |                |                
Dolgan                                        | dlg            |                |                
Dolpo                                         | dre            |                |                
Dom                                           | doa            |                |                
Domaaki                                       | dmk            |                |                
Domari                                        | rmt            |                |                
Dombe                                         | dov            |                |                
Dominican Sign Language                       | doq            |                |                
Dompo                                         | doy            |                |                
Domu                                          | dof            |                |                
Domung                                        | dev            |                |                
Dondo                                         | dok            |                |                
Dong                                          | doh            |                |                
Dongo                                         | doo            |                |                
Dongotono                                     | ddd            |                |                
Dongshanba Lalo                               | yik            |                |                
Dongxiang                                     | sce            |                |                
Donno So Dogon                                | dds            |                |                
Doondo                                        | dde            |                |                
Dori'o                                        | dor            |                |                
Doromu-Koki                                   | kqc            |                |                
Dororo                                        | drr            |                |                
Dorze                                         | doz            |                |                
Doso                                          | dol            |                |                
Dotyali                                       | dty            |                |                
Doutai                                        | tds            |                |                
Doyayo                                        | dow            |                |                
Dravidian languages                           | dra            |                |                
Drents                                        | drt            |                |                
Drung                                         | duu            |                |                
Duala                                         | dua            |                |                
Duano                                         | dup            |                |                
Duau                                          | dva            |                |                
Dubli                                         | dub            |                |                
Dubu                                          | dmu            |                |                
Dugun                                         | ndu            |                |                
Duguri                                        | dbm            |                |                
Dugwor                                        | dme            |                |                
Duhwa                                         | kbz            |                |                
Duke                                          | nke            |                |                
Dulbu                                         | dbo            |                |                
Duli-Gey                                      | duz            |                |                
Duma                                          | dma            |                |                
Dumbea                                        | duf            |                |                
Dumi                                          | dus            |                |                
Dumpas                                        | dmv            |                |                
Dumun                                         | dui            |                |                
Duna                                          | duc            |                |                
Dungan                                        | dng            |                |                
Dungmali                                      | raa            |                |                
Dungra Bhil                                   | duh            |                |                
Dungu                                         | dbv            |                |                
Dupaninan Agta                                | duo            |                |                
Dura                                          | drq            |                |                
Durango Nahuatl                               | nln            |                |                
Duri                                          | mvp            |                |                
Duriankere                                    | dbn            |                |                
Duruma                                        | dug            |                |                
Duruwa                                        | pci            |                |                
Dusner                                        | dsn            |                |                
Dusun Deyah                                   | dun            |                |                
Dusun Malang                                  | duq            |                |                
Dusun Witu                                    | duw            |                |                
Dutch Sign Language                           | dse            |                |                
Dutch                                         | dut            | nl             | nld            
Dutton World Speedwords                       | dws            |                |                
Duungooma                                     | dux            |                |                
Duupa                                         | dae            |                |                
Duvle                                         | duv            |                |                
Duwai                                         | dbp            |                |                
Duwet                                         | gve            |                |                
Dũya                                          | ldb            |                |                
Dwang                                         | nnu            |                |                
Dyaberdyaber                                  | dyb            |                |                
Dyan                                          | dya            |                |                
Dyangadi                                      | dyn            |                |                
Dyirbal                                       | dbl            |                |                
Dyugun                                        | dyd            |                |                
Dyula                                         | dyu            |                |                
Dza                                           | jen            |                |                
Dzalakha                                      | dzl            |                |                
Dzando                                        | dzn            |                |                
Dzao Min                                      | bpn            |                |                
Dzongkha                                      | dzo            | dz             |                
Dzùùngoo                                      | dnn            |                |                
Dâw                                           | kwa            |                |                
E                                             | eee            |                |                
E'ma Buyang                                   | yzg            |                |                
E'ñapa Woromaipu                              | pbh            |                |                
Early Tripuri                                 | xtr            |                |                
East Ambae                                    | omb            |                |                
East Berawan                                  | zbe            |                |                
East Damar                                    | dmr            |                |                
East Futuna                                   | fud            |                |                
East Germanic languages                       | gme            |                |                
East Kewa                                     | kjs            |                |                
East Limba                                    | lma            |                |                
East Makian                                   | mky            |                |                
East Masela                                   | vme            |                |                
East Nyala                                    | nle            |                |                
East Slavic languages                         | zle            |                |                
East Tarangan                                 | tre            |                |                
East Yugur                                    | yuy            |                |                
Eastern Abnaki                                | aaq            |                |                
Eastern Acipa                                 | acp            |                |                
Eastern Apurímac Quechua                      | qve            |                |                
Eastern Arrernte                              | aer            |                |                
Eastern Balochi                               | bgp            |                |                
Eastern Bolivian Guaraní                      | gui            |                |                
Eastern Bontok                                | ebk            |                |                
Eastern Bru                                   | bru            |                |                
Eastern Canadian Inuktitut                    | ike            |                |                
Eastern Cham                                  | cjm            |                |                
Eastern Durango Nahuatl                       | azd            |                |                
Eastern Egyptian Bedawi Arabic                | avl            |                |                
Eastern Frisian                               | frs            |                |                
Eastern Gorkha Tamang                         | tge            |                |                
Eastern Gurung                                | ggn            |                |                
Eastern Highland Chatino                      | cly            |                |                
Eastern Highland Otomi                        | otm            |                |                
Eastern Hongshuihe Zhuang                     | zeh            |                |                
Eastern Huasteca Nahuatl                      | nhe            |                |                
Eastern Huishui Hmong                         | hme            |                |                
Eastern Karaboro                              | xrb            |                |                
Eastern Karnic                                | ekc            |                |                
Eastern Katu                                  | ktv            |                |                
Eastern Kayah                                 | eky            |                |                
Eastern Keres                                 | kee            |                |                
Eastern Khumi Chin                            | cek            |                |                
Eastern Krahn                                 | kqo            |                |                
Eastern Lalu                                  | yit            |                |                
Eastern Lawa                                  | lwl            |                |                
Eastern Magar                                 | mgp            |                |                
Eastern Malayo-Polynesian languages           | pqe            |                |                
Eastern Maninkakan                            | emk            |                |                
Eastern Mari                                  | mhr            |                |                
Eastern Maroon Creole                         | djk            |                |                
Eastern Meohang                               | emg            |                |                
Eastern Minyag                                | emq            |                |                
Eastern Mnong                                 | mng            |                |                
Eastern Muria                                 | emu            |                |                
Eastern Ngad'a                                | nea            |                |                
Eastern Nisu                                  | nos            |                |                
Eastern Ojibwa                                | ojg            |                |                
Eastern Oromo                                 | hae            |                |                
Eastern Parbate Kham                          | kif            |                |                
Eastern Penan                                 | pez            |                |                
Eastern Pomo                                  | peb            |                |                
Eastern Qiandong Miao                         | hmq            |                |                
Eastern Subanen                               | sfe            |                |                
Eastern Sudanic languages                     | sdv            |                |                
Eastern Tamang                                | taj            |                |                
Eastern Tawbuid                               | bnj            |                |                
Eastern Xiangxi Miao                          | muq            |                |                
Eastern Xwla Gbe                              | gbx            |                |                
Eastern Yiddish                               | ydd            |                |                
Ebira                                         | igb            |                |                
Eblan                                         | xeb            |                |                
Ebrié                                         | ebr            |                |                
Ebughu                                        | ebg            |                |                
Ecuadorian Sign Language                      | ecs            |                |                
Ede Cabe                                      | cbj            |                |                
Ede Ica                                       | ica            |                |                
Ede Idaca                                     | idd            |                |                
Ede Ije                                       | ijj            |                |                
Edera Awyu                                    | awy            |                |                
Edolo                                         | etr            |                |                
Edomite                                       | xdm            |                |                
Edopi                                         | dbf            |                |                
Efai                                          | efa            |                |                
Efe                                           | efe            |                |                
Efik                                          | efi            |                |                
Efutop                                        | ofu            |                |                
Ega                                           | ega            |                |                
Eggon                                         | ego            |                |                
Egypt Sign Language                           | esl            |                |                
Egyptian (Ancient)                            | egy            |                |                
Egyptian Arabic                               | arz            |                |                
Egyptian languages                            | egx            |                |                
Ehueun                                        | ehu            |                |                
Eipomek                                       | eip            |                |                
Eitiep                                        | eit            |                |                
Ejagham                                       | etu            |                |                
Ejamat                                        | eja            |                |                
Ekai Chin                                     | cey            |                |                
Ekajuk                                        | eka            |                |                
Ekari                                         | ekg            |                |                
Eki                                           | eki            |                |                
Ekit                                          | eke            |                |                
Ekpeye                                        | ekp            |                |                
El Alto Zapotec                               | zpp            |                |                
El Hugeirat                                   | elh            |                |                
El Molo                                       | elo            |                |                
El Nayar Cora                                 | crn            |                |                
Elamite                                       | elx            |                |                
Eleme                                         | elm            |                |                
Elepi                                         | ele            |                |                
Elfdalian                                     | ovd            |                |                
Elip                                          | ekm            |                |                
Elkei                                         | elk            |                |                
Elotepec Zapotec                              | zte            |                |                
Eloyi                                         | afo            |                |                
Elpaputih                                     | elp            |                |                
Elseng                                        | mrf            |                |                
Elu                                           | elu            |                |                
Elymian                                       | xly            |                |                
Emae                                          | mmw            |                |                
Emai-Iuleha-Ora                               | ema            |                |                
Eman                                          | emn            |                |                
Embaloh                                       | emb            |                |                
Emberá-Baudó                                  | bdc            |                |                
Emberá-Catío                                  | cto            |                |                
Emberá-Chamí                                  | cmi            |                |                
Emberá-Tadó                                   | tdc            |                |                
Embu                                          | ebu            |                |                
Emerillon                                     | eme            |                |                
Emilian                                       | egl            |                |                
Emok                                          | emo            |                |                
Emplawas                                      | emw            |                |                
Emumu                                         | enr            |                |                
En                                            | enc            |                |                
Enawené-Nawé                                  | unk            |                |                
Ende                                          | end            |                |                
Enga                                          | enq            |                |                
Engdewu                                       | ngr            |                |                
Engenni                                       | enn            |                |                
Enggano                                       | eno            |                |                
English                                       | eng            | en             |                
Enlhet                                        | enl            |                |                
Enrekang                                      | ptt            |                |                
Enu                                           | enu            |                |                
Enwan (Akwa Ibom State)                       | enw            |                |                
Enwan (Edo State)                             | env            |                |                
Enxet                                         | enx            |                |                
Enya                                          | gey            |                |                
Epena                                         | sja            |                |                
Epi-Olmec                                     | xep            |                |                
Epie                                          | epi            |                |                
Epigraphic Mayan                              | emy            |                |                
Eravallan                                     | era            |                |                
Erave                                         | kjy            |                |                
Ere                                           | twp            |                |                
Eritai                                        | ert            |                |                
Erokwanas                                     | erw            |                |                
Erre                                          | err            |                |                
Erromintxela                                  | emx            |                |                
Ersu                                          | ers            |                |                
Eruwa                                         | erh            |                |                
Erzya                                         | myv            |                |                
Esan                                          | ish            |                |                
Ese Ejja                                      | ese            |                |                
Ese                                           | mcq            |                |                
Eshtehardi                                    | esh            |                |                
Esimbi                                        | ags            |                |                
Eskayan                                       | esy            |                |                
Eskimo-Aleut languages                        | esx            |                |                
Esperanto                                     | epo            | eo             |                
Esselen                                       | esq            |                |                
Estado de México Otomi                        | ots            |                |                
Estonian Sign Language                        | eso            |                |                
Estonian                                      | est            | et             |                
Esuma                                         | esm            |                |                
Etchemin                                      | etc            |                |                
Etebi                                         | etb            |                |                
Eten                                          | etx            |                |                
Eteocretan                                    | ecr            |                |                
Eteocypriot                                   | ecy            |                |                
Ethiopian Sign Language                       | eth            |                |                
Etkywan                                       | ich            |                |                
Eton (Cameroon)                               | eto            |                |                
Eton (Vanuatu)                                | etn            |                |                
Etruscan                                      | ett            |                |                
Etulo                                         | utr            |                |                
Evant                                         | bzz            |                |                
Even                                          | eve            |                |                
Evenki                                        | evn            |                |                
Eviya                                         | gev            |                |                
Ewage-Notu                                    | nou            |                |                
Ewe                                           | ewe            | ee             |                
Ewondo                                        | ewo            |                |                
Extremaduran                                  | ext            |                |                
Eyak                                          | eya            |                |                
Ezaa                                          | eza            |                |                
Fa d'Ambu                                     | fab            |                |                
Fagani                                        | faf            |                |                
Faifi                                         | fif            |                |                
Faire Atta                                    | azt            |                |                
Faita                                         | faj            |                |                
Faiwol                                        | fai            |                |                
Fala                                          | fax            |                |                
Falam Chin                                    | cfm            |                |                
Fali                                          | fli            |                |                
Faliscan                                      | xfa            |                |                
Fam                                           | fam            |                |                
Fanagalo                                      | fng            |                |                
Fanamaket                                     | bjp            |                |                
Fanbak                                        | fnb            |                |                
Fang (Cameroon)                               | fak            |                |                
Fang (Equatorial Guinea)                      | fan            |                |                
Fania                                         | fni            |                |                
Fanti                                         | fat            |                |                
Far Western Muria                             | fmu            |                |                
Farefare                                      | gur            |                |                
Faroese                                       | fao            | fo             |                
Fas                                           | fqs            |                |                
Fasu                                          | faa            |                |                
Fataleka                                      | far            |                |                
Fataluku                                      | ddg            |                |                
Fayu                                          | fau            |                |                
Fe'fe'                                        | fmp            |                |                
Fembe                                         | agl            |                |                
Fernando Po Creole English                    | fpe            |                |                
Feroge                                        | fer            |                |                
Fiji Hindi                                    | hif            |                |                
Fijian                                        | fij            | fj             |                
Filipino                                      | fil            |                |                
Filomena Mata-Coahuitlán Totonac              | tlp            |                |                
Finallig                                      | bkb            |                |                
Finland-Swedish Sign Language                 | fss            |                |                
Finnish Sign Language                         | fse            |                |                
Finnish                                       | fin            | fi             |                
Finno-Ugrian languages                        | fiu            |                |                
Finongan                                      | fag            |                |                
Fipa                                          | fip            |                |                
Firan                                         | fir            |                |                
Fiwaga                                        | fiw            |                |                
Flaaitaal                                     | fly            |                |                
Flinders Island                               | fln            |                |                
Foau                                          | flh            |                |                
Foi                                           | foi            |                |                
Foia Foia                                     | ffi            |                |                
Folopa                                        | ppo            |                |                
Foma                                          | fom            |                |                
Fon                                           | fon            |                |                
Fongoro                                       | fgr            |                |                
Foodo                                         | fod            |                |                
Forak                                         | frq            |                |                
Fordata                                       | frd            |                |                
Fore                                          | for            |                |                
Forest Enets                                  | enf            |                |                
Forest Maninka                                | myq            |                |                
Formosan languages                            | fox            |                |                
Fortsenal                                     | frt            |                |                
Francisco León Zoque                          | zos            |                |                
Frankish                                      | frk            |                |                
French Sign Language                          | fsl            |                |                
French                                        | fre            | fr             | fra            
Friulian                                      | fur            |                |                
Fulah                                         | ful            | ff             |                
Fuliiru                                       | flr            |                |                
Fulniô                                        | fun            |                |                
Fum                                           | fum            |                |                
Fungwa                                        | ula            |                |                
Fur                                           | fvr            |                |                
Furu                                          | fuu            |                |                
Futuna-Aniwa                                  | fut            |                |                
Fuyug                                         | fuy            |                |                
Fwe                                           | fwe            |                |                
Fwâi                                          | fwa            |                |                
Fyam                                          | pym            |                |                
Fyer                                          | fie            |                |                
Ga                                            | gaa            |                |                
Ga'anda                                       | gqa            |                |                
Ga'dang                                       | gdg            |                |                
Gaa                                           | ttb            |                |                
Gaam                                          | tbi            |                |                
Gabi-Gabi                                     | gbw            |                |                
Gabri                                         | gab            |                |                
Gabrielino-Fernandeño                         | xgf            |                |                
Gabutamon                                     | gav            |                |                
Gadang                                        | gdk            |                |                
Gaddang                                       | gad            |                |                
Gaddi                                         | gbk            |                |                
Gade Lohar                                    | gda            |                |                
Gade                                          | ged            |                |                
Gadjerawang                                   | gdh            |                |                
Gadsup                                        | gaj            |                |                
Gafat                                         | gft            |                |                
Gagadu                                        | gbu            |                |                
Gagauz                                        | gag            |                |                
Gagnoa Bété                                   | btg            |                |                
Gagu                                          | ggu            |                |                
Gahri                                         | bfu            |                |                
Gaikundi                                      | gbf            |                |                
Gail                                          | gic            |                |                
Gaina                                         | gcn            |                |                
Gal                                           | gap            |                |                
Galambu                                       | glo            |                |                
Galatian                                      | xga            |                |                
Galela                                        | gbi            |                |                
Galeya                                        | gar            |                |                
Galibi Carib                                  | car            |                |                
Galice                                        | gce            |                |                
Galician                                      | glg            | gl             |                
Galindan                                      | xgl            |                |                
Gallurese Sardinian                           | sdn            |                |                
Galo                                          | adl            |                |                
Galolen                                       | gal            |                |                
Gamale Kham                                   | kgj            |                |                
Gambera                                       | gma            |                |                
Gambian Wolof                                 | wof            |                |                
Gamilaraay                                    | kld            |                |                
Gamit                                         | gbl            |                |                
Gamkonora                                     | gak            |                |                
Gamo                                          | gmv            |                |                
Gamo-Ningi                                    | bte            |                |                
Gan Chinese                                   | gan            |                |                
Gana                                          | gnq            |                |                
Ganang                                        | gne            |                |                
Ganda                                         | lug            | lg             |                
Gane                                          | gzn            |                |                
Ganggalida                                    | gcd            |                |                
Ganglau                                       | ggl            |                |                
Gangte                                        | gnb            |                |                
Gangulu                                       | gnl            |                |                
Gants                                         | gao            |                |                
Ganza                                         | gza            |                |                
Ganzi                                         | gnz            |                |                
Gao                                           | gga            |                |                
Gapapaiwa                                     | pwg            |                |                
Garawa                                        | gbc            |                |                
Garhwali                                      | gbm            |                |                
Garifuna                                      | cab            |                |                
Garig-Ilgar                                   | ilg            |                |                
Garingbal                                     | xgi            |                |                
Garlali                                       | gll            |                |                
Garo                                          | grt            |                |                
Garre                                         | gex            |                |                
Garrwa                                        | wrk            |                |                
Garus                                         | gyb            |                |                
Garza                                         | xgr            |                |                
Gata'                                         | gaq            |                |                
Gavak                                         | dmc            |                |                
Gavar                                         | gou            |                |                
Gavião Do Jiparaná                            | gvo            |                |                
Gawar-Bati                                    | gwt            |                |                
Gawri                                         | gwc            |                |                
Gawwada                                       | gwd            |                |                
Gayil                                         | gyl            |                |                
Gayo                                          | gay            |                |                
Gazi                                          | gzi            |                |                
Gaɓogbo                                       | gie            |                |                
Gbagyi                                        | gbr            |                |                
Gbanu                                         | gbv            |                |                
Gbanziri                                      | gbg            |                |                
Gbari                                         | gby            |                |                
Gbati-ri                                      | gti            |                |                
Gbaya (Central African Republic)              | gba            |                |                
Gbaya (Sudan)                                 | krs            |                |                
Gbaya-Bossangoa                               | gbp            |                |                
Gbaya-Bozoum                                  | gbq            |                |                
Gbaya-Mbodomo                                 | gmm            |                |                
Gbayi                                         | gyg            |                |                
Gbesi Gbe                                     | gbs            |                |                
Gbii                                          | ggb            |                |                
Gbin                                          | xgb            |                |                
Gbiri-Niragu                                  | grh            |                |                
Gboloo Grebo                                  | gec            |                |                
Ge                                            | hmj            |                |                
Geba Karen                                    | kvq            |                |                
Gebe                                          | gei            |                |                
Gedaged                                       | gdd            |                |                
Gedeo                                         | drs            |                |                
Geez                                          | gez            |                |                
Geji                                          | gji            |                |                
Geji                                          | gyz            |                |                
Geko Karen                                    | ghk            |                |                
Gela                                          | nlg            |                |                
Gelao                                         | gio            |                |                
Geme                                          | geq            |                |                
Gen                                           | gej            |                |                
Gende                                         | gaf            |                |                
Gengle                                        | geg            |                |                
Georgian                                      | geo            | ka             | kat            
Gepo                                          | ygp            |                |                
Gera                                          | gew            |                |                
Gerai                                         | gef            |                |                
German Sign Language                          | gsg            |                |                
German                                        | ger            | de             | deu            
Germanic languages                            | gem            |                |                
Geruma                                        | gea            |                |                
Geser-Gorom                                   | ges            |                |                
Gey                                           | guv            |                |                
Ghadamès                                      | gha            |                |                
Ghanaian Pidgin English                       | gpe            |                |                
Ghanaian Sign Language                        | gse            |                |                
Ghandruk Sign Language                        | gds            |                |                
Ghanongga                                     | ghn            |                |                
Ghari                                         | gri            |                |                
Ghayavi                                       | bmk            |                |                
Gheg Albanian                                 | aln            |                |                
Ghera                                         | ghr            |                |                
Ghodoberi                                     | gdo            |                |                
Ghomara                                       | gho            |                |                
Ghomálá'                                      | bbj            |                |                
Ghotuo                                        | aaa            |                |                
Ghulfan                                       | ghl            |                |                
Giangan                                       | bgi            |                |                
Gibanawa                                      | gib            |                |                
Gidar                                         | gid            |                |                
Giiwo                                         | kks            |                |                
Gikyode                                       | acd            |                |                
Gilaki                                        | glk            |                |                
Gilbertese                                    | gil            |                |                
Gilima                                        | gix            |                |                
Gilyak                                        | niv            |                |                
Gimi (Eastern Highlands)                      | gim            |                |                
Gimi (West New Britain)                       | gip            |                |                
Gimme                                         | kmp            |                |                
Gimnime                                       | gmn            |                |                
Ginuman                                       | gnm            |                |                
Ginyanga                                      | ayg            |                |                
Girawa                                        | bbr            |                |                
Girirra                                       | gii            |                |                
Giryama                                       | nyf            |                |                
Githabul                                      | gih            |                |                
Gitonga                                       | toh            |                |                
Gitua                                         | ggt            |                |                
Gitxsan                                       | git            |                |                
Giyug                                         | giy            |                |                
Gizrra                                        | tof            |                |                
Glaro-Twabo                                   | glr            |                |                
Glavda                                        | glw            |                |                
Glio-Oubi                                     | oub            |                |                
Gnau                                          | gnu            |                |                
Goan Konkani                                  | gom            |                |                
Goaria                                        | gig            |                |                
Gobasi                                        | goi            |                |                
Gobu                                          | gox            |                |                
Godié                                         | god            |                |                
Godwari                                       | gdx            |                |                
Goemai                                        | ank            |                |                
Gofa                                          | gof            |                |                
Gogo                                          | gog            |                |                
Gogodala                                      | ggw            |                |                
Gokana                                        | gkn            |                |                
Gola                                          | gol            |                |                
Golin                                         | gvf            |                |                
Golpa                                         | lja            |                |                
Gondi                                         | gon            |                |                
Gone Dau                                      | goo            |                |                
Gongduk                                       | goe            |                |                
Gonja                                         | gjn            |                |                
Goo                                           | gov            |                |                
Gooniyandi                                    | gni            |                |                
Gor                                           | gqr            |                |                
Gorakor                                       | goc            |                |                
Gorap                                         | goq            |                |                
Goreng                                        | xgg            |                |                
Gorontalo                                     | gor            |                |                
Gorovu                                        | grq            |                |                
Gorowa                                        | gow            |                |                
Gothic                                        | got            |                |                
Goundo                                        | goy            |                |                
Gourmanchéma                                  | gux            |                |                
Gowlan                                        | goj            |                |                
Gowli                                         | gok            |                |                
Gowro                                         | gwf            |                |                
Gozarkhani                                    | goz            |                |                
Grangali                                      | nli            |                |                
Grass Koiari                                  | kbk            |                |                
Grebo                                         | grb            |                |                
Greek (ancient, -1453)                        | grc            |                |                
Greek (modern, 1453-)                         | gre            | el             | ell            
Greek Sign Language                           | gss            |                |                
Greek languages                               | grk            |                |                
Green Gelao                                   | giq            |                |                
Grenadian Creole English                      | gcl            |                |                
Gresi                                         | grs            |                |                
Groma                                         | gro            |                |                
Gronings                                      | gos            |                |                
Gros Ventre                                   | ats            |                |                
Gua                                           | gwx            |                |                
Guadeloupean Creole French                    | gcf            |                |                
Guahibo                                       | guh            |                |                
Guajajára                                     | gub            |                |                
Guajá                                         | gvj            |                |                
Guambiano                                     | gum            |                |                
Guana (Brazil)                                | gqn            |                |                
Guana (Paraguay)                              | gva            |                |                
Guanano                                       | gvc            |                |                
Guanche                                       | gnc            |                |                
Guanyinqiao                                   | jiq            |                |                
Guarani                                       | grn            | gn             |                
Guarayu                                       | gyr            |                |                
Guarequena                                    | gae            |                |                
Guatemalan Sign Language                      | gsm            |                |                
Guató                                         | gta            |                |                
Guayabero                                     | guo            |                |                
Gudang                                        | xgd            |                |                
Gudanji                                       | nji            |                |                
Gude                                          | gde            |                |                
Gudu                                          | gdu            |                |                
Guduf-Gava                                    | gdf            |                |                
Guerrero Amuzgo                               | amu            |                |                
Guerrero Nahuatl                              | ngu            |                |                
Guevea De Humboldt Zapotec                    | zpg            |                |                
Gugadj                                        | ggd            |                |                
Gugu Badhun                                   | gdc            |                |                
Gugu Warra                                    | wrw            |                |                
Gugubera                                      | kkp            |                |                
Guhu-Samane                                   | ghs            |                |                
Guianese Creole French                        | gcr            |                |                
Guibei Zhuang                                 | zgb            |                |                
Guiberoua Béte                                | bet            |                |                
Guibian Zhuang                                | zgn            |                |                
Guinea Kpelle                                 | gkp            |                |                
Guinean Sign Language                         | gus            |                |                
Guiqiong                                      | gqi            |                |                
Gujarati                                      | guj            | gu             |                
Gujari                                        | gju            |                |                
Gula (Central African Republic)               | kcm            |                |                
Gula (Chad)                                   | glu            |                |                
Gula Iro                                      | glj            |                |                
Gula'alaa                                     | gmb            |                |                
Gulay                                         | gvl            |                |                
Gule                                          | gly            |                |                
Gulf Arabic                                   | afb            |                |                
Guliguli                                      | gli            |                |                
Gumalu                                        | gmu            |                |                
Gumatj                                        | gnn            |                |                
Gumawana                                      | gvs            |                |                
Gumuz                                         | guk            |                |                
Gun                                           | guw            |                |                
Gundi                                         | gdi            |                |                
Gunditjmara                                   | gjm            |                |                
Gundungurra                                   | xrd            |                |                
Gungabula                                     | gyf            |                |                
Gungu                                         | rub            |                |                
Guntai                                        | gnt            |                |                
Gunwinggu                                     | gup            |                |                
Gunya                                         | gyy            |                |                
Gupa-Abawa                                    | gpa            |                |                
Gupapuyngu                                    | guf            |                |                
Guramalum                                     | grz            |                |                
Gurani                                        | hac            |                |                
Gurdjar                                       | gdj            |                |                
Gureng Gureng                                 | gnr            |                |                
Gurgula                                       | ggg            |                |                
Guriaso                                       | grx            |                |                
Gurindji Kriol                                | gjr            |                |                
Gurindji                                      | gue            |                |                
Gurmana                                       | gvm            |                |                
Guro                                          | goa            |                |                
Gurr-goni                                     | gge            |                |                
Gurung                                        | gvr            |                |                
Guruntum-Mbaaru                               | grd            |                |                
Gusii                                         | guz            |                |                
Gusilay                                       | gsl            |                |                
Guugu Yimidhirr                               | kky            |                |                
Guwa                                          | xgw            |                |                
Guwamu                                        | gwu            |                |                
Guya                                          | gka            |                |                
Guyanese Creole English                       | gyn            |                |                
Guyani                                        | gvy            |                |                
Gvoko                                         | ngs            |                |                
Gwa                                           | gwb            |                |                
Gwahatike                                     | dah            |                |                
Gwak                                          | jgk            |                |                
Gwamhi-Wuri                                   | bga            |                |                
Gwandara                                      | gwn            |                |                
Gweda                                         | grw            |                |                
Gweno                                         | gwe            |                |                
Gwere                                         | gwr            |                |                
Gwichʼin                                      | gwi            |                |                
Gyalsumdo                                     | gyo            |                |                
Gyele                                         | gyi            |                |                
Gyem                                          | gye            |                |                
Güilá Zapotec                                 | ztu            |                |                
Gāndhārī                                      | pgd            |                |                
Ha                                            | haq            |                |                
Habu                                          | hbu            |                |                
Hadiyya                                       | hdy            |                |                
Hadothi                                       | hoj            |                |                
Hadrami Arabic                                | ayh            |                |                
Hadrami                                       | xhd            |                |                
Hadza                                         | hts            |                |                
Haeke                                         | aek            |                |                
Hahon                                         | hah            |                |                
Haida                                         | hai            |                |                
Haigwai                                       | hgw            |                |                
Haiphong Sign Language                        | haf            |                |                
Haisla                                        | has            |                |                
Haitian Vodoun Culture Language               | hvc            |                |                
Haitian                                       | hat            | ht             |                
Haiǁom                                        | hgm            |                |                
Haji                                          | hji            |                |                
Hajong                                        | haj            |                |                
Hakha Chin                                    | cnh            |                |                
Hakka Chinese                                 | hak            |                |                
Hakö                                          | hao            |                |                
Halang Doan                                   | hld            |                |                
Halang                                        | hal            |                |                
Halbi                                         | hlb            |                |                
Halh Mongolian                                | khk            |                |                
Halia                                         | hla            |                |                
Halkomelem                                    | hur            |                |                
Hamap                                         | hmu            |                |                
Hamba                                         | hba            |                |                
Hamer-Banna                                   | amf            |                |                
Hamtai                                        | hmt            |                |                
Han                                           | haa            |                |                
Hanga Hundi                                   | wos            |                |                
Hanga                                         | hag            |                |                
Hangaza                                       | han            |                |                
Hani                                          | hni            |                |                
Hano                                          | lml            |                |                
Hanoi Sign Language                           | hab            |                |                
Hanunoo                                       | hnn            |                |                
Harami                                        | xha            |                |                
Harari                                        | har            |                |                
Harijan Kinnauri                              | kjo            |                |                
Haroi                                         | hro            |                |                
Harsusi                                       | hss            |                |                
Haruai                                        | tmd            |                |                
Haruku                                        | hrk            |                |                
Haryanvi                                      | bgc            |                |                
Harzani                                       | hrz            |                |                
Hasha                                         | ybj            |                |                
Hassaniyya                                    | mey            |                |                
Hatam                                         | had            |                |                
Hattic                                        | xht            |                |                
Hausa Sign Language                           | hsl            |                |                
Hausa                                         | hau            | ha             |                
Havasupai-Walapai-Yavapai                     | yuf            |                |                
Haveke                                        | hvk            |                |                
Havu                                          | hav            |                |                
Hawai'i Creole English                        | hwc            |                |                
Hawai'i Sign Language (HSL)                   | hps            |                |                
Hawaiian                                      | haw            |                |                
Haya                                          | hay            |                |                
Hazaragi                                      | haz            |                |                
Hdi                                           | xed            |                |                
Hebrew                                        | heb            | he             |                
Hehe                                          | heh            |                |                
Heiban                                        | hbn            |                |                
Heiltsuk                                      | hei            |                |                
Helong                                        | heg            |                |                
Hema                                          | nix            |                |                
Hemba                                         | hem            |                |                
Herdé                                         | hed            |                |                
Herero                                        | her            | hz             |                
Hermit                                        | llf            |                |                
Hernican                                      | xhr            |                |                
Hewa                                          | ham            |                |                
Heyo                                          | auk            |                |                
Hiberno-Scottish Gaelic                       | ghc            |                |                
Hibito                                        | hib            |                |                
Hidatsa                                       | hid            |                |                
Hieroglyphic Luwian                           | hlu            |                |                
Higaonon                                      | mba            |                |                
Highland Konjo                                | kjk            |                |                
Highland Oaxaca Chontal                       | chd            |                |                
Highland Popoluca                             | poi            |                |                
Highland Puebla Nahuatl                       | azz            |                |                
Highland Totonac                              | tos            |                |                
Hijazi Arabic                                 | acw            |                |                
Hijuk                                         | hij            |                |                
Hiligaynon                                    | hil            |                |                
Himachali languages; Western Pahari languages | him            |                |                
Himarimã                                      | hir            |                |                
Hindi                                         | hin            | hi             |                
Hinduri                                       | hii            |                |                
Hinukh                                        | gin            |                |                
Hiri Motu                                     | hmo            | ho             |                
Hittite                                       | hit            |                |                
Hitu                                          | htu            |                |                
Hiw                                           | hiw            |                |                
Hixkaryána                                    | hix            |                |                
Hlai                                          | lic            |                |                
Hlepho Phowa                                  | yhl            |                |                
Hlersu                                        | hle            |                |                
Hmar                                          | hmr            |                |                
Hmong Daw                                     | mww            |                |                
Hmong Don                                     | hmf            |                |                
Hmong Dô                                      | hmv            |                |                
Hmong Njua                                    | hnj            |                |                
Hmong Shua                                    | hmz            |                |                
Hmong                                         | hmn            |                |                
Hmong-Mien languages                          | hmx            |                |                
Hmwaveke                                      | mrk            |                |                
Ho Chi Minh City Sign Language                | hos            |                |                
Ho                                            | hoc            |                |                
Ho-Chunk                                      | win            |                |                
Hoava                                         | hoa            |                |                
Hobyót                                        | hoh            |                |                
Hoia Hoia                                     | hhi            |                |                
Hokan languages                               | hok            |                |                
Holikachuk                                    | hoi            |                |                
Holiya                                        | hoy            |                |                
Holma                                         | hod            |                |                
Holoholo                                      | hoo            |                |                
Holu                                          | hol            |                |                
Homa                                          | hom            |                |                
Honduras Sign Language                        | hds            |                |                
Hong Kong Sign Language                       | hks            |                |                
Honi                                          | how            |                |                
Hopi                                          | hop            |                |                
Horned Miao                                   | hrm            |                |                
Horo                                          | hor            |                |                
Horom                                         | hoe            |                |                
Horpa                                         | ero            |                |                
Horuru                                        | hrr            |                |                
Hote                                          | hot            |                |                
Hoti                                          | hti            |                |                
Hovongan                                      | hov            |                |                
Hoyahoya                                      | hhy            |                |                
Hozo                                          | hoz            |                |                
Hpon                                          | hpo            |                |                
Hrangkhol                                     | hra            |                |                
Hre                                           | hre            |                |                
Hruso                                         | hru            |                |                
Hu                                            | huo            |                |                
Huachipaeri                                   | hug            |                |                
Huallaga Huánuco Quechua                      | qub            |                |                
Huamalíes-Dos de Mayo Huánuco Quechua         | qvh            |                |                
Huambisa                                      | hub            |                |                
Huarijio                                      | var            |                |                
Huastec                                       | hus            |                |                
Huaulu                                        | hud            |                |                
Huautla Mazatec                               | mau            |                |                
Huaxcaleca Nahuatl                            | nhq            |                |                
Huaylas Ancash Quechua                        | qwh            |                |                
Huaylla Wanca Quechua                         | qvw            |                |                
Huba                                          | hbb            |                |                
Huehuetla Tepehua                             | tee            |                |                
Huichol                                       | hch            |                |                
Huilliche                                     | huh            |                |                
Huitepec Mixtec                               | mxs            |                |                
Huizhou Chinese                               | czh            |                |                
Hukumina                                      | huw            |                |                
Hula                                          | hul            |                |                
Hulaulá                                       | huy            |                |                
Huli                                          | hui            |                |                
Hulung                                        | huk            |                |                
Humburi Senni Songhay                         | hmb            |                |                
Humene                                        | huf            |                |                
Humla                                         | hut            |                |                
Hun-Saare                                     | dud            |                |                
Hunde                                         | hke            |                |                
Hung                                          | hnu            |                |                
Hungana                                       | hum            |                |                
Hungarian Sign Language                       | hsh            |                |                
Hungarian                                     | hun            | hu             |                
Hungu                                         | hng            |                |                
Hunjara-Kaina Ke                              | hkk            |                |                
Hunnic                                        | xhc            |                |                
Hunsrik                                       | hrx            |                |                
Hunzib                                        | huz            |                |                
Hupa                                          | hup            |                |                
Hupdë                                         | jup            |                |                
Hupla                                         | hap            |                |                
Hurrian                                       | xhu            |                |                
Hutterite German                              | geh            |                |                
Hwana                                         | hwo            |                |                
Hya                                           | hya            |                |                
Hyam                                          | jab            |                |                
Hyolmo                                        | scp            |                |                
Hértevin                                      | hrt            |                |                
Hõne                                          | juh            |                |                
I-Wak                                         | iwk            |                |                
Iaai                                          | iai            |                |                
Iamalele                                      | yml            |                |                
Iapama                                        | iap            |                |                
Iatmul                                        | ian            |                |                
Iau                                           | tmu            |                |                
Ibali Teke                                    | tek            |                |                
Ibaloi                                        | ibl            |                |                
Iban                                          | iba            |                |                
Ibanag                                        | ibg            |                |                
Ibani                                         | iby            |                |                
Ibatan                                        | ivb            |                |                
Iberian                                       | xib            |                |                
Ibibio                                        | ibb            |                |                
Ibilo                                         | ibi            |                |                
Ibino                                         | ibn            |                |                
Ibu                                           | ibu            |                |                
Ibuoro                                        | ibr            |                |                
Icelandic Sign Language                       | icl            |                |                
Icelandic                                     | ice            | is             | isl            
Iceve-Maci                                    | bec            |                |                
Ida'an                                        | dbj            |                |                
Idakho-Isukha-Tiriki                          | ida            |                |                
Idaté                                         | idt            |                |                
Idere                                         | ide            |                |                
Idesa                                         | ids            |                |                
Idi                                           | idi            |                |                
Ido                                           | ido            | io             |                
Idoma                                         | idu            |                |                
Idon                                          | idc            |                |                
Idu-Mishmi                                    | clk            |                |                
Iduna                                         | viv            |                |                
Ifo                                           | iff            |                |                
Ifè                                           | ife            |                |                
Igala                                         | igl            |                |                
Igana                                         | igg            |                |                
Igbo                                          | ibo            | ig             |                
Igede                                         | ige            |                |                
Ignaciano                                     | ign            |                |                
Igo                                           | ahl            |                |                
Iguta                                         | nar            |                |                
Igwe                                          | igw            |                |                
Iha Based Pidgin                              | ihb            |                |                
Iha                                           | ihp            |                |                
Ihievbe                                       | ihi            |                |                
Ija-Zuba                                      | vki            |                |                
Ijo languages                                 | ijo            |                |                
Ik                                            | ikx            |                |                
Ika                                           | ikk            |                |                
Ikaranggal                                    | ikr            |                |                
Ikizu                                         | ikz            |                |                
Iko                                           | iki            |                |                
Ikobi                                         | meb            |                |                
Ikoma-Nata-Isenye                             | ntk            |                |                
Ikpeng                                        | txi            |                |                
Ikpeshi                                       | ikp            |                |                
Ikposo                                        | kpo            |                |                
Iku-Gora-Ankwa                                | ikv            |                |                
Ikulu                                         | ikl            |                |                
Ikwere                                        | ikw            |                |                
Ikwo                                          | iqw            |                |                
Ila                                           | ilb            |                |                
Ile Ape                                       | ila            |                |                
Ili Turki                                     | ili            |                |                
Ili'uun                                       | ilu            |                |                
Ilianen Manobo                                | mbi            |                |                
Illyrian                                      | xil            |                |                
Iloko                                         | ilo            |                |                
Ilongot                                       | ilk            |                |                
Ilue                                          | ilv            |                |                
Ilwana                                        | mlk            |                |                
Imbabura Highland Quichua                     | qvi            |                |                
Imbongu                                       | imo            |                |                
Imeraguen                                     | ime            |                |                
Imonda                                        | imn            |                |                
Imotong                                       | imt            |                |                
Imroing                                       | imr            |                |                
Inabaknon                                     | abx            |                |                
Inapang                                       | mzu            |                |                
Inari Sami                                    | smn            |                |                
Indian Sign Language                          | ins            |                |                
Indic languages                               | inc            |                |                
Indo-European languages                       | ine            |                |                
Indo-Iranian languages                        | iir            |                |                
Indo-Portuguese                               | idb            |                |                
Indonesian Bajau                              | bdl            |                |                
Indonesian Sign Language                      | inl            |                |                
Indonesian                                    | ind            | id             |                
Indri                                         | idr            |                |                
Indus Kohistani                               | mvy            |                |                
Indus Valley Language                         | xiv            |                |                
Inebu One                                     | oin            |                |                
Ineseño                                       | inz            |                |                
Inga                                          | inb            |                |                
Ingrian                                       | izh            |                |                
Ingush                                        | inh            |                |                
Inlaod Itneg                                  | iti            |                |                
Innu                                          | moe            |                |                
Inoke-Yate                                    | ino            |                |                
Inonhan                                       | loc            |                |                
Inor                                          | ior            |                |                
Inpui Naga                                    | nkf            |                |                
Interglossa                                   | igs            |                |                
Interlingua (IALA)                            | ina            | ia             |                
Interlingue                                   | ile            | ie             |                
International Sign                            | ils            |                |                
Intha                                         | int            |                |                
Inuinnaqtun                                   | ikt            |                |                
Inuit Sign Language                           | iks            |                |                
Inuktitut                                     | iku            | iu             |                
Inupiaq                                       | ipk            | ik             |                
Iowa-Oto                                      | iow            |                |                
Ipalapa Amuzgo                                | azm            |                |                
Ipiko                                         | ipo            |                |                
Ipili                                         | ipi            |                |                
Ipulo                                         | ass            |                |                
Iquito                                        | iqu            |                |                
Ir                                            | irr            |                |                
Iranian Persian                               | pes            |                |                
Iranian Sign Language                         | psc            |                |                
Iranian languages                             | ira            |                |                
Iranun (Malaysia)                             | ilm            |                |                
Iranun (Philippines)                          | ilp            |                |                
Iranun                                        | ill            |                |                
Iraqw                                         | irk            |                |                
Irarutu                                       | irh            |                |                
Iraya                                         | iry            |                |                
Iresim                                        | ire            |                |                
Irish Sign Language                           | isg            |                |                
Irish                                         | gle            | ga             |                
Iroquoian languages                           | iro            |                |                
Irula                                         | iru            |                |                
Irántxe                                       | irn            |                |                
Isabi                                         | isa            |                |                
Isanzu                                        | isn            |                |                
Isarog Agta                                   | agk            |                |                
Isconahua                                     | isc            |                |                
Isebe                                         | igo            |                |                
Isekiri                                       | its            |                |                
Ishkashimi                                    | isk            |                |                
Isinai                                        | inn            |                |                
Isirawa                                       | srl            |                |                
Island Carib                                  | crb            |                |                
Islander Creole English                       | icr            |                |                
Isnag                                         | isd            |                |                
Isoko                                         | iso            |                |                
Israeli Sign Language                         | isr            |                |                
Isthmus Mixe                                  | mir            |                |                
Isthmus Zapotec                               | zai            |                |                
Isthmus-Cosoleacaque Nahuatl                  | nhk            |                |                
Isthmus-Mecayapan Nahuatl                     | nhx            |                |                
Isthmus-Pajapan Nahuatl                       | nhp            |                |                
Istriot                                       | ist            |                |                
Istro Romanian                                | ruo            |                |                
Isu (Fako Division)                           | szv            |                |                
Isu (Menchum Division)                        | isu            |                |                
Italian Sign Language                         | ise            |                |                
Italian                                       | ita            | it             |                
Italic languages                              | itc            |                |                
Itawit                                        | itv            |                |                
Itelmen                                       | itl            |                |                
Itene                                         | ite            |                |                
Iteri                                         | itr            |                |                
Itik                                          | itx            |                |                
Ito                                           | itw            |                |                
Itonama                                       | ito            |                |                
Itu Mbon Uzo                                  | itm            |                |                
Itundujia Mixtec                              | mce            |                |                
Itzá                                          | itz            |                |                
Iu Mien                                       | ium            |                |                
Ivatan                                        | ivv            |                |                
Ivbie North-Okpela-Arhe                       | atg            |                |                
Iwaidja                                       | ibd            |                |                
Iwal                                          | kbm            |                |                
Iwam                                          | iwm            |                |                
Iwur                                          | iwo            |                |                
Ixcatec                                       | ixc            |                |                
Ixcatlán Mazatec                              | mzi            |                |                
Ixil                                          | ixl            |                |                
Ixtayutla Mixtec                              | vmj            |                |                
Ixtenco Otomi                                 | otz            |                |                
Iyayu                                         | iya            |                |                
Iyive                                         | uiv            |                |                
Iyo                                           | nca            |                |                
Iyo'wujwa Chorote                             | crq            |                |                
Iyojwa'ja Chorote                             | crt            |                |                
Izere                                         | izr            |                |                
Izi-Ezaa-Ikwo-Mgbo                            | izi            |                |                
Izii                                          | izz            |                |                
Izon                                          | ijc            |                |                
Izora                                         | cbo            |                |                
Iñapari                                       | inp            |                |                
Jabutí                                        | jbt            |                |                
Jad                                           | jda            |                |                
Jadgali                                       | jdg            |                |                
Jah Hut                                       | jah            |                |                
Jahanka                                       | jad            |                |                
Jair Awyu                                     | awv            |                |                
Jaitmatang                                    | xjt            |                |                
Jakati                                        | jat            |                |                
Jakattoe                                      | jrt            |                |                
Jakun                                         | jak            |                |                
Jalapa De Díaz Mazatec                        | maj            |                |                
Jalkunan                                      | bxl            |                |                
Jamaican Country Sign Language                | jcs            |                |                
Jamaican Creole English                       | jam            |                |                
Jamaican Sign Language                        | jls            |                |                
Jamamadí                                      | jaa            |                |                
Jambi Malay                                   | jax            |                |                
Jamiltepec Mixtec                             | mxt            |                |                
Jamsay Dogon                                  | djm            |                |                
Jandai                                        | jan            |                |                
Jandavra                                      | jnd            |                |                
Jangkang                                      | djo            |                |                
Jangshung                                     | jna            |                |                
Janji                                         | jni            |                |                
Japanese (family)                             | jpx            |                |                
Japanese Sign Language                        | jsl            |                |                
Japanese                                      | jpn            | ja             |                
Japrería                                      | jru            |                |                
Jaqaru                                        | jqr            |                |                
Jara                                          | jaf            |                |                
Jarai                                         | jra            |                |                
Jarawa (India)                                | anq            |                |                
Jarawa (Nigeria)                              | jar            |                |                
Jaru                                          | ddj            |                |                
Jauja Wanca Quechua                           | qxw            |                |                
Jaunsari                                      | jns            |                |                
Javanese                                      | jav            | jv             |                
Javindo                                       | jvd            |                |                
Jawe                                          | jaz            |                |                
Jawoyn                                        | djn            |                |                
Jaya                                          | jyy            |                |                
Jebero                                        | jeb            |                |                
Jeh                                           | jeh            |                |                
Jehai                                         | jhi            |                |                
Jejara Naga                                   | pzn            |                |                
Jejueo                                        | jje            |                |                
Jemez                                         | tow            |                |                
Jenaama Bozo                                  | bze            |                |                
Jeng                                          | jeg            |                |                
Jennu Kurumba                                 | xuj            |                |                
Jere                                          | jer            |                |                
Jeri Kuo                                      | jek            |                |                
Jerung                                        | jee            |                |                
Jewish Babylonian Aramaic (ca. 200-1200 CE)   | tmr            |                |                
Jewish Palestinian Aramaic                    | jpa            |                |                
Jhankot Sign Language                         | jhs            |                |                
Jiamao                                        | jio            |                |                
Jiarong                                       | jya            |                |                
Jiba                                          | juo            |                |                
Jibu                                          | jib            |                |                
Jicarilla Apache                              | apj            |                |                
Jiiddu                                        | jii            |                |                
Jilbe                                         | jie            |                |                
Jilim                                         | jil            |                |                
Jimi (Cameroon)                               | jim            |                |                
Jimi (Nigeria)                                | jmi            |                |                
Jina                                          | jia            |                |                
Jingulu                                       | jig            |                |                
Jinyu Chinese                                 | cjy            |                |                
Jiongnai Bunu                                 | pnu            |                |                
Jirel                                         | jul            |                |                
Jiru                                          | jrr            |                |                
Jita                                          | jit            |                |                
Jju                                           | kaj            |                |                
Joba                                          | job            |                |                
Jofotek-Bromnya                               | jbr            |                |                
Jogi                                          | jog            |                |                
Jola-Fonyi                                    | dyo            |                |                
Jola-Kasa                                     | csk            |                |                
Jonkor Bourmataguil                           | jeu            |                |                
Jordanian Sign Language                       | jos            |                |                
Jorá                                          | jor            |                |                
Jowulu                                        | jow            |                |                
Ju                                            | juu            |                |                
Juang                                         | jun            |                |                
Judeo-Arabic                                  | jrb            |                |                
Judeo-Berber                                  | jbe            |                |                
Judeo-Georgian                                | jge            |                |                
Judeo-Iraqi Arabic                            | yhd            |                |                
Judeo-Italian                                 | itk            |                |                
Judeo-Moroccan Arabic                         | aju            |                |                
Judeo-Persian                                 | jpr            |                |                
Judeo-Tat                                     | jdt            |                |                
Judeo-Tripolitanian Arabic                    | yud            |                |                
Judeo-Tunisian Arabic                         | ajt            |                |                
Judeo-Yemeni Arabic                           | jye            |                |                
Jukun Takum                                   | jbu            |                |                
Jumjum                                        | jum            |                |                
Jumla Sign Language                           | jus            |                |                
Jumli                                         | jml            |                |                
Jungle Inga                                   | inj            |                |                
Juquila Mixe                                  | mxq            |                |                
Jur Modo                                      | bex            |                |                
Juray                                         | juy            |                |                
Jurchen                                       | juc            |                |                
Jurúna                                        | jur            |                |                
Jutish                                        | jut            |                |                
Juwal                                         | mwb            |                |                
Juxtlahuaca Mixtec                            | vmc            |                |                
Juǀʼhoan                                      | ktz            |                |                
Jwira-Pepesa                                  | jwi            |                |                
Jèrriais                                      | nrf            |                |                
Júma                                          | jua            |                |                
K'iche'                                       | quc            |                |                
Kaamba                                        | xku            |                |                
Kaan                                          | ldl            |                |                
Kaang Chin                                    | ckn            |                |                
Kaansa                                        | gna            |                |                
Kaba                                          | ksp            |                |                
Kabalai                                       | kvf            |                |                
Kabardian                                     | kbd            |                |                
Kabatei                                       | xkp            |                |                
Kabixí                                        | xbx            |                |                
Kabiyè                                        | kbp            |                |                
Kabola                                        | klz            |                |                
Kabore One                                    | onk            |                |                
Kabras                                        | lkb            |                |                
Kaburi                                        | uka            |                |                
Kabutra                                       | kbu            |                |                
Kabuverdianu                                  | kea            |                |                
Kabwa                                         | cwa            |                |                
Kabwari                                       | kcw            |                |                
Kabyle                                        | kab            |                |                
Kachama-Ganjule                               | kcx            |                |                
Kachari                                       | xac            |                |                
Kachhi                                        | kfr            |                |                
Kachi Koli                                    | gjk            |                |                
Kachin                                        | kac            |                |                
Kachok                                        | xkk            |                |                
Kacipo-Bale Suri                              | koe            |                |                
Kadai                                         | kzd            |                |                
Kadar                                         | kej            |                |                
Kadaru                                        | kdu            |                |                
Kadazan Dusun                                 | dtp            |                |                
Kadiwéu                                       | kbc            |                |                
Kado                                          | kdv            |                |                
Kadu                                          | zkd            |                |                
Kadung                                        | dkg            |                |                
Kaduo                                         | ktp            |                |                
Kaeku                                         | kkq            |                |                
Kaera                                         | jka            |                |                
Kafa                                          | kbr            |                |                
Kafoa                                         | kpu            |                |                
Kagan Kalagan                                 | kll            |                |                
Kagate                                        | syw            |                |                
Kagayanen                                     | cgc            |                |                
Kagoma                                        | kdm            |                |                
Kagoro                                        | xkg            |                |                
Kagulu                                        | kki            |                |                
Kahe                                          | hka            |                |                
Kahua                                         | agw            |                |                
Kaian                                         | kct            |                |                
Kaibobo                                       | kzb            |                |                
Kaidipang                                     | kzp            |                |                
Kaiep                                         | kbw            |                |                
Kaikadi                                       | kep            |                |                
Kaikavian Literary Language                   | kjv            |                |                
Kaike                                         | kzq            |                |                
Kaimbulawa                                    | zka            |                |                
Kaimbé                                        | xai            |                |                
Kaingang                                      | kgp            |                |                
Kairak                                        | ckr            |                |                
Kairiru                                       | kxa            |                |                
Kairui-Midiki                                 | krd            |                |                
Kais                                          | kzm            |                |                
Kaitag                                        | xdq            |                |                
Kaivi                                         | kce            |                |                
Kaiwá                                         | kgk            |                |                
Kaiy                                          | tcq            |                |                
Kajakse                                       | ckq            |                |                
Kajali                                        | xkj            |                |                
Kajaman                                       | kag            |                |                
Kakabai                                       | kqf            |                |                
Kakabe                                        | kke            |                |                
Kakanda                                       | kka            |                |                
Kakauhua                                      | kbf            |                |                
Kaki Ae                                       | tbd            |                |                
Kakihum                                       | kxe            |                |                
Kako                                          | kkj            |                |                
Kakwa                                         | keo            |                |                
Kala Lagaw Ya                                 | mwp            |                |                
Kalaallisut                                   | kal            | kl             |                
Kalaamaya                                     | lkm            |                |                
Kalabakan                                     | kve            |                |                
Kalabari                                      | ijn            |                |                
Kalabra                                       | kzz            |                |                
Kalagan                                       | kqe            |                |                
Kalaktang Monpa                               | kkf            |                |                
Kalam                                         | kmh            |                |                
Kalamsé                                       | knz            |                |                
Kalanadi                                      | wkl            |                |                
Kalanga                                       | kck            |                |                
Kalanguya                                     | kak            |                |                
Kalao                                         | kly            |                |                
Kalapuya                                      | kyl            |                |                
Kalarko                                       | kba            |                |                
Kalasha                                       | kls            |                |                
Kalenjin                                      | kln            |                |                
Kalispel-Pend d'Oreille                       | fla            |                |                
Kalkoti                                       | xka            |                |                
Kalkutung                                     | ktg            |                |                
Kalmyk                                        | xal            |                |                
Kalo Finnish Romani                           | rmf            |                |                
Kalou                                         | ywa            |                |                
Kaluli                                        | bco            |                |                
Kalumpang                                     | kli            |                |                
Kam                                           | kdx            |                |                
Kamakan                                       | vkm            |                |                
Kamang                                        | woi            |                |                
Kamano                                        | kbq            |                |                
Kamantan                                      | kci            |                |                
Kamar                                         | keq            |                |                
Kamara                                        | jmr            |                |                
Kamarian                                      | kzx            |                |                
Kamaru                                        | kgx            |                |                
Kamas                                         | xas            |                |                
Kamasa                                        | klp            |                |                
Kamasau                                       | kms            |                |                
Kamayo                                        | kyk            |                |                
Kamayurá                                      | kay            |                |                
Kamba (Brazil)                                | xba            |                |                
Kamba (Kenya)                                 | kam            |                |                
Kambaata                                      | ktb            |                |                
Kambaira                                      | kyy            |                |                
Kambera                                       | xbr            |                |                
Kamberau                                      | irx            |                |                
Kambiwá                                       | xbw            |                |                
Kami (Nigeria)                                | kmi            |                |                
Kami (Tanzania)                               | kcu            |                |                
Kamo                                          | kcq            |                |                
Kamoro                                        | kgq            |                |                
Kamu                                          | xmu            |                |                
Kamula                                        | xla            |                |                
Kamviri                                       | xvi            |                |                
Kamwe                                         | hig            |                |                
Kanakanabu                                    | xnb            |                |                
Kanamarí                                      | knm            |                |                
Kanan                                         | zkn            |                |                
Kanashi                                       | xns            |                |                
Kanasi                                        | soq            |                |                
Kanauji                                       | bjj            |                |                
Kandas                                        | kqw            |                |                
Kandawo                                       | gam            |                |                
Kande                                         | kbs            |                |                
Kanembu                                       | kbl            |                |                
Kang                                          | kyp            |                |                
Kanga                                         | kcp            |                |                
Kangean                                       | kkv            |                |                
Kanggape                                      | igm            |                |                
Kangjia                                       | kxs            |                |                
Kango (Bas-Uélé District)                     | kty            |                |                
Kango (Tshopo District)                       | kzy            |                |                
Kangri                                        | xnr            |                |                
Kaniet                                        | ktk            |                |                
Kanikkaran                                    | kev            |                |                
Kaningdon-Nindem                              | kdp            |                |                
Kaningi                                       | kzo            |                |                
Kaningra                                      | knr            |                |                
Kaninuwa                                      | wat            |                |                
Kanite                                        | kmu            |                |                
Kanjari                                       | kft            |                |                
Kanju                                         | kbe            |                |                
Kankanaey                                     | kne            |                |                
Kannada Kurumba                               | kfi            |                |                
Kannada                                       | kan            | kn             |                
Kanowit-Tanjong Melanau                       | kxn            |                |                
Kanoé                                         | kxo            |                |                
Kansa                                         | ksk            |                |                
Kantosi                                       | xkt            |                |                
Kanu                                          | khx            |                |                
Kanufi                                        | kni            |                |                
Kanuri                                        | kau            | kr             |                
Kanyok                                        | kny            |                |                
Kao                                           | kax            |                |                
Kaonde                                        | kqn            |                |                
Kap                                           | ykm            |                |                
Kapin                                         | tbx            |                |                
Kapinawá                                      | xpn            |                |                
Kapingamarangi                                | kpg            |                |                
Kapori                                        | khp            |                |                
Kapriman                                      | dju            |                |                
Kaptiau                                       | kbi            |                |                
Kapya                                         | klo            |                |                
Kaqchikel                                     | cak            |                |                
Kara (Central African Republic)               | kah            |                |                
Kara (Korea)                                  | zra            |                |                
Kara (Papua New Guinea)                       | leu            |                |                
Kara (Tanzania)                               | reg            |                |                
Kara-Kalpak                                   | kaa            |                |                
Karachay-Balkar                               | krc            |                |                
Karagas                                       | kim            |                |                
Karahawyana                                   | xkh            |                |                
Karaim                                        | kdr            |                |                
Karajarri                                     | gbd            |                |                
Karajá                                        | kpj            |                |                
Karakhanid                                    | xqa            |                |                
Karami                                        | xar            |                |                
Karamojong                                    | kdj            |                |                
Karang                                        | kzr            |                |                
Karanga                                       | kth            |                |                
Karankawa                                     | zkk            |                |                
Karao                                         | kyj            |                |                
Karas                                         | kgv            |                |                
Karata                                        | kpt            |                |                
Karawa                                        | xrw            |                |                
Karbi                                         | mjw            |                |                
Kare (Central African Republic)               | kbn            |                |                
Kare (Papua New Guinea)                       | kmf            |                |                
Karekare                                      | kai            |                |                
Karelian                                      | krl            |                |                
Karen languages                               | kar            |                |                
Karenggapa                                    | eaa            |                |                
Karey                                         | kyd            |                |                
Kari                                          | kbj            |                |                
Karingani                                     | kgn            |                |                
Karipuna                                      | kuq            |                |                
Karipúna Creole French                        | kmv            |                |                
Karipúna                                      | kgm            |                |                
Karirí-Xocó                                   | kzw            |                |                
Karitiâna                                     | ktn            |                |                
Kariya                                        | kil            |                |                
Kariyarra                                     | vka            |                |                
Karkar-Yuri                                   | yuj            |                |                
Karkin                                        | krb            |                |                
Karko                                         | kko            |                |                
Karnai                                        | bbv            |                |                
Karo (Brazil)                                 | arr            |                |                
Karo (Ethiopia)                               | kxh            |                |                
Karok                                         | kyh            |                |                
Karon Dori                                    | kgw            |                |                
Karon                                         | krx            |                |                
Karore                                        | xkx            |                |                
Karranga                                      | xrq            |                |                
Karuwali                                      | rxw            |                |                
Kasanga                                       | ccj            |                |                
Kasem                                         | xsm            |                |                
Kashaya                                       | kju            |                |                
Kashmiri                                      | kas            | ks             |                
Kashubian                                     | csb            |                |                
Kasiguranin                                   | ksn            |                |                
Kaska                                         | kkz            |                |                
Kaskean                                       | zsk            |                |                
Kasseng                                       | kgc            |                |                
Kasua                                         | khs            |                |                
Kataang                                       | kgd            |                |                
Katabaga                                      | ktq            |                |                
Katawixi                                      | xat            |                |                
Katbol                                        | tmb            |                |                
Katcha-Kadugli-Miri                           | xtc            |                |                
Kathoriya Tharu                               | tkt            |                |                
Kathu                                         | ykt            |                |                
Kati                                          | bsh            |                |                
Katkari                                       | kfu            |                |                
Katla                                         | kcr            |                |                
Kato                                          | ktw            |                |                
Katso                                         | kaf            |                |                
Katua                                         | kta            |                |                
Katukína                                      | kav            |                |                
Kaulong                                       | pss            |                |                
Kaur                                          | vkk            |                |                
Kaure                                         | bpp            |                |                
Kaurna                                        | zku            |                |                
Kauwera                                       | xau            |                |                
Kavalan                                       | ckv            |                |                
Kavet                                         | krv            |                |                
Kawacha                                       | kcb            |                |                
Kawaiisu                                      | xaw            |                |                
Kawe                                          | kgb            |                |                
Kawi                                          | kaw            |                |                
Kaxararí                                      | ktx            |                |                
Kaxuiâna                                      | kbb            |                |                
Kayabí                                        | kyz            |                |                
Kayagar                                       | kyt            |                |                
Kayan Mahakam                                 | xay            |                |                
Kayan River Kayan                             | xkn            |                |                
Kayan                                         | pdu            |                |                
Kayapó                                        | txu            |                |                
Kayardild                                     | gyd            |                |                
Kayaw                                         | kvl            |                |                
Kayeli                                        | kzl            |                |                
Kayong                                        | kxy            |                |                
Kayort                                        | kyv            |                |                
Kaytetye                                      | gbb            |                |                
Kayupulau                                     | kzu            |                |                
Kazakh                                        | kaz            | kk             |                
Kazukuru                                      | kzk            |                |                
Ke'o                                          | xxk            |                |                
Keak                                          | keh            |                |                
Keapara                                       | khz            |                |                
Kedah Malay                                   | meo            |                |                
Kedang                                        | ksx            |                |                
Keder                                         | kdy            |                |                
Keerray-Woorroong                             | wkr            |                |                
Kehu                                          | khh            |                |                
Kei                                           | kei            |                |                
Keiga                                         | kec            |                |                
Kein                                          | bmh            |                |                
Keiyo                                         | eyo            |                |                
Kekchí                                        | kek            |                |                
Kela (Democratic Republic of Congo)           | kel            |                |                
Kela (Papua New Guinea)                       | kcl            |                |                
Kelabit                                       | kzi            |                |                
Kele (Democratic Republic of Congo)           | khy            |                |                
Kele (Papua New Guinea)                       | sbc            |                |                
Keley-I Kallahan                              | ify            |                |                
Keliko                                        | kbo            |                |                
Kelo                                          | xel            |                |                
Kelon                                         | kyo            |                |                
Kemak                                         | kem            |                |                
Kembayan                                      | xem            |                |                
Kemberano                                     | bzp            |                |                
Kembra                                        | xkw            |                |                
Kemedzung                                     | dmo            |                |                
Kemi Sami                                     | sjk            |                |                
Kemiehua                                      | kfj            |                |                
Kemtuik                                       | kmt            |                |                
Kenaboi                                       | xbn            |                |                
Kenati                                        | gat            |                |                
Kendayan                                      | knx            |                |                
Kendeje                                       | klf            |                |                
Kendem                                        | kvm            |                |                
Kenga                                         | kyq            |                |                
Keningau Murut                                | kxi            |                |                
Keninjal                                      | knl            |                |                
Kensiu                                        | kns            |                |                
Kenswei Nsei                                  | ndb            |                |                
Kenuzi-Dongola                                | kzh            |                |                
Kenyan Sign Language                          | xki            |                |                
Kenyang                                       | ken            |                |                
Kenyi                                         | lke            |                |                
Kenzi                                         | xnz            |                |                
Keoru-Ahia                                    | xeu            |                |                
Kepkiriwát                                    | kpn            |                |                
Kepo'                                         | kuk            |                |                
Kera                                          | ker            |                |                
Kerak                                         | hhr            |                |                
Kereho                                        | xke            |                |                
Kerek                                         | krk            |                |                
Kerewe                                        | ked            |                |                
Kerewo                                        | kxz            |                |                
Kerinci                                       | kvr            |                |                
Kesawai                                       | xes            |                |                
Ket                                           | ket            |                |                
Ketangalan                                    | kae            |                |                
Kete                                          | kcv            |                |                
Ketengban                                     | xte            |                |                
Ketum                                         | ktt            |                |                
Keyagana                                      | kyg            |                |                
Kgalagadi                                     | xkv            |                |                
Khah                                          | hkh            |                |                
Khakas                                        | kjh            |                |                
Khalaj [Indo-Iranian]                         | kjf            |                |                
Khalaj                                        | klj            |                |                
Khaling                                       | klr            |                |                
Khamba                                        | kbg            |                |                
Khams Tibetan                                 | khg            |                |                
Khamti                                        | kht            |                |                
Khamyang                                      | ksu            |                |                
Khana                                         | ogo            |                |                
Khandesi                                      | khn            |                |                
Khanty                                        | kca            |                |                
Khao                                          | xao            |                |                
Kharam Naga                                   | kfw            |                |                
Kharia Thar                                   | ksy            |                |                
Kharia                                        | khr            |                |                
Khasi                                         | kha            |                |                
Khayo                                         | lko            |                |                
Khazar                                        | zkz            |                |                
Khe                                           | kqg            |                |                
Khehek                                        | tlx            |                |                
Khengkha                                      | xkf            |                |                
Khetrani                                      | xhe            |                |                
Khezha Naga                                   | nkh            |                |                
Khiamniungan Naga                             | kix            |                |                
Khinalugh                                     | kjj            |                |                
Khirwar                                       | kwx            |                |                
Khisa                                         | kqm            |                |                
Khlor                                         | llo            |                |                
Khlula                                        | ykl            |                |                
Khmer                                         | khm            | km             |                
Khmu                                          | kjg            |                |                
Kho'ini                                       | xkc            |                |                
Khoekhoe                                      | naq            |                |                
Khoibu Naga                                   | nkb            |                |                
Khoisan languages                             | khi            |                |                
Kholok                                        | ktc            |                |                
Khorasani Turkish                             | kmz            |                |                
Khorezmian                                    | zkh            |                |                
Khotanese                                     | kho            |                |                
Khowar                                        | khw            |                |                
Khua                                          | xhv            |                |                
Khuen                                         | khf            |                |                
Khumi Awa Chin                                | cka            |                |                
Khumi Chin                                    | cnk            |                |                
Khunsari                                      | kfm            |                |                
Khvarshi                                      | khv            |                |                
Kháng                                         | kjm            |                |                
Khün                                          | kkh            |                |                
Kibala                                        | blv            |                |                
Kibet                                         | kie            |                |                
Kibiri                                        | prm            |                |                
Kickapoo                                      | kic            |                |                
Kija                                          | gia            |                |                
Kikai                                         | kzg            |                |                
Kikuyu                                        | kik            | ki             |                
Kildin Sami                                   | sjd            |                |                
Kilivila                                      | kij            |                |                
Kiliwa                                        | klb            |                |                
Kilmeri                                       | kih            |                |                
Kim Mun                                       | mji            |                |                
Kim                                           | kia            |                |                
Kimaama                                       | kig            |                |                
Kimaragang                                    | kqr            |                |                
Kimbu                                         | kiv            |                |                
Kimbundu                                      | kmb            |                |                
Kimki                                         | sbt            |                |                
Kimré                                         | kqp            |                |                
Kinabalian                                    | cbw            |                |                
Kinalakna                                     | kco            |                |                
Kinamiging Manobo                             | mkx            |                |                
Kinaray-A                                     | krj            |                |                
Kinga                                         | zga            |                |                
Kinnauri                                      | kfk            |                |                
Kintaq                                        | knq            |                |                
Kinuku                                        | kkd            |                |                
Kinyarwanda                                   | kin            | rw             |                
Kioko                                         | ues            |                |                
Kiong                                         | kkm            |                |                
Kiorr                                         | xko            |                |                
Kiowa Apache                                  | apk            |                |                
Kiowa                                         | kio            |                |                
Kipsigis                                      | sgc            |                |                
Kiput                                         | kyi            |                |                
Kir-Balar                                     | kkr            |                |                
Kire                                          | geb            |                |                
Kirghiz                                       | kir            | ky             |                
Kirike                                        | okr            |                |                
Kirikiri                                      | kiy            |                |                
Kirmanjki (individual language)               | kiu            |                |                
Kirya-Konzəl                                  | fkk            |                |                
Kis                                           | kis            |                |                
Kisa                                          | lks            |                |                
Kisan                                         | xis            |                |                
Kisankasa                                     | kqh            |                |                
Kisar                                         | kje            |                |                
Kisi                                          | kiz            |                |                
Kistane                                       | gru            |                |                
Kita Maninkakan                               | mwk            |                |                
Kitan                                         | zkt            |                |                
Kitsai                                        | kii            |                |                
Kituba (Congo)                                | mkw            |                |                
Kituba (Democratic Republic of Congo)         | ktu            |                |                
Kiunum                                        | wei            |                |                
Kla-Dan                                       | lda            |                |                
Klamath-Modoc                                 | kla            |                |                
Klao                                          | klu            |                |                
Klias River Kadazan                           | kqt            |                |                
Klingon                                       | tlh            |                |                
Knaanic                                       | czk            |                |                
Ko                                            | fuj            |                |                
Koalib                                        | kib            |                |                
Koasati                                       | cku            |                |                
Koba                                          | kpd            |                |                
Kobiana                                       | kcj            |                |                
Kobo                                          | okc            |                |                
Kobol                                         | kgu            |                |                
Kobon                                         | kpw            |                |                
Koch                                          | kdq            |                |                
Kochila Tharu                                 | thq            |                |                
Koda                                          | cdz            |                |                
Kodaku                                        | ksz            |                |                
Kodava                                        | kfa            |                |                
Kodeoha                                       | vko            |                |                
Kodi                                          | kod            |                |                
Kodia                                         | kwp            |                |                
Koenoem                                       | kcs            |                |                
Kofa                                          | kso            |                |                
Kofei                                         | kpi            |                |                
Kofyar                                        | kwl            |                |                
Koguryo                                       | zkg            |                |                
Kohin                                         | kkx            |                |                
Kohistani Shina                               | plk            |                |                
Koho                                          | kpm            |                |                
Kohumono                                      | bcs            |                |                
Koi                                           | kkt            |                |                
Koibal                                        | zkb            |                |                
Koireng                                       | nkd            |                |                
Koitabu                                       | kqi            |                |                
Koiwat                                        | kxt            |                |                
Kok Borok                                     | trp            |                |                
Kok-Nar                                       | gko            |                |                
Kokata                                        | ktd            |                |                
Koke                                          | kou            |                |                
Koki Naga                                     | nxk            |                |                
Koko Babangk                                  | okg            |                |                
Kokoda                                        | xod            |                |                
Kokola                                        | kzn            |                |                
Kokota                                        | kkk            |                |                
Kol (Bangladesh)                              | ekl            |                |                
Kol (Cameroon)                                | biw            |                |                
Kol (Papua New Guinea)                        | kol            |                |                
Kola                                          | kvv            |                |                
Kolbila                                       | klc            |                |                
Kolibugan Subanon                             | skn            |                |                
Kolum So Dogon                                | dkl            |                |                
Koluwawa                                      | klx            |                |                
Kom (Cameroon)                                | bkm            |                |                
Kom (India)                                   | kmm            |                |                
Koma                                          | kmy            |                |                
Komba                                         | kpf            |                |                
Kombai                                        | tyn            |                |                
Kombio                                        | xbi            |                |                
Komering                                      | kge            |                |                
Komi                                          | kom            | kv             |                
Komi-Permyak                                  | koi            |                |                
Komi-Zyrian                                   | kpv            |                |                
Kominimung                                    | xoi            |                |                
Komo (Democratic Republic of Congo)           | kmw            |                |                
Komo (Sudan)                                  | xom            |                |                
Komodo                                        | kvh            |                |                
Kompane                                       | kvp            |                |                
Komyandaret                                   | kzv            |                |                
Kon Keu                                       | kkn            |                |                
Konai                                         | kxw            |                |                
Konda                                         | knd            |                |                
Konda-Dora                                    | kfc            |                |                
Koneraw                                       | kdw            |                |                
Kongo                                         | kon            | kg             |                
Konkani (individual language)                 | knn            |                |                
Konkani (macrolanguage)                       | kok            |                |                
Konkomba                                      | xon            |                |                
Konni                                         | kma            |                |                
Kono (Guinea)                                 | knu            |                |                
Kono (Nigeria)                                | klk            |                |                
Kono (Sierra Leone)                           | kno            |                |                
Konomala                                      | koa            |                |                
Konongo                                       | kcz            |                |                
Konso                                         | kxc            |                |                
Konyak Naga                                   | nbe            |                |                
Konyanka Maninka                              | mku            |                |                
Konzo                                         | koo            |                |                
Koongo                                        | kng            |                |                
Koonzime                                      | ozm            |                |                
Koorete                                       | kqy            |                |                
Kopar                                         | xop            |                |                
Kopkaka                                       | opk            |                |                
Korafe-Yegha                                  | kpr            |                |                
Korak                                         | koz            |                |                
Korana                                        | kqz            |                |                
Korandje                                      | kcy            |                |                
Kordofanian languages                         | kdo            |                |                
Korean Sign Language                          | kvk            |                |                
Korean                                        | kor            | ko             |                
Koreguaje                                     | coe            |                |                
Koresh-e Rostam                               | okh            |                |                
Korku                                         | kfq            |                |                
Korlai Creole Portuguese                      | vkp            |                |                
Koro (Côte d'Ivoire)                          | kfo            |                |                
Koro (India)                                  | jkr            |                |                
Koro (Papua New Guinea)                       | kxr            |                |                
Koro (Vanuatu)                                | krf            |                |                
Koro Nulu                                     | vkn            |                |                
Koro Wachi                                    | bqv            |                |                
Koro Zuba                                     | vkz            |                |                
Koromfé                                       | kfz            |                |                
Koromira                                      | kqj            |                |                
Koronadal Blaan                               | bpr            |                |                
Koroni                                        | xkq            |                |                
Korop                                         | krp            |                |                
Koropó                                        | xxr            |                |                
Koroshi                                       | ktl            |                |                
Korowai                                       | khe            |                |                
Korra Koraga                                  | kfd            |                |                
Korubo                                        | xor            |                |                
Korupun-Sela                                  | kpq            |                |                
Korwa                                         | kfp            |                |                
Koryak                                        | kpy            |                |                
Kosadle                                       | kiq            |                |                
Kosarek Yale                                  | kkl            |                |                
Kosena                                        | kze            |                |                
Koshin                                        | kid            |                |                
Kosraean                                      | kos            |                |                
Kota (Gabon)                                  | koq            |                |                
Kota (India)                                  | kfe            |                |                
Kota Bangun Kutai Malay                       | mqg            |                |                
Kota Marudu Talantang                         | grm            |                |                
Kota Marudu Tinagas                           | ktr            |                |                
Kotafon Gbe                                   | kqk            |                |                
Kotava                                        | avk            |                |                
Koti                                          | eko            |                |                
Kott                                          | zko            |                |                
Kou                                           | snz            |                |                
Kouya                                         | kyf            |                |                
Kovai                                         | kqb            |                |                
Kove                                          | kvc            |                |                
Kowaki                                        | xow            |                |                
Kowiai                                        | kwh            |                |                
Koy Sanjaq Surat                              | kqd            |                |                
Koya                                          | kff            |                |                
Koyaga                                        | kga            |                |                
Koyo                                          | koh            |                |                
Koyra Chiini Songhay                          | khq            |                |                
Koyraboro Senni Songhai                       | ses            |                |                
Koyukon                                       | koy            |                |                
Kpagua                                        | kuw            |                |                
Kpala                                         | kpl            |                |                
Kpan                                          | kpk            |                |                
Kpasam                                        | pbn            |                |                
Kpati                                         | koc            |                |                
Kpatili                                       | kym            |                |                
Kpeego                                        | cpo            |                |                
Kpelle                                        | kpe            |                |                
Kpessi                                        | kef            |                |                
Kplang                                        | kph            |                |                
Krache                                        | kye            |                |                
Krahô                                         | xra            |                |                
Kraol                                         | rka            |                |                
Krenak                                        | kqq            |                |                
Krevinian                                     | zkv            |                |                
Kreye                                         | xre            |                |                
Kriang                                        | ngt            |                |                
Krikati-Timbira                               | xri            |                |                
Krim                                          | krm            |                |                
Krio                                          | kri            |                |                
Kriol                                         | rop            |                |                
Krisa                                         | ksi            |                |                
Krobu                                         | kxb            |                |                
Krongo                                        | kgo            |                |                
Kru languages                                 | kro            |                |                
Krung                                         | krr            |                |                
Krymchak                                      | jct            |                |                
Kryts                                         | kry            |                |                
Kua                                           | tyu            |                |                
Kua-nsi                                       | ykn            |                |                
Kuamasi                                       | yku            |                |                
Kuan                                          | uan            |                |                
Kuanhua                                       | xnh            |                |                
Kuanua                                        | ksd            |                |                
Kuanyama                                      | kua            | kj             |                
Kubachi                                       | ugh            |                |                
Kube                                          | kgf            |                |                
Kubi                                          | kof            |                |                
Kubo                                          | jko            |                |                
Kubu                                          | kvb            |                |                
Kucong                                        | lkc            |                |                
Kudiya                                        | kfg            |                |                
Kudmali                                       | kyw            |                |                
Kudu-Camo                                     | kov            |                |                
Kufr Qassem Sign Language (KQSL)              | sqx            |                |                
Kugama                                        | kow            |                |                
Kugbo                                         | kes            |                |                
Kugu-Muminh                                   | xmh            |                |                
Kui (India)                                   | kxu            |                |                
Kui (India)                                   | uki            |                |                
Kui (Indonesia)                               | kvd            |                |                
Kuijau                                        | dkr            |                |                
Kuikúro-Kalapálo                              | kui            |                |                
Kujarge                                       | vkj            |                |                
Kuk                                           | kfn            |                |                
Kukatja                                       | kux            |                |                
Kuke                                          | ght            |                |                
Kukele                                        | kez            |                |                
Kukna                                         | kex            |                |                
Kuku                                          | ukv            |                |                
Kuku-Mangk                                    | xmq            |                |                
Kuku-Mu'inh                                   | xmp            |                |                
Kuku-Ugbanh                                   | ugb            |                |                
Kuku-Uwanh                                    | uwa            |                |                
Kuku-Yalanji                                  | gvn            |                |                
Kula                                          | tpg            |                |                
Kulere                                        | kul            |                |                
Kulfa                                         | kxj            |                |                
Kulina Pano                                   | xpk            |                |                
Kulisusu                                      | vkl            |                |                
Kullu Pahari                                  | kfx            |                |                
Kulon                                         | uon            |                |                
Kulon-Pazeh                                   | uun            |                |                
Kulung (Nepal)                                | kle            |                |                
Kulung (Nigeria)                              | bbu            |                |                
Kumalu                                        | ksl            |                |                
Kumam                                         | kdi            |                |                
Kuman (Papua New Guinea)                      | kue            |                |                
Kuman (Russia)                                | qwm            |                |                
Kumaoni                                       | kfy            |                |                
Kumarbhag Paharia                             | kmj            |                |                
Kumba                                         | ksm            |                |                
Kumbainggar                                   | kgs            |                |                
Kumbaran                                      | wkb            |                |                
Kumbewaha                                     | xks            |                |                
Kumhali                                       | kra            |                |                
Kumiai                                        | dih            |                |                
Kumukio                                       | kuo            |                |                
Kumyk                                         | kum            |                |                
Kumzari                                       | zum            |                |                
Kunama                                        | kun            |                |                
Kunbarlang                                    | wlg            |                |                
Kunda                                         | kdn            |                |                
Kundal Shahi                                  | shd            |                |                
Kunduvadi                                     | wku            |                |                
Kung                                          | kfl            |                |                
Kung-Ekoka                                    | knw            |                |                
Kungarakany                                   | ggk            |                |                
Kungardutyi                                   | gdt            |                |                
Kunggara                                      | kvs            |                |                
Kunggari                                      | kgl            |                |                
Kungkari                                      | lku            |                |                
Kuni                                          | kse            |                |                
Kuni-Boazi                                    | kvg            |                |                
Kunigami                                      | xug            |                |                
Kunimaipa                                     | kup            |                |                
Kunja                                         | pep            |                |                
Kunjen                                        | kjn            |                |                
Kunyi                                         | njx            |                |                
Kunza                                         | kuz            |                |                
Kuo                                           | xuo            |                |                
Kuot                                          | kto            |                |                
Kupa                                          | kug            |                |                
Kupang Malay                                  | mkn            |                |                
Kupia                                         | key            |                |                
Kupsabiny                                     | kpz            |                |                
Kur                                           | kuv            |                |                
Kura Ede Nago                                 | nqk            |                |                
Kurama                                        | krh            |                |                
Kuranko                                       | knk            |                |                
Kurdish                                       | kur            | ku             |                
Kuri                                          | nbn            |                |                
Kuria                                         | kuj            |                |                
Kurichiya                                     | kfh            |                |                
Kurmukar                                      | kfv            |                |                
Kurnai                                        | unn            |                |                
Kurrama                                       | vku            |                |                
Kurti                                         | ktm            |                |                
Kurtokha                                      | xkz            |                |                
Kurudu                                        | kjr            |                |                
Kurukh                                        | kru            |                |                
Kuruáya                                       | kyr            |                |                
Kusaal                                        | kus            |                |                
Kusaghe                                       | ksg            |                |                
Kushi                                         | kuh            |                |                
Kusu                                          | ksv            |                |                
Kusunda                                       | kgg            |                |                
Kutenai                                       | kut            |                |                
Kutep                                         | kub            |                |                
Kuthant                                       | xut            |                |                
Kutong                                        | skm            |                |                
Kutto                                         | kpa            |                |                
Kutu                                          | kdc            |                |                
Kuturmi                                       | khj            |                |                
Kuuk Thaayorre                                | thd            |                |                
Kuuk-Yak                                      | uky            |                |                
Kuuku-Ya'u                                    | kuy            |                |                
Kuvale                                        | olu            |                |                
Kuvi                                          | kxv            |                |                
Kuwaa                                         | blh            |                |                
Kuwaataay                                     | cwt            |                |                
Kuwema                                        | woa            |                |                
Kuy                                           | kdt            |                |                
Kven Finnish                                  | fkv            |                |                
Kw'adza                                       | wka            |                |                
Kwa                                           | kwb            |                |                
Kwa'                                          | bko            |                |                
Kwaami                                        | ksq            |                |                
Kwadi                                         | kwz            |                |                
Kwaio                                         | kwd            |                |                
Kwaja                                         | kdz            |                |                
Kwak                                          | kwq            |                |                
Kwakiutl                                      | kwk            |                |                
Kwakum                                        | kwu            |                |                
Kwalhioqua-Tlatskanai                         | qwt            |                |                
Kwama                                         | kmq            |                |                
Kwambi                                        | kwm            |                |                
Kwamera                                       | tnk            |                |                
Kwami                                         | ktf            |                |                
Kwamtim One                                   | okk            |                |                
Kwandu                                        | xdo            |                |                
Kwang                                         | kvi            |                |                
Kwanga                                        | kwj            |                |                
Kwangali                                      | kwn            |                |                
Kwanja                                        | knp            |                |                
Kwara'ae                                      | kwf            |                |                
Kwasio                                        | nmg            |                |                
Kwaya                                         | kya            |                |                
Kwaza                                         | xwa            |                |                
Kwegu                                         | xwg            |                |                
Kwer                                          | kwr            |                |                
Kwerba Mamberamo                              | xwr            |                |                
Kwerba                                        | kwe            |                |                
Kwere                                         | cwe            |                |                
Kwerisa                                       | kkb            |                |                
Kwese                                         | kws            |                |                
Kwesten                                       | kwt            |                |                
Kwini                                         | gww            |                |                
Kwinsu                                        | kuc            |                |                
Kwinti                                        | kww            |                |                
Kwoma                                         | kmo            |                |                
Kwomtari                                      | kwo            |                |                
Kxoe                                          | xuu            |                |                
Kyak                                          | bka            |                |                
Kyaka                                         | kyc            |                |                
Kyan-Karyaw Naga                              | nqq            |                |                
Kyanga                                        | tye            |                |                
Kyenele                                       | kql            |                |                
Kyerung                                       | kgy            |                |                
Kâte                                          | kmg            |                |                
Kélé                                          | keb            |                |                
Kölsch                                        | ksh            |                |                
Kɛlɛngaxo Bozo                                | bzx            |                |                
La'bi                                         | lbi            |                |                
Laal                                          | gdm            |                |                
Laari                                         | ldi            |                |                
Laba                                          | lau            |                |                
Label                                         | lbb            |                |                
Labir                                         | jku            |                |                
Labo Phowa                                    | ypb            |                |                
Labo                                          | mwi            |                |                
Labu                                          | lbu            |                |                
Labuk-Kinabatangan Kadazan                    | dtb            |                |                
Lacandon                                      | lac            |                |                
Lachi                                         | lbt            |                |                
Lachiguiri Zapotec                            | zpa            |                |                
Lachixío Zapotec                              | zpl            |                |                
Ladakhi                                       | lbj            |                |                
Ladin                                         | lld            |                |                
Ladino                                        | lad            |                |                
Ladji Ladji                                   | llj            |                |                
Laeko-Libuat                                  | lkl            |                |                
Lafofa                                        | laf            |                |                
Laghu                                         | lgb            |                |                
Laghuu                                        | lgh            |                |                
Lagwan                                        | kot            |                |                
Laha (Indonesia)                              | lhh            |                |                
Laha (Viet Nam)                               | lha            |                |                
Lahanan                                       | lhn            |                |                
Lahnda                                        | lah            |                |                
Lahta Karen                                   | kvt            |                |                
Lahu Shi                                      | lhi            |                |                
Lahu                                          | lhu            |                |                
Lahul Lohar                                   | lhl            |                |                
Laimbue                                       | lmx            |                |                
Laitu Chin                                    | clj            |                |                
Laiyolo                                       | lji            |                |                
Lak                                           | lbe            |                |                
Laka (Chad)                                   | lap            |                |                
Laka (Nigeria)                                | lak            |                |                
Lakalei                                       | lka            |                |                
Lake Miwok                                    | lmw            |                |                
Lakha                                         | lkh            |                |                
Laki                                          | lki            |                |                
Lakkia                                        | lbc            |                |                
Lakon                                         | lkn            |                |                
Lakondê                                       | lkd            |                |                
Lakota Dida                                   | dic            |                |                
Lakota                                        | lkt            |                |                
Lakurumau                                     | lxm            |                |                
Lala                                          | nrz            |                |                
Lala-Bisa                                     | leb            |                |                
Lala-Roba                                     | lla            |                |                
Lalana Chinantec                              | cnl            |                |                
Lalia                                         | lal            |                |                
Lama (Togo)                                   | las            |                |                
Lama Bai                                      | lay            |                |                
Lamaholot                                     | slp            |                |                
Lamalama                                      | lby            |                |                
Lamalera                                      | lmr            |                |                
Lamam                                         | lmm            |                |                
Lamang                                        | hia            |                |                
Lamatuka                                      | lmq            |                |                
Lamba                                         | lam            |                |                
Lambadi                                       | lmn            |                |                
Lambayeque Quechua                            | quf            |                |                
Lambichhong                                   | lmh            |                |                
Lamboya                                       | lmy            |                |                
Lambya                                        | lai            |                |                
Lame                                          | bma            |                |                
Lamenu                                        | lmu            |                |                
Lamja-Dengsa-Tola                             | ldh            |                |                
Lamkang                                       | lmk            |                |                
Lamma                                         | lev            |                |                
Lamnso'                                       | lns            |                |                
Lamogai                                       | lmg            |                |                
Lampung Api                                   | ljp            |                |                
Lampung Nyo                                   | abl            |                |                
Lamu                                          | llh            |                |                
Lanas Lobu                                    | ruu            |                |                
Land Dayak languages                          | day            |                |                
Landoma                                       | ldm            |                |                
Lang'e                                        | yne            |                |                
Langam                                        | lnm            |                |                
Langbashe                                     | lna            |                |                
Langi                                         | lag            |                |                
Langnian Buyang                               | yln            |                |                
Lango (South Sudan)                           | lgo            |                |                
Lango (South Sudan)                           | lno            |                |                
Lango (Uganda)                                | laj            |                |                
Langobardic                                   | lng            |                |                
Langue des signes de Belgique Francophone     | sfb            |                |                
Lanima                                        | lnw            |                |                
Lanoh                                         | lnh            |                |                
Lao Naga                                      | nlq            |                |                
Lao                                           | lao            | lo             |                
Laomian                                       | lwm            |                |                
Laopang                                       | lbg            |                |                
Laos Sign Language                            | lso            |                |                
Lapaguía-Guivini Zapotec                      | ztl            |                |                
Laragia                                       | lrg            |                |                
Larantuka Malay                               | lrt            |                |                
Lardil                                        | lbz            |                |                
Larevat                                       | lrv            |                |                
Large Flowery Miao                            | hmd            |                |                
Lari                                          | lrl            |                |                
Larike-Wakasihu                               | alo            |                |                
Laro                                          | lro            |                |                
Larteh                                        | lar            |                |                
Laru                                          | lan            |                |                
Las Delicias Zapotec                          | zcd            |                |                
Lasalimu                                      | llm            |                |                
Lasgerdi                                      | lsa            |                |                
Lashi                                         | lsi            |                |                
Lasi                                          | lss            |                |                
Late Middle Chinese                           | ltc            |                |                
Latgalian                                     | ltg            |                |                
Latin                                         | lat            | la             |                
Latu                                          | ltu            |                |                
Latundê                                       | ltn            |                |                
Latvian Sign Language                         | lsl            |                |                
Latvian                                       | lav            | lv             |                
Lau                                           | llu            |                |                
Laua                                          | luf            |                |                
Lauan                                         | llx            |                |                
Lauje                                         | law            |                |                
Laura                                         | lur            |                |                
Laurentian                                    | lre            |                |                
Lautu Chin                                    | clt            |                |                
Lavatbura-Lamusong                            | lbv            |                |                
Laven                                         | lbo            |                |                
Lavi                                          | lvi            |                |                
Lavukaleve                                    | lvk            |                |                
Lawangan                                      | lbx            |                |                
Lawu                                          | lwu            |                |                
Lawunuia                                      | tgi            |                |                
Layakha                                       | lya            |                |                
Laz                                           | lzz            |                |                
Lealao Chinantec                              | cle            |                |                
Leco                                          | lec            |                |                
Ledo Kaili                                    | lew            |                |                
Leelau                                        | ldk            |                |                
Lefa                                          | lfa            |                |                
Lega-Mwenga                                   | lgm            |                |                
Lega-Shabunda                                 | lea            |                |                
Legbo                                         | agb            |                |                
Legenyem                                      | lcc            |                |                
Lehali                                        | tql            |                |                
Lehalurup                                     | urr            |                |                
Lehar                                         | cae            |                |                
Leinong Naga                                  | lzn            |                |                
Leipon                                        | lek            |                |                
Lelak                                         | llk            |                |                
Lele (Chad)                                   | lln            |                |                
Lele (Democratic Republic of Congo)           | lel            |                |                
Lele (Guinea)                                 | llc            |                |                
Lele (Papua New Guinea)                       | lle            |                |                
Lelemi                                        | lef            |                |                
Lelepa                                        | lpa            |                |                
Lembena                                       | leq            |                |                
Lemerig                                       | lrz            |                |                
Lemio                                         | lei            |                |                
Lemnian                                       | xle            |                |                
Lemolang                                      | ley            |                |                
Lemoro                                        | ldj            |                |                
Lenakel                                       | tnl            |                |                
Lenca                                         | len            |                |                
Lendu                                         | led            |                |                
Lengilu                                       | lgi            |                |                
Lengo                                         | lgr            |                |                
Lengola                                       | lej            |                |                
Lengua                                        | leg            |                |                
Leningitij                                    | lnj            |                |                
Lenje                                         | leh            |                |                
Lenkau                                        | ler            |                |                
Lenyima                                       | ldg            |                |                
Lepcha                                        | lep            |                |                
Lepki                                         | lpe            |                |                
Lepontic                                      | xlp            |                |                
Lere                                          | gnh            |                |                
Lese                                          | les            |                |                
Lesing-Gelimi                                 | let            |                |                
Letemboi                                      | nms            |                |                
Leti (Cameroon)                               | leo            |                |                
Leti (Indonesia)                              | lti            |                |                
Levuka                                        | lvu            |                |                
Lewo Eleng                                    | lwe            |                |                
Lewo                                          | lww            |                |                
Lewotobi                                      | lwt            |                |                
Leyigha                                       | ayi            |                |                
Lezghian                                      | lez            |                |                
Lhokpu                                        | lhp            |                |                
Lhomi                                         | lhm            |                |                
Li'o                                          | ljl            |                |                
Liabuku                                       | lix            |                |                
Liana-Seti                                    | ste            |                |                
Liangmai Naga                                 | njn            |                |                
Lianshan Zhuang                               | zln            |                |                
Liberia Kpelle                                | xpe            |                |                
Liberian English                              | lir            |                |                
Libido                                        | liq            |                |                
Libinza                                       | liz            |                |                
Libon Bikol                                   | lbl            |                |                
Liburnian                                     | xli            |                |                
Libyan Arabic                                 | ayl            |                |                
Libyan Sign Language                          | lbs            |                |                
Lidzonka                                      | add            |                |                
Ligbi                                         | lig            |                |                
Ligenza                                       | lgz            |                |                
Ligurian (Ancient)                            | xlg            |                |                
Ligurian                                      | lij            |                |                
Lihir                                         | lih            |                |                
Lijili                                        | mgi            |                |                
Lika                                          | lik            |                |                
Liki                                          | lio            |                |                
Likila                                        | lie            |                |                
Likuba                                        | kxx            |                |                
Likum                                         | lib            |                |                
Likwala                                       | kwc            |                |                
Lilau                                         | lll            |                |                
Lillooet                                      | lil            |                |                
Limassa                                       | bme            |                |                
Limbu                                         | lif            |                |                
Limbum                                        | lmp            |                |                
Limburgan                                     | lim            | li             |                
Limi                                          | ylm            |                |                
Limilngan                                     | lmc            |                |                
Limos Kalinga                                 | kmk            |                |                
Linear A                                      | lab            |                |                
Lingala                                       | lin            | ln             |                
Lingao                                        | onb            |                |                
Lingarak                                      | lgk            |                |                
Lingkhim                                      | lii            |                |                
Lingua Franca Nova                            | lfn            |                |                
Lingua Franca                                 | pml            |                |                
Lipan Apache                                  | apl            |                |                
Lipo                                          | lpo            |                |                
Lisabata-Nuniali                              | lcs            |                |                
Lisela                                        | lcl            |                |                
Lish                                          | lsh            |                |                
Lishana Deni                                  | lsd            |                |                
Lishanid Noshan                               | aij            |                |                
Lishán Didán                                  | trg            |                |                
Lisu                                          | lis            |                |                
Literary Chinese                              | lzh            |                |                
Lithuanian Sign Language                      | lls            |                |                
Lithuanian                                    | lit            | lt             |                
Litzlitz                                      | lzl            |                |                
Liujiang Zhuang                               | zlj            |                |                
Liuqian Zhuang                                | zlq            |                |                
Liv                                           | liv            |                |                
Livvi                                         | olo            |                |                
Lo-Toga                                       | lht            |                |                
Loarki                                        | lrk            |                |                
Lobala                                        | loq            |                |                
Lobi                                          | lob            |                |                
Lodhi                                         | lbm            |                |                
Logba                                         | lgq            |                |                
Logir                                         | lqr            |                |                
Logo                                          | log            |                |                
Logol                                         | lof            |                |                
Logooli                                       | rag            |                |                
Logorik                                       | liu            |                |                
Logudorese Sardinian                          | src            |                |                
Lohorung                                      | lbr            |                |                
Loja Highland Quichua                         | qvj            |                |                
Lojban                                        | jbo            |                |                
Lokaa                                         | yaz            |                |                
Loke                                          | loy            |                |                
Loko                                          | lok            |                |                
Lokoya                                        | lky            |                |                
Lola                                          | lcd            |                |                
Lolak                                         | llq            |                |                
Lole                                          | llg            |                |                
Lolo                                          | llb            |                |                
Loloda                                        | loa            |                |                
Lolopo                                        | ycl            |                |                
Loma (Côte d'Ivoire)                          | loi            |                |                
Loma (Liberia)                                | lom            |                |                
Lomaiviti                                     | lmv            |                |                
Lomavren                                      | rmi            |                |                
Lombard                                       | lmo            |                |                
Lombi                                         | lmi            |                |                
Lombo                                         | loo            |                |                
Lomwe                                         | ngl            |                |                
Loncong                                       | lce            |                |                
Long Phuri Naga                               | lpn            |                |                
Long Wat                                      | ttw            |                |                
Longgu                                        | lgu            |                |                
Longto                                        | wok            |                |                
Longuda                                       | lnu            |                |                
Loniu                                         | los            |                |                
Lonwolwol                                     | crc            |                |                
Lonzo                                         | lnz            |                |                
Loo                                           | ldo            |                |                
Lopa                                          | lop            |                |                
Lopi                                          | lov            |                |                
Lopit                                         | lpx            |                |                
Lorang                                        | lrn            |                |                
Lorediakarkar                                 | lnn            |                |                
Loreto-Ucayali Spanish                        | spq            |                |                
Lote                                          | uvl            |                |                
Lotha Naga                                    | njh            |                |                
Lotud                                         | dtr            |                |                
Lou                                           | loj            |                |                
Louisiana Creole                              | lou            |                |                
Loun                                          | lox            |                |                
Loup A                                        | xlo            |                |                
Loup B                                        | xlb            |                |                
Low German                                    | nds            |                |                
Lower Burdekin                                | xbb            |                |                
Lower Chehalis                                | cea            |                |                
Lower Grand Valley Dani                       | dni            |                |                
Lower Nossob                                  | nsb            |                |                
Lower Silesian                                | sli            |                |                
Lower Sorbian                                 | dsb            |                |                
Lower Southern Aranda                         | axl            |                |                
Lower Ta'oih                                  | tto            |                |                
Lower Tanana                                  | taa            |                |                
Lowland Oaxaca Chontal                        | clo            |                |                
Lowland Tarahumara                            | tac            |                |                
Loxicha Zapotec                               | ztp            |                |                
Lozi                                          | loz            |                |                
Lua'                                          | prb            |                |                
Luang                                         | lex            |                |                
Luba-Katanga                                  | lub            | lu             |                
Luba-Lulua                                    | lua            |                |                
Lubila                                        | kcc            |                |                
Lubu                                          | lcf            |                |                
Lubuagan Kalinga                              | knb            |                |                
Luchazi                                       | lch            |                |                
Lucumi                                        | luq            |                |                
Ludian                                        | lud            |                |                
Lufu                                          | ldq            |                |                
Lugbara                                       | lgg            |                |                
Luguru                                        | ruf            |                |                
Luhu                                          | lcq            |                |                
Lui                                           | lba            |                |                
Luimbi                                        | lum            |                |                
Luiseno                                       | lui            |                |                
Lukpa                                         | dop            |                |                
Lule Sami                                     | smj            |                |                
Lule                                          | ule            |                |                
Lumba-Yakkha                                  | luu            |                |                
Lumbee                                        | lmz            |                |                
Lumbu                                         | lup            |                |                
Lumun                                         | lmd            |                |                
Luna                                          | luj            |                |                
Lunanakha                                     | luk            |                |                
Lunda                                         | lun            |                |                
Lundayeh                                      | lnd            |                |                
Lungalunga                                    | vmg            |                |                
Lungga                                        | lga            |                |                
Luo (Cameroon)                                | luw            |                |                
Luo (Kenya and Tanzania)                      | luo            |                |                
Luopohe Hmong                                 | hml            |                |                
Luri                                          | ldd            |                |                
Lusengo                                       | lse            |                |                
Lushai                                        | lus            |                |                
Lushootseed                                   | lut            |                |                
Lusi                                          | khl            |                |                
Lusitanian                                    | xls            |                |                
Lutos                                         | ndy            |                |                
Luvale                                        | lue            |                |                
Luwati                                        | luv            |                |                
Luwo                                          | lwo            |                |                
Luxembourgish                                 | ltz            | lb             |                
Luyana                                        | lyn            |                |                
Luyia                                         | luy            |                |                
Lwalu                                         | lwa            |                |                
Lycian                                        | xlc            |                |                
Lydian                                        | xld            |                |                
Lyngngam                                      | lyg            |                |                
Lyons Sign Language                           | lsg            |                |                
Lyélé                                         | lee            |                |                
Láadan                                        | ldn            |                |                
Láá Láá Bwamu                                 | bwj            |                |                
Lü                                            | khb            |                |                
Ma (Democratic Republic of Congo)             | msj            |                |                
Ma (Papua New Guinea)                         | mjn            |                |                
Ma Manda                                      | skc            |                |                
Ma'anyan                                      | mhy            |                |                
Ma'di                                         | mhi            |                |                
Ma'ya                                         | slz            |                |                
Maa                                           | cma            |                |                
Maaka                                         | mew            |                |                
Maasina Fulfulde                              | ffm            |                |                
Maay                                          | ymm            |                |                
Maba (Chad)                                   | mde            |                |                
Maba (Indonesia)                              | mqa            |                |                
Mabaale                                       | mmz            |                |                
Mabaan                                        | mfz            |                |                
Mabaka Valley Kalinga                         | kkg            |                |                
Mabire                                        | muj            |                |                
Maca                                          | mca            |                |                
Macaguaje                                     | mcl            |                |                
Macaguán                                      | mbn            |                |                
Macanese                                      | mzs            |                |                
Macedo-Romanian                               | rup            |                |                
Macedonian                                    | mac            | mk             | mkd            
Machame                                       | jmc            |                |                
Machiguenga                                   | mcb            |                |                
Machinere                                     | mpd            |                |                
Machinga                                      | mvw            |                |                
Maco                                          | wpc            |                |                
Macuna                                        | myy            |                |                
Macushi                                       | mbc            |                |                
Mada (Cameroon)                               | mxu            |                |                
Mada (Nigeria)                                | mda            |                |                
Madagascar Sign Language                      | mzc            |                |                
Madak                                         | mmx            |                |                
Madhi Madhi                                   | dmd            |                |                
Madi                                          | grg            |                |                
Madurese                                      | mad            |                |                
Mae                                           | mme            |                |                
Maek                                          | hmk            |                |                
Maeng Itneg                                   | itt            |                |                
Mafa                                          | maf            |                |                
Mafea                                         | mkv            |                |                
Mag-Indi Ayta                                 | blx            |                |                
Mag-antsi Ayta                                | sgb            |                |                
Magahi                                        | mag            |                |                
Magbukun Ayta                                 | ayt            |                |                
Magdalena Peñasco Mixtec                      | xtm            |                |                
Magoma                                        | gmx            |                |                
Magori                                        | zgr            |                |                
Maguindanaon                                  | mdh            |                |                
Magɨ (Madang Province)                        | gkd            |                |                
Magɨyi                                        | gmg            |                |                
Mahali                                        | mjx            |                |                
Mahasu Pahari                                 | bfz            |                |                
Mahei                                         | mja            |                |                
Mahican                                       | mjy            |                |                
Mahongwe                                      | mhb            |                |                
Mahou                                         | mxx            |                |                
Mai Brat                                      | ayz            |                |                
Maia                                          | sks            |                |                
Maiadomu                                      | mzz            |                |                
Maiani                                        | tnh            |                |                
Maii                                          | mmm            |                |                
Mailu                                         | mgu            |                |                
Maindo                                        | cwb            |                |                
Mainfränkisch                                 | vmf            |                |                
Mainstream Kenyah                             | xkl            |                |                
Mairasi                                       | zrs            |                |                
Maisin                                        | mbq            |                |                
Maithili                                      | mai            |                |                
Maiwa (Indonesia)                             | wmm            |                |                
Maiwa (Papua New Guinea)                      | mti            |                |                
Maiwala                                       | mum            |                |                
Majang                                        | mpe            |                |                
Majera                                        | xmj            |                |                
Majhi                                         | mjz            |                |                
Majhwar                                       | mmj            |                |                
Majukayang Kalinga                            | kmd            |                |                
Mak (China)                                   | mkg            |                |                
Mak (Nigeria)                                 | pbl            |                |                
Makaa                                         | mcp            |                |                
Makah                                         | myh            |                |                
Makalero                                      | mjb            |                |                
Makasae                                       | mkz            |                |                
Makasar                                       | mak            |                |                
Makassar Malay                                | mfp            |                |                
Makayam                                       | aup            |                |                
Makhuwa                                       | vmw            |                |                
Makhuwa-Marrevone                             | xmc            |                |                
Makhuwa-Meetto                                | mgh            |                |                
Makhuwa-Moniga                                | mhm            |                |                
Makhuwa-Saka                                  | xsq            |                |                
Makhuwa-Shirima                               | vmk            |                |                
Maklew                                        | mgf            |                |                
Makolkol                                      | zmh            |                |                
Makonde                                       | kde            |                |                
Maku'a                                        | lva            |                |                
Makuri Naga                                   | jmn            |                |                
Makuráp                                       | mpu            |                |                
Makwe                                         | ymk            |                |                
Makyan Naga                                   | umn            |                |                
Mal Paharia                                   | mkb            |                |                
Mal                                           | mlf            |                |                
Mala (Nigeria)                                | ruy            |                |                
Mala (Papua New Guinea)                       | ped            |                |                
Mala Malasar                                  | ima            |                |                
Malaccan Creole Malay                         | ccm            |                |                
Malaccan Creole Portuguese                    | mcm            |                |                
Malagasy                                      | mlg            | mg             |                
Malak Malak                                   | mpb            |                |                
Malakhel                                      | mld            |                |                
Malalamai                                     | mmt            |                |                
Malango                                       | mln            |                |                
Malankuravan                                  | mjo            |                |                
Malapandaram                                  | mjp            |                |                
Malaryan                                      | mjq            |                |                
Malas                                         | mkr            |                |                
Malasar                                       | ymr            |                |                
Malavedan                                     | mjr            |                |                
Malawi Lomwe                                  | lon            |                |                
Malawi Sena                                   | swk            |                |                
Malawian Sign Language                        | lws            |                |                
Malay (individual language)                   | zlm            |                |                
Malay (macrolanguage)                         | may            | ms             | msa            
Malayalam                                     | mal            | ml             |                
Malayic Dayak                                 | xdy            |                |                
Malaynon                                      | mlz            |                |                
Malayo                                        | mbp            |                |                
Malayo-Polynesian languages                   | poz            |                |                
Malaysian Sign Language                       | xml            |                |                
Malba Birifor                                 | bfo            |                |                
Male (Ethiopia)                               | mdy            |                |                
Male (Papua New Guinea)                       | mdc            |                |                
Malecite-Passamaquoddy                        | pqm            |                |                
Maleng                                        | pkt            |                |                
Maleu-Kilenge                                 | mgl            |                |                
Malfaxal                                      | mlx            |                |                
Malgana                                       | vml            |                |                
Malgbe                                        | mxf            |                |                
Mali                                          | gcc            |                |                
Maligo                                        | mwj            |                |                
Malila                                        | mgq            |                |                
Malimba                                       | mzd            |                |                
Malimpung                                     | mli            |                |                
Malinaltepec Me'phaa                          | tcf            |                |                
Malo                                          | mla            |                |                
Malol                                         | mbk            |                |                
Maltese Sign Language                         | mdl            |                |                
Maltese                                       | mlt            | mt             |                
Malua Bay                                     | mll            |                |                
Malvi                                         | mup            |                |                
Malyangapa                                    | yga            |                |                
Maléku Jaíka                                  | gut            |                |                
Mam                                           | mam            |                |                
Mama                                          | mma            |                |                
Mamaa                                         | mhf            |                |                
Mamaindé                                      | wmd            |                |                
Mamanwa                                       | mmn            |                |                
Mamara Senoufo                                | myk            |                |                
Mamasa                                        | mqj            |                |                
Mambae                                        | mgm            |                |                
Mambai                                        | mcs            |                |                
Mamboru                                       | mvd            |                |                
Mambwe-Lungu                                  | mgr            |                |                
Mampruli                                      | maw            |                |                
Mamuju                                        | mqx            |                |                
Mamulique                                     | emm            |                |                
Mamusi                                        | kdf            |                |                
Mamvu                                         | mdi            |                |                
Man Met                                       | mml            |                |                
Manado Malay                                  | xmm            |                |                
Manam                                         | mva            |                |                
Manambu                                       | mle            |                |                
Manangba                                      | nmm            |                |                
Manangkari                                    | znk            |                |                
Manchu                                        | mnc            |                |                
Manda (Australia)                             | zma            |                |                
Manda (India)                                 | mha            |                |                
Manda (Tanzania)                              | mgs            |                |                
Mandahuaca                                    | mht            |                |                
Mandaic                                       | mid            |                |                
Mandan                                        | mhq            |                |                
Mandandanyi                                   | zmk            |                |                
Mandar                                        | mdr            |                |                
Mandara                                       | tbf            |                |                
Mandari                                       | mqu            |                |                
Mandarin Chinese                              | cmn            |                |                
Mandaya                                       | mry            |                |                
Mande languages                               | dmn            |                |                
Mandeali                                      | mjl            |                |                
Mander                                        | mqr            |                |                
Mandingo                                      | man            |                |                
Mandinka                                      | mnk            |                |                
Mandjak                                       | mfv            |                |                
Mandobo Atas                                  | aax            |                |                
Mandobo Bawah                                 | bwp            |                |                
Manem                                         | jet            |                |                
Mang                                          | zng            |                |                
Manga Kanuri                                  | kby            |                |                
Mangala                                       | mem            |                |                
Mangareva                                     | mrv            |                |                
Mangarrayi                                    | mpc            |                |                
Mangas                                        | zns            |                |                
Mangayat                                      | myj            |                |                
Mangbetu                                      | mdj            |                |                
Mangbutu                                      | mdk            |                |                
Mangerr                                       | zme            |                |                
Mangetti Dune ǃXung                           | gfx            |                |                
Mangga Buang                                  | mmo            |                |                
Manggarai                                     | mqy            |                |                
Mango                                         | mge            |                |                
Mangole                                       | mqc            |                |                
Mangseng                                      | mbh            |                |                
Mangue                                        | mom            |                |                
Manichaean Middle Persian                     | xmn            |                |                
Manide                                        | abd            |                |                
Manikion                                      | mnx            |                |                
Manipa                                        | mqp            |                |                
Manipuri                                      | mni            |                |                
Mankanya                                      | knf            |                |                
Mankiyali                                     | nlm            |                |                
Manna-Dora                                    | mju            |                |                
Mannan                                        | mjv            |                |                
Mano                                          | mev            |                |                
Manobo languages                              | mno            |                |                
Manombai                                      | woo            |                |                
Mansaka                                       | msk            |                |                
Mansi                                         | mns            |                |                
Mansoanka                                     | msw            |                |                
Manta                                         | myg            |                |                
Mantsi                                        | nty            |                |                
Manumanaw Karen                               | kxf            |                |                
Manx                                          | glv            | gv             |                
Manya                                         | mzj            |                |                
Manyawa                                       | mny            |                |                
Manyika                                       | mxc            |                |                
Manza                                         | mzv            |                |                
Mao Naga                                      | nbi            |                |                
Maonan                                        | mmd            |                |                
Maore Comorian                                | swb            |                |                
Maori                                         | mao            | mi             | mri            
Mape                                          | mlh            |                |                
Mapena                                        | mnm            |                |                
Mapia                                         | mpy            |                |                
Mapidian                                      | mpw            |                |                
Mapos Buang                                   | bzh            |                |                
Mapoyo                                        | mcg            |                |                
Mapudungun                                    | arn            |                |                
Mapun                                         | sjm            |                |                
Maquiritari                                   | mch            |                |                
Mara Chin                                     | mrh            |                |                
Marachi                                       | lri            |                |                
Maraghei                                      | vmh            |                |                
Maragus                                       | mrs            |                |                
Maram Naga                                    | nma            |                |                
Marama                                        | lrm            |                |                
Maramba                                       | myd            |                |                
Maranao                                       | mrw            |                |                
Maranunggu                                    | zmr            |                |                
Mararit                                       | mgb            |                |                
Marathi                                       | mar            | mr             |                
Marau                                         | mvr            |                |                
Marba                                         | mpg            |                |                
Mardin Sign Language                          | dsz            |                |                
Maremgi                                       | mrx            |                |                
Marenje                                       | vmr            |                |                
Marfa                                         | mvu            |                |                
Margany                                       | zmc            |                |                
Marghi Central                                | mrt            |                |                
Marghi South                                  | mfm            |                |                
Margos-Yarowilca-Lauricocha Quechua           | qvm            |                |                
Margu                                         | mhg            |                |                
Mari (East Sepik Province)                    | mbx            |                |                
Mari (Madang Province)                        | hob            |                |                
Mari (Russia)                                 | chm            |                |                
Maria (India)                                 | mrr            |                |                
Maria (Papua New Guinea)                      | mds            |                |                
Maricopa                                      | mrc            |                |                
Maridan                                       | zmd            |                |                
Maridjabin                                    | zmj            |                |                
Marik                                         | dad            |                |                
Marimanindji                                  | zmm            |                |                
Marind                                        | mrz            |                |                
Maring Naga                                   | nng            |                |                
Maring                                        | mbw            |                |                
Maringarr                                     | zmt            |                |                
Marino                                        | mrb            |                |                
Mariri                                        | mqi            |                |                
Maritime Sign Language                        | nsr            |                |                
Maritsauá                                     | msp            |                |                
Mariyedi                                      | zmy            |                |                
Marka                                         | rkm            |                |                
Markweeta                                     | enb            |                |                
Marma                                         | rmz            |                |                
Marovo                                        | mvo            |                |                
Marra                                         | mec            |                |                
Marriammu                                     | xru            |                |                
Marrithiyel                                   | mfr            |                |                
Marrucinian                                   | umc            |                |                
Marshallese                                   | mah            | mh             |                
Marsian                                       | ims            |                |                
Martha's Vineyard Sign Language               | mre            |                |                
Marti Ke                                      | zmg            |                |                
Martu Wangka                                  | mpj            |                |                
Martuyhunira                                  | vma            |                |                
Maru                                          | mhx            |                |                
Marwari (India)                               | rwr            |                |                
Marwari (Pakistan)                            | mve            |                |                
Marwari                                       | mwr            |                |                
Marúbo                                        | mzr            |                |                
Masaaba                                       | myx            |                |                
Masadiit Itneg                                | tis            |                |                
Masai                                         | mas            |                |                
Masalit                                       | mls            |                |                
Masana                                        | mcn            |                |                
Masbatenyo                                    | msb            |                |                
Mashco Piro                                   | cuj            |                |                
Mashi (Nigeria)                               | jms            |                |                
Mashi (Zambia)                                | mho            |                |                
Masikoro Malagasy                             | msh            |                |                
Masimasi                                      | ism            |                |                
Masiwang                                      | bnf            |                |                
Maskelynes                                    | klv            |                |                
Maskoy Pidgin                                 | mhh            |                |                
Maslam                                        | msv            |                |                
Masmaje                                       | mes            |                |                
Massalat                                      | mdg            |                |                
Massep                                        | mvs            |                |                
Matagalpa                                     | mtn            |                |                
Matal                                         | mfh            |                |                
Matbat                                        | xmt            |                |                
Matengo                                       | mgv            |                |                
Matepi                                        | mqe            |                |                
Matigsalug Manobo                             | mbt            |                |                
Matipuhy                                      | mzo            |                |                
Matngala                                      | zml            |                |                
Mato Grosso Arára                             | axg            |                |                
Mato                                          | met            |                |                
Mator                                         | mtm            |                |                
Mator-Taygi-Karagas                           | ymt            |                |                
Matsés                                        | mcf            |                |                
Mattole                                       | mvb            |                |                
Matu Chin                                     | hlt            |                |                
Matukar                                       | mjk            |                |                
Matumbi                                       | mgw            |                |                
Matya Samo                                    | stj            |                |                
Matís                                         | mpq            |                |                
Maung                                         | mph            |                |                
Mauritian Sign Language                       | lsy            |                |                
Mauwake                                       | mhl            |                |                
Mawa (Chad)                                   | mcw            |                |                
Mawa (Nigeria)                                | wma            |                |                
Mawak                                         | mjj            |                |                
Mawan                                         | mcz            |                |                
Mawayana                                      | mzx            |                |                
Mawchi                                        | mke            |                |                
Mawes                                         | mgk            |                |                
Maxakalí                                      | mbl            |                |                
Maxi Gbe                                      | mxl            |                |                
Maya Samo                                     | sym            |                |                
Mayaguduna                                    | xmy            |                |                
Mayan languages                               | myn            |                |                
Mayangna                                      | yan            |                |                
Mayawali                                      | yxa            |                |                
Mayeka                                        | myc            |                |                
Mayi-Kulan                                    | xyk            |                |                
Mayi-Thakurti                                 | xyt            |                |                
Mayi-Yapi                                     | xyj            |                |                
Maykulan                                      | mnt            |                |                
Mayo                                          | mfy            |                |                
Mayogo                                        | mdm            |                |                
Mayoyao Ifugao                                | ifu            |                |                
Mazagway                                      | dkx            |                |                
Mazaltepec Zapotec                            | zpy            |                |                
Mazanderani                                   | mzn            |                |                
Mazatlán Mazatec                              | vmz            |                |                
Mazatlán Mixe                                 | mzl            |                |                
Mba                                           | mfc            |                |                
Mbala                                         | mdp            |                |                
Mbalanhu                                      | lnb            |                |                
Mbandja                                       | zmz            |                |                
Mbangala                                      | mxg            |                |                
Mbangi                                        | mgn            |                |                
Mbangwe                                       | zmn            |                |                
Mbara (Australia)                             | mvl            |                |                
Mbara (Chad)                                  | mpk            |                |                
Mbariman-Gudhinma                             | zmv            |                |                
Mbati                                         | mdn            |                |                
Mbato                                         | gwa            |                |                
Mbay                                          | myb            |                |                
Mbe                                           | mfo            |                |                
Mbe'                                          | mtk            |                |                
Mbelime                                       | mql            |                |                
Mbere                                         | mdt            |                |                
Mbesa                                         | zms            |                |                
Mbessa                                        | emz            |                |                
Mbo (Cameroon)                                | mbo            |                |                
Mbo (Democratic Republic of Congo)            | zmw            |                |                
Mboi                                          | moi            |                |                
Mboko                                         | mdu            |                |                
Mbole                                         | mdq            |                |                
Mbonga                                        | xmb            |                |                
Mbongno                                       | bgu            |                |                
Mbosi                                         | mdw            |                |                
Mbowe                                         | mxo            |                |                
Mbre                                          | mka            |                |                
Mbudum                                        | xmd            |                |                
Mbugu                                         | mhd            |                |                
Mbugwe                                        | mgz            |                |                
Mbuk                                          | bpc            |                |                
Mbuko                                         | mqb            |                |                
Mbukushu                                      | mhw            |                |                
Mbula                                         | mna            |                |                
Mbula-Bwazza                                  | mbu            |                |                
Mbule                                         | mlb            |                |                
Mbulungish                                    | mbv            |                |                
Mbum                                          | mdd            |                |                
Mbunda                                        | mck            |                |                
Mbunga                                        | mgy            |                |                
Mburku                                        | bbt            |                |                
Mbwela                                        | mfu            |                |                
Mbyá Guaraní                                  | gun            |                |                
Me'en                                         | mym            |                |                
Mea                                           | meg            |                |                
Medebur                                       | mjm            |                |                
Medefaidrin                                   | dmf            |                |                
Media Lengua                                  | mue            |                |                
Mediak                                        | mwx            |                |                
Median                                        | xme            |                |                
Mednyj Aleut                                  | mud            |                |                
Medumba                                       | byv            |                |                
Mefele                                        | mfj            |                |                
Megam                                         | mef            |                |                
Megleno Romanian                              | ruq            |                |                
Mehek                                         | nux            |                |                
Mehináku                                      | mmh            |                |                
Mehri                                         | gdq            |                |                
Mekeo                                         | mek            |                |                
Mekmek                                        | mvk            |                |                
Mekwei                                        | msf            |                |                
Mel-Khaonh                                    | hkn            |                |                
Mele-Fila                                     | mxe            |                |                
Melo                                          | mfx            |                |                
Melpa                                         | med            |                |                
Memoni                                        | mby            |                |                
Mendalam Kayan                                | xkd            |                |                
Mendankwe-Nkwen                               | mfd            |                |                
Mende (Papua New Guinea)                      | sim            |                |                
Mende (Sierra Leone)                          | men            |                |                
Mengaka                                       | xmg            |                |                
Mengen                                        | mee            |                |                
Mengisa                                       | mct            |                |                
Menka                                         | mea            |                |                
Menominee                                     | mez            |                |                
Mentawai                                      | mwv            |                |                
Menya                                         | mcr            |                |                
Meoswar                                       | mvx            |                |                
Mer                                           | mnu            |                |                
Meramera                                      | mxm            |                |                
Merei                                         | lmb            |                |                
Merey                                         | meq            |                |                
Meriam Mir                                    | ulk            |                |                
Merlav                                        | mrm            |                |                
Meroitic                                      | xmr            |                |                
Meru                                          | mer            |                |                
Merwari                                       | wry            |                |                
Mesaka                                        | iyo            |                |                
Mescalero-Chiricahua Apache                   | apm            |                |                
Mese                                          | mci            |                |                
Meskwaki                                      | sac            |                |                
Mesme                                         | zim            |                |                
Mesmes                                        | mys            |                |                
Mesopotamian Arabic                           | acm            |                |                
Mesqan                                        | mvz            |                |                
Messapic                                      | cms            |                |                
Meta'                                         | mgo            |                |                
Metlatónoc Mixtec                             | mxv            |                |                
Mewari                                        | mtr            |                |                
Mewati                                        | wtm            |                |                
Mexican Sign Language                         | mfs            |                |                
Meyah                                         | mej            |                |                
Mezontla Popoloca                             | pbe            |                |                
Mezquital Otomi                               | ote            |                |                
Mfinu                                         | zmf            |                |                
Mfumte                                        | nfu            |                |                
Mgbolizhia                                    | gmz            |                |                
Mi'kmaq                                       | mic            |                |                
Miahuatlán Zapotec                            | zam            |                |                
Miami                                         | mia            |                |                
Mian                                          | mpt            |                |                
Miani                                         | pla            |                |                
Michif                                        | crg            |                |                
Michigamea                                    | cmm            |                |                
Michoacán Mazahua                             | mmc            |                |                
Michoacán Nahuatl                             | ncl            |                |                
Mid Grand Valley Dani                         | dnt            |                |                
Mid-Southern Banda                            | bjo            |                |                
Middle Armenian                               | axm            |                |                
Middle Breton                                 | xbm            |                |                
Middle Cornish                                | cnx            |                |                
Middle Dutch (ca. 1050-1350)                  | dum            |                |                
Middle English (1100-1500)                    | enm            |                |                
Middle French (ca. 1400-1600)                 | frm            |                |                
Middle High German (ca. 1050-1500)            | gmh            |                |                
Middle Hittite                                | htx            |                |                
Middle Irish (900-1200)                       | mga            |                |                
Middle Khmer (1400 to 1850 CE)                | xhm            |                |                
Middle Korean (10th-16th cent.)               | okm            |                |                
Middle Low German                             | gml            |                |                
Middle Mongolian                              | xng            |                |                
Middle Newar                                  | nwx            |                |                
Middle Watut                                  | mpl            |                |                
Middle Welsh                                  | wlm            |                |                
Midob                                         | mei            |                |                
Migaama                                       | mmy            |                |                
Migabac                                       | mpp            |                |                
Migum                                         | klm            |                |                
Miju-Mishmi                                   | mxj            |                |                
Mikasuki                                      | mik            |                |                
Mili                                          | ymh            |                |                
Miltu                                         | mlj            |                |                
Miluk                                         | iml            |                |                
Milyan                                        | imy            |                |                
Min Bei Chinese                               | mnp            |                |                
Min Dong Chinese                              | cdo            |                |                
Min Nan Chinese                               | nan            |                |                
Min Zhong Chinese                             | czo            |                |                
Mina (Cameroon)                               | hna            |                |                
Mina (India)                                  | myi            |                |                
Minaean                                       | inm            |                |                
Minang                                        | xrg            |                |                
Minangkabau                                   | min            |                |                
Minanibai                                     | mcv            |                |                
Minaveha                                      | mvn            |                |                
Minderico                                     | drc            |                |                
Mindiri                                       | mpn            |                |                
Mingang Doso                                  | mko            |                |                
Mingrelian                                    | xmf            |                |                
Minica Huitoto                                | hto            |                |                
Minidien                                      | wii            |                |                
Minjungbal                                    | xjb            |                |                
Minkin                                        | xxm            |                |                
Minoan                                        | omn            |                |                
Minokok                                       | mqq            |                |                
Minriq                                        | mnq            |                |                
Mintil                                        | mzt            |                |                
Minz Zhuang                                   | zgm            |                |                
Miqie                                         | yiq            |                |                
Mirandese                                     | mwl            |                |                
Miraya Bikol                                  | rbl            |                |                
Mirgan                                        | zrg            |                |                
Miriti                                        | mmv            |                |                
Miriwoong Sign Language                       | rsm            |                |                
Miriwoong                                     | mep            |                |                
Mirning                                       | gmr            |                |                
Mirpur Panjabi                                | pmu            |                |                
Miship                                        | mjs            |                |                
Misima-Panaeati                               | mpx            |                |                
Mising                                        | mrg            |                |                
Mitla Zapotec                                 | zaw            |                |                
Mitlatongo Mixtec                             | vmm            |                |                
Mittu                                         | mwu            |                |                
Mituku                                        | zmq            |                |                
Miu                                           | mpo            |                |                
Miwa                                          | vmi            |                |                
Mixed Great Andamanese                        | gac            |                |                
Mixtepec Mixtec                               | mix            |                |                
Mixtepec Zapotec                              | zpm            |                |                
Miya                                          | mkf            |                |                
Miyako                                        | mvi            |                |                
Miyakubo Sign Language                        | ehs            |                |                
Miyobe                                        | soy            |                |                
Mlabri                                        | mra            |                |                
Mlahsö                                        | lhs            |                |                
Mlap                                          | kja            |                |                
Mlomp                                         | mlo            |                |                
Mmaala                                        | mmu            |                |                
Mmen                                          | bfm            |                |                
Mo'da                                         | gbn            |                |                
Moabite                                       | obm            |                |                
Moba                                          | mfq            |                |                
Mobilian                                      | mod            |                |                
Mobumrin Aizi                                 | ahm            |                |                
Mobwa Karen                                   | jkm            |                |                
Mochi                                         | old            |                |                
Mochica                                       | omc            |                |                
Mocho                                         | mhc            |                |                
Mocoví                                        | moc            |                |                
Modang                                        | mxd            |                |                
Modole                                        | mqo            |                |                
Moere                                         | mvq            |                |                
Mofu-Gudur                                    | mif            |                |                
Mogholi                                       | mhj            |                |                
Mogofin                                       | mfg            |                |                
Mogum                                         | mou            |                |                
Mohave                                        | mov            |                |                
Mohawk                                        | moh            |                |                
Mohegan-Montauk-Narragansett                  | mof            |                |                
Mohegan-Pequot                                | xpq            |                |                
Moi (Congo)                                   | mow            |                |                
Moi (Indonesia)                               | mxn            |                |                
Moikodi                                       | mkp            |                |                
Moingi                                        | mwz            |                |                
Moji                                          | ymi            |                |                
Mok                                           | mqt            |                |                
Moken                                         | mwt            |                |                
Mokerang                                      | mft            |                |                
Mokilese                                      | mkj            |                |                
Moklen                                        | mkm            |                |                
Mokole                                        | mkl            |                |                
Mokpwe                                        | bri            |                |                
Moksela                                       | vms            |                |                
Moksha                                        | mdf            |                |                
Molale                                        | mbe            |                |                
Molbog                                        | pwm            |                |                
Moldova Sign Language                         | vsi            |                |                
Molengue                                      | bxc            |                |                
Molima                                        | mox            |                |                
Molmo One                                     | aun            |                |                
Molo                                          | zmo            |                |                
Molof                                         | msl            |                |                
Moloko                                        | mlw            |                |                
Mom Jango                                     | ver            |                |                
Moma                                          | myl            |                |                
Momare                                        | msz            |                |                
Mombo Dogon                                   | dmb            |                |                
Mombum                                        | mso            |                |                
Momina                                        | mmb            |                |                
Momuna                                        | mqf            |                |                
Mon                                           | mnw            |                |                
Mon-Khmer languages                           | mkh            |                |                
Monastic Sign Language                        | mzg            |                |                
Mondropolon                                   | npn            |                |                
Mondé                                         | mnd            |                |                
Mongo                                         | lol            |                |                
Mongol                                        | mgt            |                |                
Mongolia Buriat                               | bxm            |                |                
Mongolian Sign Language                       | msr            |                |                
Mongolian languages                           | xgn            |                |                
Mongolian                                     | mon            | mn             |                
Mongondow                                     | mog            |                |                
Moni                                          | mnz            |                |                
Mono (Cameroon)                               | mru            |                |                
Mono (Democratic Republic of Congo)           | mnh            |                |                
Mono (Solomon Islands)                        | mte            |                |                
Mono (USA)                                    | mnr            |                |                
Monom                                         | moo            |                |                
Monsang Naga                                  | nmh            |                |                
Montenegrin                                   | cnr            |                |                
Montol                                        | mtl            |                |                
Monumbo                                       | mxk            |                |                
Monzombo                                      | moj            |                |                
Moo                                           | gwg            |                |                
Moose Cree                                    | crm            |                |                
Mopán Maya                                    | mop            |                |                
Mor (Bomberai Peninsula)                      | moq            |                |                
Mor (Mor Islands)                             | mhz            |                |                
Moraid                                        | msg            |                |                
Morawa                                        | mze            |                |                
Morelos Nahuatl                               | nhm            |                |                
Morerebi                                      | xmo            |                |                
Moresada                                      | msx            |                |                
Mori Atas                                     | mzq            |                |                
Mori Bawah                                    | xmz            |                |                
Morigi                                        | mdb            |                |                
Morisyen                                      | mfe            |                |                
Moro                                          | mor            |                |                
Moroccan Arabic                               | ary            |                |                
Moroccan Sign Language                        | xms            |                |                
Morokodo                                      | mgc            |                |                
Morom                                         | bdo            |                |                
Moronene                                      | mqn            |                |                
Morori                                        | mok            |                |                
Morouas                                       | mrp            |                |                
Morrobalama                                   | umg            |                |                
Mortlockese                                   | mrl            |                |                
Moru                                          | mgd            |                |                
Mosimo                                        | mqv            |                |                
Mosiro                                        | mwy            |                |                
Moskona                                       | mtj            |                |                
Mossi                                         | mos            |                |                
Mota                                          | mtt            |                |                
Motlav                                        | mlv            |                |                
Motu                                          | meu            |                |                
Mouk-Aria                                     | mwh            |                |                
Moundadan Chetty                              | cty            |                |                
Mountain Koiali                               | kpx            |                |                
Mouwase                                       | jmw            |                |                
Movima                                        | mzp            |                |                
Moyadan Itneg                                 | ity            |                |                
Moyon Naga                                    | nmo            |                |                
Mozambican Sign Language                      | mzy            |                |                
Mozarabic                                     | mxi            |                |                
Mpade                                         | mpi            |                |                
Mpalitjanh                                    | xpj            |                |                
Mpi                                           | mpz            |                |                
Mpiemo                                        | mcx            |                |                
Mpinda                                        | pnd            |                |                
Mpoto                                         | mpa            |                |                
Mpotovoro                                     | mvt            |                |                
Mpumpong                                      | mgg            |                |                
Mpuono                                        | zmp            |                |                
Mpur                                          | akc            |                |                
Mro-Khimi Chin                                | cmr            |                |                
Mru                                           | mro            |                |                
Mser                                          | kqx            |                |                
Mt. Iraya Agta                                | atl            |                |                
Mt. Iriga Agta                                | agz            |                |                
Muak Sa-aak                                   | ukk            |                |                
Mualang                                       | mtd            |                |                
Mubami                                        | tsx            |                |                
Mubi                                          | mub            |                |                
Muda                                          | ymd            |                |                
Mudbura                                       | mwd            |                |                
Mudburra                                      | dmw            |                |                
Mudhili Gadaba                                | gau            |                |                
Mudu Koraga                                   | vmd            |                |                
Muduga                                        | udg            |                |                
Mufian                                        | aoj            |                |                
Mugom                                         | muk            |                |                
Muinane                                       | bmr            |                |                
Mukha-Dora                                    | mmk            |                |                
Mukulu                                        | moz            |                |                
Mulaha                                        | mfw            |                |                
Mulam                                         | mlm            |                |                
Mulao                                         | giu            |                |                
Mulgi                                         | mvh            |                |                
Mullu Kurumba                                 | kpb            |                |                
Multiple languages                            | mul            |                |                
Muluridyi                                     | vmu            |                |                
Mum                                           | kqa            |                |                
Mumuye                                        | mzm            |                |                
Muna                                          | mnb            |                |                
Munda languages                               | mun            |                |                
Munda                                         | unx            |                |                
Mundabli                                      | boe            |                |                
Mundang                                       | mua            |                |                
Mundani                                       | mnf            |                |                
Mundari                                       | unr            |                |                
Mundat                                        | mmf            |                |                
Mundurukú                                     | myu            |                |                
Mungaka                                       | mhk            |                |                
Munggui                                       | mth            |                |                
Mungkip                                       | mpv            |                |                
Muniche                                       | myr            |                |                
Munit                                         | mtc            |                |                
Munji                                         | mnj            |                |                
Munsee                                        | umu            |                |                
Muong                                         | mtq            |                |                
Mur Pano                                      | tkv            |                |                
Muratayak                                     | asx            |                |                
Murik (Malaysia)                              | mxr            |                |                
Murik (Papua New Guinea)                      | mtf            |                |                
Murkim                                        | rmh            |                |                
Murle                                         | mur            |                |                
Murrinh-Patha                                 | mwf            |                |                
Mursi                                         | muz            |                |                
Murui Huitoto                                 | huu            |                |                
Murupi                                        | mqw            |                |                
Muruwari                                      | zmu            |                |                
Musak                                         | mmq            |                |                
Musar                                         | mmi            |                |                
Musasa                                        | smm            |                |                
Musey                                         | mse            |                |                
Musgu                                         | mug            |                |                
Mushungulu                                    | xma            |                |                
Musi                                          | mui            |                |                
Muskum                                        | mje            |                |                
Muslim Tat                                    | ttt            |                |                
Musom                                         | msu            |                |                
Mussau-Emira                                  | emi            |                |                
Muthuvan                                      | muv            |                |                
Mutu                                          | tuc            |                |                
Muya                                          | mvm            |                |                
Muyang                                        | muy            |                |                
Muyuw                                         | myw            |                |                
Muzi                                          | ymz            |                |                
Mvanip                                        | mcj            |                |                
Mvuba                                         | mxh            |                |                
Mwaghavul                                     | sur            |                |                
Mwali Comorian                                | wlc            |                |                
Mwan                                          | moa            |                |                
Mwani                                         | wmw            |                |                
Mwatebu                                       | mwa            |                |                
Mwera (Chimwera)                              | mwe            |                |                
Mwera (Nyasa)                                 | mjh            |                |                
Mwimbi-Muthambi                               | mws            |                |                
Myanmar Sign Language                         | ysm            |                |                
Mycenaean Greek                               | gmy            |                |                
Myene                                         | mye            |                |                
Mysian                                        | yms            |                |                
Mzieme Naga                                   | nme            |                |                
Mághdì                                        | gmd            |                |                
Máku                                          | xak            |                |                
Ménik                                         | tnr            |                |                
Mískito                                       | miq            |                |                
Mócheno                                       | mhn            |                |                
Mün Chin                                      | mwq            |                |                
Mündü                                         | muh            |                |                
Māhārāṣṭri Prākrit                            | pmh            |                |                
N'Ko                                          | nqo            |                |                
Na                                            | nbt            |                |                
Na-Dene languages                             | xnd            |                |                
Na-kara                                       | nck            |                |                
Naaba                                         | nao            |                |                
Naami                                         | bzv            |                |                
Naasioi                                       | nas            |                |                
Naba                                          | mne            |                |                
Nabak                                         | naf            |                |                
Nabi                                          | mty            |                |                
Nachering                                     | ncd            |                |                
Nadruvian                                     | ndf            |                |                
Nadëb                                         | mbj            |                |                
Nafaanra                                      | nfr            |                |                
Nafi                                          | srf            |                |                
Nafri                                         | nxx            |                |                
Nafusi                                        | jbn            |                |                
Naga Pidgin                                   | nag            |                |                
Nagarchal                                     | nbg            |                |                
Nage                                          | nxe            |                |                
Nagumi                                        | ngv            |                |                
Nahali                                        | nlx            |                |                
Nahari                                        | nhh            |                |                
Nahuatl languages                             | nah            |                |                
Nai                                           | bio            |                |                
Najdi Arabic                                  | ars            |                |                
Naka'ela                                      | nae            |                |                
Nakai                                         | nkj            |                |                
Nakame                                        | nib            |                |                
Nakanai                                       | nak            |                |                
Nake                                          | nbk            |                |                
Naki                                          | mff            |                |                
Nakwi                                         | nax            |                |                
Nalca                                         | nlc            |                |                
Nali                                          | nss            |                |                
Nalik                                         | nal            |                |                
Nalu                                          | naj            |                |                
Naluo Yi                                      | ylo            |                |                
Nalögo                                        | nlz            |                |                
Nama (Papua New Guinea)                       | nmx            |                |                
Namakura                                      | nmk            |                |                
Namat                                         | nkm            |                |                
Nambo                                         | ncm            |                |                
Nambya                                        | nmq            |                |                
Namia                                         | nnm            |                |                
Namiae                                        | nvm            |                |                
Namibian Sign Language                        | nbs            |                |                
Namla                                         | naa            |                |                
Namo                                          | mxw            |                |                
Namonuito                                     | nmt            |                |                
Namosi-Naitasiri-Serua                        | bwb            |                |                
Namuyi                                        | nmy            |                |                
Nanai                                         | gld            |                |                
Nancere                                       | nnc            |                |                
Nande                                         | nnb            |                |                
Nandi                                         | niq            |                |                
Nanerigé Sénoufo                              | sen            |                |                
Nanga Dama Dogon                              | nzz            |                |                
Nankina                                       | nnk            |                |                
Nanti                                         | cox            |                |                
Nanticoke                                     | nnt            |                |                
Nanubae                                       | afk            |                |                
Napo Lowland Quechua                          | qvo            |                |                
Napu                                          | npy            |                |                
Nar Phu                                       | npa            |                |                
Nara                                          | nrb            |                |                
Narak                                         | nac            |                |                
Narango                                       | nrg            |                |                
Narau                                         | nxu            |                |                
Nari Nari                                     | rnr            |                |                
Narim                                         | loh            |                |                
Naro                                          | nhr            |                |                
Narom                                         | nrm            |                |                
Narragansett                                  | xnt            |                |                
Narua                                         | nru            |                |                
Narungga                                      | nnr            |                |                
Nasal                                         | nsy            |                |                
Nasarian                                      | nvh            |                |                
Naskapi                                       | nsk            |                |                
Natagaimas                                    | nts            |                |                
Natanzi                                       | ntz            |                |                
Nataoran Amis                                 | ais            |                |                
Natchez                                       | ncz            |                |                
Nateni                                        | ntm            |                |                
Nathembo                                      | nte            |                |                
Natioro                                       | nti            |                |                
Natügu                                        | ntu            |                |                
Nauete                                        | nxa            |                |                
Naukan Yupik                                  | ynk            |                |                
Nauna                                         | ncn            |                |                
Nauo                                          | nwo            |                |                
Nauru                                         | nau            | na             |                
Navajo                                        | nav            | nv             |                
Navut                                         | nsw            |                |                
Nawaru                                        | nwr            |                |                
Nawathinehena                                 | nwa            |                |                
Nawdm                                         | nmz            |                |                
Nawuri                                        | naw            |                |                
Naxi                                          | nbf            |                |                
Naxi                                          | nxq            |                |                
Nayi                                          | noz            |                |                
Nayini                                        | nyq            |                |                
Ncane                                         | ncr            |                |                
Nchumbulu                                     | nlu            |                |                
Nda'nda'                                      | nnz            |                |                
Ndai                                          | gke            |                |                
Ndaka                                         | ndk            |                |                
Ndaktup                                       | ncp            |                |                
Ndali                                         | ndh            |                |                
Ndam                                          | ndm            |                |                
Ndamba                                        | ndj            |                |                
Ndambomo                                      | nxo            |                |                
Ndasa                                         | nda            |                |                
Ndau                                          | ndc            |                |                
Nde-Gbite                                     | ned            |                |                
Nde-Nsele-Nta                                 | ndd            |                |                
Ndemli                                        | nml            |                |                
Ndendeule                                     | dne            |                |                
Ndengereko                                    | ndg            |                |                
Nding                                         | eli            |                |                
Ndo                                           | ndp            |                |                
Ndobo                                         | ndw            |                |                
Ndoe                                          | nbb            |                |                
Ndogo                                         | ndz            |                |                
Ndolo                                         | ndl            |                |                
Ndom                                          | nqm            |                |                
Ndombe                                        | ndq            |                |                
Ndonde Hamba                                  | njd            |                |                
Ndonga                                        | ndo            | ng             |                
Ndoola                                        | ndr            |                |                
Ndra'ngith                                    | dgt            |                |                
Ndrulo                                        | dno            |                |                
Nduga                                         | ndx            |                |                
Ndumu                                         | nmd            |                |                
Ndunda                                        | nuh            |                |                
Ndunga                                        | ndt            |                |                
Ndut                                          | ndv            |                |                
Ndwewe                                        | nww            |                |                
Ndyuka-Trio Pidgin                            | njt            |                |                
Ndzwani Comorian                              | wni            |                |                
Neapolitan                                    | nap            |                |                
Nedebang                                      | nec            |                |                
Nefamese                                      | nef            |                |                
Negerhollands                                 | dcr            |                |                
Negeri Sembilan Malay                         | zmi            |                |                
Negidal                                       | neg            |                |                
Nehan                                         | nsn            |                |                
Nek                                           | nif            |                |                
Nekgini                                       | nkg            |                |                
Neko                                          | nej            |                |                
Neku                                          | nek            |                |                
Nema                                          | gsn            |                |                
Neme                                          | nex            |                |                
Nemi                                          | nem            |                |                
Nen                                           | nqn            |                |                
Nend                                          | anh            |                |                
Nenets                                        | yrk            |                |                
Nengone                                       | nen            |                |                
Neo                                           | neu            |                |                
Neo-Hittite                                   | nei            |                |                
Nepalese Sign Language                        | nsp            |                |                
Nepali (individual language)                  | npi            |                |                
Nepali (macrolanguage)                        | nep            | ne             |                
Nepali Kurux                                  | kxl            |                |                
Nete                                          | net            |                |                
New Caledonian Javanese                       | jas            |                |                
New Zealand Sign Language                     | nzs            |                |                
Newari                                        | new            |                |                
Neyo                                          | ney            |                |                
Nez Perce                                     | nez            |                |                
Ngaanyatjarra                                 | ntj            |                |                
Ngad'a                                        | nxg            |                |                
Ngadjunmaya                                   | nju            |                |                
Ngadjuri                                      | jui            |                |                
Ngaing                                        | nnf            |                |                
Ngaju                                         | nij            |                |                
Ngala                                         | nud            |                |                
Ngalakgan                                     | nig            |                |                
Ngalum                                        | szb            |                |                
Ngam                                          | nmc            |                |                
Ngamambo                                      | nbv            |                |                
Ngambay                                       | sba            |                |                
Ngamini                                       | nmv            |                |                
Ngamo                                         | nbh            |                |                
Ngan'gityemerri                               | nam            |                |                
Nganakarti                                    | xnk            |                |                
Nganasan                                      | nio            |                |                
Ngandi                                        | nid            |                |                
Ngando (Central African Republic)             | ngd            |                |                
Ngando (Democratic Republic of Congo)         | nxd            |                |                
Ngandyera                                     | nne            |                |                
Ngangam                                       | gng            |                |                
Ngantangarra                                  | ntg            |                |                
Nganyaywana                                   | nyx            |                |                
Ngardi                                        | rxd            |                |                
Ngarigu                                       | xni            |                |                
Ngarinyin                                     | ung            |                |                
Ngarinyman                                    | nbj            |                |                
Ngarla                                        | nlr            |                |                
Ngarla                                        | nrk            |                |                
Ngarluma                                      | nrl            |                |                
Ngarrindjeri                                  | nay            |                |                
Ngas                                          | anc            |                |                
Ngasa                                         | nsg            |                |                
Ngatik Men's Creole                           | ngm            |                |                
Ngawn Chin                                    | cnw            |                |                
Ngawun                                        | nxn            |                |                
Ngayawung                                     | nwg            |                |                
Ngazidja Comorian                             | zdj            |                |                
Ngbaka Ma'bo                                  | nbm            |                |                
Ngbaka Manza                                  | ngg            |                |                
Ngbaka                                        | nga            |                |                
Ngbee                                         | jgb            |                |                
Ngbinda                                       | nbd            |                |                
Ngbundu                                       | nuu            |                |                
Ngelima                                       | agh            |                |                
Ngemba                                        | nge            |                |                
Ngen                                          | gnj            |                |                
Ngendelengo                                   | nql            |                |                
Ngete                                         | nnn            |                |                
Nggem                                         | nbq            |                |                
Nggwahyi                                      | ngx            |                |                
Ngie                                          | ngj            |                |                
Ngiemboon                                     | nnh            |                |                
Ngile                                         | jle            |                |                
Ngindo                                        | nnq            |                |                
Ngiti                                         | niy            |                |                
Ngizim                                        | ngi            |                |                
Ngkâlmpw Kanum                                | kcd            |                |                
Ngom                                          | nra            |                |                
Ngomba                                        | jgo            |                |                
Ngombale                                      | nla            |                |                
Ngombe (Central African Republic)             | nmj            |                |                
Ngombe (Democratic Republic of Congo)         | ngc            |                |                
Ngong                                         | nnx            |                |                
Ngongo                                        | noq            |                |                
Ngoni (Mozambique)                            | xnq            |                |                
Ngoni (Tanzania)                              | xnj            |                |                
Ngoni                                         | ngo            |                |                
Ngoshie                                       | nsh            |                |                
Ngul                                          | nlo            |                |                
Ngulu                                         | ngp            |                |                
Nguluwan                                      | nuw            |                |                
Ngumbarl                                      | xnm            |                |                
Ngumbi                                        | nui            |                |                
Ngunawal                                      | xul            |                |                
Ngundi                                        | ndn            |                |                
Ngundu                                        | nue            |                |                
Ngungwel                                      | ngz            |                |                
Ngura                                         | nbx            |                |                
Ngurimi                                       | ngq            |                |                
Ngurmbur                                      | nrx            |                |                
Nguôn                                         | nuo            |                |                
Ngwaba                                        | ngw            |                |                
Ngwe                                          | nwe            |                |                
Ngwo                                          | ngn            |                |                
Ngäbere                                       | gym            |                |                
Nhanda                                        | nha            |                |                
Nhengatu                                      | yrl            |                |                
Nhirrpi                                       | hrp            |                |                
Nhuwala                                       | nhf            |                |                
Nias                                          | nia            |                |                
Nicaragua Creole English                      | bzk            |                |                
Nicaraguan Sign Language                      | ncs            |                |                
Niellim                                       | nie            |                |                
Niger-Kordofanian languages                   | nic            |                |                
Nigeria Mambila                               | mzk            |                |                
Nigerian Fulfulde                             | fuv            |                |                
Nigerian Pidgin                               | pcm            |                |                
Nigerian Sign Language                        | nsi            |                |                
Nihali                                        | nll            |                |                
Nii                                           | nii            |                |                
Nijadali                                      | nad            |                |                
Niksek                                        | gbe            |                |                
Nila                                          | nil            |                |                
Nilamba                                       | nim            |                |                
Nilo-Saharan languages                        | ssa            |                |                
Nimadi                                        | noe            |                |                
Nimanbur                                      | nmp            |                |                
Nimbari                                       | nmr            |                |                
Nimboran                                      | nir            |                |                
Nimi                                          | nis            |                |                
Nimo                                          | niw            |                |                
Nimoa                                         | nmw            |                |                
Ninam                                         | shb            |                |                
Nindi                                         | nxi            |                |                
Ningera                                       | nby            |                |                
Ninggerum                                     | nxr            |                |                
Ningil                                        | niz            |                |                
Ningye                                        | nns            |                |                
Ninia Yali                                    | nlk            |                |                
Ninzo                                         | nin            |                |                
Nipsan                                        | nps            |                |                
Nisa                                          | njs            |                |                
Nisenan                                       | nsz            |                |                
Nisga'a                                       | ncg            |                |                
Nisi (China)                                  | yso            |                |                
Nisi (India)                                  | dap            |                |                
Niuafo'ou                                     | num            |                |                
Niuatoputapu                                  | nkp            |                |                
Niuean                                        | niu            |                |                
Nivaclé                                       | cag            |                |                
Niwer Mil                                     | hrc            |                |                
Njalgulgule                                   | njl            |                |                
Njebi                                         | nzb            |                |                
Njen                                          | njj            |                |                
Njerep                                        | njr            |                |                
Njyem                                         | njy            |                |                
Nkami                                         | nkq            |                |                
Nkangala                                      | nkn            |                |                
Nkari                                         | nkz            |                |                
Nkem-Nkum                                     | isi            |                |                
Nkhumbi                                       | khu            |                |                
Nkongho                                       | nkc            |                |                
Nkonya                                        | nko            |                |                
Nkoroo                                        | nkx            |                |                
Nkoya                                         | nka            |                |                
Nkukoli                                       | nbo            |                |                
Nkutu                                         | nkw            |                |                
Nnam                                          | nbp            |                |                
No linguistic content                         | zxx            |                |                
Nobiin                                        | fia            |                |                
Nobonob                                       | gaw            |                |                
Nocamán                                       | nom            |                |                
Nocte Naga                                    | njb            |                |                
Nogai                                         | nog            |                |                
Noipx                                         | npx            |                |                
Noiri                                         | noi            |                |                
Nokuku                                        | nkk            |                |                
Nomaande                                      | lem            |                |                
Nomane                                        | nof            |                |                
Nomatsiguenga                                 | not            |                |                
Nomlaki                                       | nol            |                |                
Nomu                                          | noh            |                |                
Nong Zhuang                                   | zhn            |                |                
Nonuya                                        | noj            |                |                
Nooksack                                      | nok            |                |                
Noon                                          | snf            |                |                
Noone                                         | nhu            |                |                
Nootka                                        | noo            |                |                
Nopala Chatino                                | cya            |                |                
Noric                                         | nrc            |                |                
Norn                                          | nrn            |                |                
Norra                                         | nrr            |                |                
North Alaskan Inupiatun                       | esi            |                |                
North Ambrym                                  | mmg            |                |                
North American Indian languages               | nai            |                |                
North Asmat                                   | nks            |                |                
North Awyu                                    | yir            |                |                
North Azerbaijani                             | azj            |                |                
North Babar                                   | bcd            |                |                
North Bolivian Quechua                        | qul            |                |                
North Caucasian languages                     | ccn            |                |                
North Central Mixe                            | neq            |                |                
North Efate                                   | llp            |                |                
North Fali                                    | fll            |                |                
North Germanic languages                      | gmq            |                |                
North Giziga                                  | gis            |                |                
North Junín Quechua                           | qvn            |                |                
North Levantine Arabic                        | apc            |                |                
North Marquesan                               | mrq            |                |                
North Mesopotamian Arabic                     | ayp            |                |                
North Midlands Tasmanian                      | xph            |                |                
North Mofu                                    | mfk            |                |                
North Moluccan Malay                          | max            |                |                
North Muyu                                    | kti            |                |                
North Ndebele                                 | nde            | nd             |                
North Nuaulu                                  | nni            |                |                
North Picene                                  | nrp            |                |                
North Slavey                                  | scs            |                |                
North Tairora                                 | tbg            |                |                
North Tanna                                   | tnn            |                |                
North Wahgi                                   | whg            |                |                
North Watut                                   | una            |                |                
Northeast Kiwai                               | kiw            |                |                
Northeast Maidu                               | nmu            |                |                
Northeast Pashai                              | aee            |                |                
Northeastern Dinka                            | dip            |                |                
Northeastern Pomo                             | pef            |                |                
Northeastern Tasmanian                        | xpb            |                |                
Northeastern Thai                             | tts            |                |                
Northern Alta                                 | aqn            |                |                
Northern Altai                                | atv            |                |                
Northern Amami-Oshima                         | ryn            |                |                
Northern Betsimisaraka Malagasy               | bmm            |                |                
Northern Binukidnon                           | kyn            |                |                
Northern Bobo Madaré                          | bbo            |                |                
Northern Bontok                               | rbk            |                |                
Northern Catanduanes Bikol                    | cts            |                |                
Northern Conchucos Ancash Quechua             | qxn            |                |                
Northern Dagara                               | dgi            |                |                
Northern Dong                                 | doc            |                |                
Northern East Cree                            | crl            |                |                
Northern Emberá                               | emp            |                |                
Northern Frisian                              | frr            |                |                
Northern Ghale                                | ghh            |                |                
Northern Gondi                                | gno            |                |                
Northern Grebo                                | gbo            |                |                
Northern Guiyang Hmong                        | huj            |                |                
Northern Haida                                | hdn            |                |                
Northern Hindko                               | hno            |                |                
Northern Huishui Hmong                        | hmi            |                |                
Northern Kalapuya                             | nrt            |                |                
Northern Kankanay                             | xnn            |                |                
Northern Katang                               | ncq            |                |                
Northern Khmer                                | kxm            |                |                
Northern Kissi                                | kqs            |                |                
Northern Kurdish                              | kmr            |                |                
Northern Luri                                 | lrc            |                |                
Northern Mashan Hmong                         | hmp            |                |                
Northern Muji                                 | ymx            |                |                
Northern Nago                                 | xkb            |                |                
Northern Ngbandi                              | ngb            |                |                
Northern Nisu                                 | yiv            |                |                
Northern Nuni                                 | nuv            |                |                
Northern Oaxaca Nahuatl                       | nhy            |                |                
Northern Ohlone                               | cst            |                |                
Northern One                                  | onr            |                |                
Northern Paiute                               | pao            |                |                
Northern Pame                                 | pmq            |                |                
Northern Pashto                               | pbu            |                |                
Northern Pastaza Quichua                      | qvz            |                |                
Northern Ping Chinese                         | cnp            |                |                
Northern Pomo                                 | pej            |                |                
Northern Puebla Nahuatl                       | ncj            |                |                
Northern Pumi                                 | pmi            |                |                
Northern Qiandong Miao                        | hea            |                |                
Northern Qiang                                | cng            |                |                
Northern Rengma Naga                          | nnl            |                |                
Northern Roglai                               | rog            |                |                
Northern Sami                                 | sme            | se             |                
Northern Sierra Miwok                         | nsq            |                |                
Northern Sorsoganon                           | bks            |                |                
Northern Subanen                              | stb            |                |                
Northern Tarahumara                           | thh            |                |                
Northern Tasmanian                            | xpv            |                |                
Northern Tepehuan                             | ntp            |                |                
Northern Thai                                 | nod            |                |                
Northern Tidung                               | ntd            |                |                
Northern Tiwa                                 | twf            |                |                
Northern Tlaxiaco Mixtec                      | xtn            |                |                
Northern Toussian                             | tsp            |                |                
Northern Tujia                                | tji            |                |                
Northern Tutchone                             | ttm            |                |                
Northern Uzbek                                | uzn            |                |                
Northern Yukaghir                             | ykg            |                |                
Northwest Alaska Inupiatun                    | esk            |                |                
Northwest Gbaya                               | gya            |                |                
Northwest Maidu                               | mjd            |                |                
Northwest Oaxaca Mixtec                       | mxa            |                |                
Northwest Pashai                              | glh            |                |                
Northwestern Dinka                            | diw            |                |                
Northwestern Fars                             | faz            |                |                
Northwestern Kolami                           | kfb            |                |                
Northwestern Nisu                             | nsf            |                |                
Northwestern Ojibwa                           | ojb            |                |                
Northwestern Tamang                           | tmk            |                |                
Northwestern Tasmanian                        | xpw            |                |                
Norwegian Bokmål                              | nob            | nb             |                
Norwegian Nynorsk                             | nno            | nn             |                
Norwegian Sign Language                       | nsl            |                |                
Norwegian                                     | nor            | no             |                
Notre                                         | bly            |                |                
Notsi                                         | ncf            |                |                
Nottoway                                      | ntw            |                |                
Nottoway-Meherrin                             | nwy            |                |                
Novial                                        | nov            |                |                
Noy                                           | noy            |                |                
Nsenga                                        | nse            |                |                
Nshi                                          | nsc            |                |                
Nsongo                                        | nsx            |                |                
Ntcham                                        | bud            |                |                
Nteng                                         | nqt            |                |                
Ntomba                                        | nto            |                |                
Nubaca                                        | baf            |                |                
Nubi                                          | kcn            |                |                
Nubian languages                              | nub            |                |                
Nubri                                         | kte            |                |                
Nuer                                          | nus            |                |                
Nugunu (Australia)                            | nnv            |                |                
Nugunu (Cameroon)                             | yas            |                |                
Nuk                                           | noc            |                |                
Nukak Makú                                    | mbr            |                |                
Nukna                                         | klt            |                |                
Nukuini                                       | nuc            |                |                
Nukumanu                                      | nuq            |                |                
Nukunul                                       | xnu            |                |                
Nukuoro                                       | nkr            |                |                
Nukuria                                       | nur            |                |                
Numana                                        | nbr            |                |                
Numanggang                                    | nop            |                |                
Numbami                                       | sij            |                |                
Nume                                          | tgs            |                |                
Numidian                                      | nxm            |                |                
Numèè                                         | kdk            |                |                
Nung (Viet Nam)                               | nut            |                |                
Nungali                                       | nug            |                |                
Nunggubuyu                                    | nuy            |                |                
Nungu                                         | rin            |                |                
Nupbikha                                      | npb            |                |                
Nupe-Nupe-Tako                                | nup            |                |                
Nusa Laut                                     | nul            |                |                
Nusu                                          | nuf            |                |                
Nuu-chah-nulth                                | nuk            |                |                
Nyabwa                                        | nwb            |                |                
Nyaheun                                       | nev            |                |                
Nyahkur                                       | cbn            |                |                
Nyakyusa-Ngonde                               | nyy            |                |                
Nyali                                         | nlj            |                |                
Nyam                                          | nmi            |                |                
Nyamal                                        | nly            |                |                
Nyambo                                        | now            |                |                
Nyamusa-Molo                                  | nwm            |                |                
Nyamwanga                                     | mwn            |                |                
Nyamwezi                                      | nym            |                |                
Nyaneka                                       | nyk            |                |                
Nyang'i                                       | nyp            |                |                
Nyanga                                        | nyj            |                |                
Nyanga-li                                     | nyc            |                |                
Nyangatom                                     | nnj            |                |                
Nyangbo                                       | nyb            |                |                
Nyangga                                       | nny            |                |                
Nyangumarta                                   | nna            |                |                
Nyanja                                        | nya            | ny             |                
Nyankole                                      | nyn            |                |                
Nyankpa                                       | yes            |                |                
Nyarafolo Senoufo                             | sev            |                |                
Nyaturu                                       | rim            |                |                
Nyaw                                          | nyw            |                |                
Nyawaygi                                      | nyt            |                |                
Nyemba                                        | nba            |                |                
Nyengo                                        | nye            |                |                
Nyenkha                                       | neh            |                |                
Nyeu                                          | nyl            |                |                
Nyiha (Malawi)                                | nyr            |                |                
Nyiha (Tanzania)                              | nih            |                |                
Nyika (Malawi and Zambia)                     | nkv            |                |                
Nyika (Tanzania)                              | nkt            |                |                
Nyikina                                       | nyh            |                |                
Nyindrou                                      | lid            |                |                
Nyindu                                        | nyg            |                |                
Nyishi                                        | njz            |                |                
Nyiyaparli                                    | xny            |                |                
Nyokon                                        | nvo            |                |                
Nyole                                         | nuj            |                |                
Nyong                                         | muo            |                |                
Nyore                                         | nyd            |                |                
Nyoro                                         | nyo            |                |                
Nyulnyul                                      | nyv            |                |                
Nyungar                                       | nys            |                |                
Nyungwe                                       | nyu            |                |                
Nyâlayu                                       | yly            |                |                
Nzadi                                         | nzd            |                |                
Nzakambay                                     | nzy            |                |                
Nzakara                                       | nzk            |                |                
Nzanyi                                        | nja            |                |                
Nzima                                         | nzi            |                |                
Ná-Meo                                        | neo            |                |                
Nêlêmwa-Nixumwak                              | nee            |                |                
Nüpode Huitoto                                | hux            |                |                
Nǁng                                          | ngh            |                |                
O'chi'chi'                                    | xoc            |                |                
O'du                                          | tyh            |                |                
Obanliku                                      | bzy            |                |                
Obispeño                                      | obi            |                |                
Oblo                                          | obl            |                |                
Obo Manobo                                    | obo            |                |                
Obokuitai                                     | afz            |                |                
Obolo                                         | ann            |                |                
Obulom                                        | obu            |                |                
Ocaina                                        | oca            |                |                
Occitan (post 1500)                           | oci            | oc             |                
Ocotepec Mixtec                               | mie            |                |                
Ocotlán Zapotec                               | zac            |                |                
Od                                            | odk            |                |                
Odia                                          | ory            |                |                
Odiai                                         | bhf            |                |                
Odoodee                                       | kkc            |                |                
Odual                                         | odu            |                |                
Odut                                          | oda            |                |                
Ofayé                                         | opy            |                |                
Official Aramaic (700-300 BCE)                | arc            |                |                
Ofo                                           | ofo            |                |                
Ogbah                                         | ogc            |                |                
Ogbia                                         | ogb            |                |                
Ogbogolo                                      | ogg            |                |                
Ogbronuagum                                   | ogu            |                |                
Ogea                                          | eri            |                |                
Oirata                                        | oia            |                |                
Ojibwa                                        | oji            | oj             |                
Ojitlán Chinantec                             | chj            |                |                
Okanagan                                      | oka            |                |                
Oki-No-Erabu                                  | okn            |                |                
Okiek                                         | oki            |                |                
Oko-Eni-Osayen                                | oks            |                |                
Oko-Juwoi                                     | okj            |                |                
Okobo                                         | okb            |                |                
Okodia                                        | okd            |                |                
Okolie                                        | oie            |                |                
Okolod                                        | kqv            |                |                
Okpamheri                                     | opa            |                |                
Okpe (Northwestern Edo)                       | okx            |                |                
Okpe (Southwestern Edo)                       | oke            |                |                
Oksapmin                                      | opm            |                |                
Oku                                           | oku            |                |                
Old Aramaic (up to 700 BCE)                   | oar            |                |                
Old Avar                                      | oav            |                |                
Old Breton                                    | obt            |                |                
Old Burmese                                   | obr            |                |                
Old Cham                                      | ocm            |                |                
Old Chinese                                   | och            |                |                
Old Cornish                                   | oco            |                |                
Old Dutch                                     | odt            |                |                
Old English (ca. 450-1100)                    | ang            |                |                
Old French (842-ca. 1400)                     | fro            |                |                
Old Frisian                                   | ofs            |                |                
Old Georgian                                  | oge            |                |                
Old High German (ca. 750-1050)                | goh            |                |                
Old Hittite                                   | oht            |                |                
Old Hungarian                                 | ohu            |                |                
Old Irish (to 900)                            | sga            |                |                
Old Japanese                                  | ojp            |                |                
Old Kentish Sign Language                     | okl            |                |                
Old Khmer                                     | okz            |                |                
Old Korean (3rd-9th cent.)                    | oko            |                |                
Old Lithuanian                                | olt            |                |                
Old Malay                                     | omy            |                |                
Old Manipuri                                  | omp            |                |                
Old Marathi                                   | omr            |                |                
Old Mon                                       | omx            |                |                
Old Norse                                     | non            |                |                
Old Nubian                                    | onw            |                |                
Old Ossetic                                   | oos            |                |                
Old Persian (ca. 600-400 B.C.)                | peo            |                |                
Old Provençal (to 1500)                       | pro            |                |                
Old Russian                                   | orv            |                |                
Old Saxon                                     | osx            |                |                
Old Spanish                                   | osp            |                |                
Old Sundanese                                 | osn            |                |                
Old Tamil                                     | oty            |                |                
Old Tibetan                                   | otb            |                |                
Old Turkish                                   | otk            |                |                
Old Uighur                                    | oui            |                |                
Old Welsh                                     | owl            |                |                
Olekha                                        | ole            |                |                
Olkol                                         | olk            |                |                
Olo                                           | ong            |                |                
Oloma                                         | olm            |                |                
Olrat                                         | olr            |                |                
Olu'bo                                        | lul            |                |                
Olulumo-Ikom                                  | iko            |                |                
Oluta Popoluca                                | plo            |                |                
Omagua                                        | omg            |                |                
Omaha-Ponca                                   | oma            |                |                
Omani Arabic                                  | acx            |                |                
Omati                                         | mgx            |                |                
Ombamba                                       | mbm            |                |                
Ombo                                          | oml            |                |                
Omejes                                        | ome            |                |                
Ometepec Nahuatl                              | nht            |                |                
Omi                                           | omi            |                |                
Omok                                          | omk            |                |                
Omotic languages                              | omv            |                |                
Omotik                                        | omt            |                |                
Omurano                                       | omu            |                |                
Ona                                           | ona            |                |                
Oneida                                        | one            |                |                
Ong                                           | oog            |                |                
Onin Based Pidgin                             | onx            |                |                
Onin                                          | oni            |                |                
Onjob                                         | onj            |                |                
Ono                                           | ons            |                |                
Onobasulu                                     | onn            |                |                
Onondaga                                      | ono            |                |                
Ontenu                                        | ont            |                |                
Ontong Java                                   | ojv            |                |                
Oorlams                                       | oor            |                |                
Opao                                          | opo            |                |                
Opata                                         | opt            |                |                
Orang Kanaq                                   | orn            |                |                
Orang Seletar                                 | ors            |                |                
Oraon Sadri                                   | sdr            |                |                
Orejón                                        | ore            |                |                
Oring                                         | org            |                |                
Oriya (macrolanguage)                         | ori            | or             |                
Orizaba Nahuatl                               | nlv            |                |                
Orma                                          | orc            |                |                
Ormu                                          | orz            |                |                
Ormuri                                        | oru            |                |                
Oro Win                                       | orw            |                |                
Oro                                           | orx            |                |                
Oroch                                         | oac            |                |                
Oroha                                         | ora            |                |                
Orok                                          | oaa            |                |                
Orokaiva                                      | okv            |                |                
Oroko                                         | bdu            |                |                
Orokolo                                       | oro            |                |                
Oromo                                         | orm            | om             |                
Oroqen                                        | orh            |                |                
Orowe                                         | bpk            |                |                
Oruma                                         | orr            |                |                
Orya                                          | ury            |                |                
Osage                                         | osa            |                |                
Osatu                                         | ost            |                |                
Oscan                                         | osc            |                |                
Osing                                         | osi            |                |                
Ososo                                         | oso            |                |                
Ossetian                                      | oss            | os             |                
Ot Danum                                      | otd            |                |                
Otank                                         | uta            |                |                
Oti                                           | oti            |                |                
Oto-Manguean languages                        | omq            |                |                
Otomian languages                             | oto            |                |                
Otoro                                         | otr            |                |                
Ottawa                                        | otw            |                |                
Ottoman Turkish (1500-1928)                   | ota            |                |                
Otuho                                         | lot            |                |                
Otuke                                         | otu            |                |                
Ouma                                          | oum            |                |                
Oune                                          | oue            |                |                
Owa                                           | stn            |                |                
Owenia                                        | wsr            |                |                
Owiniga                                       | owi            |                |                
Oy                                            | oyb            |                |                
Oya'oya                                       | oyy            |                |                
Oyda                                          | oyd            |                |                
Oyster Bay Tasmanian                          | xpd            |                |                
Ozolotepec Zapotec                            | zao            |                |                
Ozumacín Chinantec                            | chz            |                |                
Pa Di                                         | pdi            |                |                
Pa'a                                          | pqa            |                |                
Pa'o Karen                                    | blk            |                |                
Pa-Hng                                        | pha            |                |                
Paakantyi                                     | drl            |                |                
Paama                                         | pma            |                |                
Paasaal                                       | sig            |                |                
Pacahuara                                     | pcp            |                |                
Pacaraos Quechua                              | qvp            |                |                
Pacific Gulf Yupik                            | ems            |                |                
Pacoh                                         | pac            |                |                
Padoe                                         | pdo            |                |                
Paekche                                       | pkc            |                |                
Paelignian                                    | pgn            |                |                
Pagi                                          | pgi            |                |                
Pagibete                                      | pae            |                |                
Pagu                                          | pgu            |                |                
Pahanan Agta                                  | apf            |                |                
Pahari                                        | phj            |                |                
Pahari-Potwari                                | phr            |                |                
Pahi                                          | lgt            |                |                
Pahlavani                                     | phv            |                |                
Pahlavi                                       | pal            |                |                
Pai Tavytera                                  | pta            |                |                
Paicî                                         | pri            |                |                
Paipai                                        | ppi            |                |                
Paite Chin                                    | pck            |                |                
Paiwan                                        | pwn            |                |                
Pak-Tong                                      | pkg            |                |                
Pakanha                                       | pkn            |                |                
Pakaásnovos                                   | pav            |                |                
Pakistan Sign Language                        | pks            |                |                
Paku Karen                                    | jkp            |                |                
Paku Karen                                    | kpp            |                |                
Paku                                          | pku            |                |                
Pal                                           | abw            |                |                
Palaic                                        | plq            |                |                
Palaka Senoufo                                | plr            |                |                
Palantla Chinantec                            | cpa            |                |                
Palauan                                       | pau            |                |                
Paleni                                        | pnl            |                |                
Palenquero                                    | pln            |                |                
Pali                                          | pli            | pi             |                
Palikúr                                       | plu            |                |                
Paliyan                                       | pcf            |                |                
Pallanganmiddang                              | pmd            |                |                
Paloor                                        | fap            |                |                
Palpa                                         | plp            |                |                
Palu                                          | pbz            |                |                
Palu'e                                        | ple            |                |                
Paluan                                        | plz            |                |                
Palumata                                      | pmc            |                |                
Palya Bareli                                  | bpx            |                |                
Pam                                           | pmn            |                |                
Pambia                                        | pmb            |                |                
Pamlico                                       | pmk            |                |                
Pamona                                        | pmf            |                |                
Pamosu                                        | hih            |                |                
Pampanga                                      | pam            |                |                
Pamplona Atta                                 | att            |                |                
Pana (Burkina Faso)                           | pnq            |                |                
Pana (Central African Republic)               | pnz            |                |                
Panamanian Sign Language                      | lsp            |                |                
Panamint                                      | par            |                |                
Panang                                        | pcr            |                |                
Panao Huánuco Quechua                         | qxh            |                |                
Panará                                        | kre            |                |                
Panasuan                                      | psn            |                |                
Panawa                                        | pwb            |                |                
Pancana                                       | pnp            |                |                
Panchpargania                                 | tdb            |                |                
Pande                                         | bkj            |                |                
Pangasinan                                    | pag            |                |                
Pangseng                                      | pgs            |                |                
Pangu                                         | png            |                |                
Pangutaran Sama                               | slm            |                |                
Pangwa                                        | pbr            |                |                
Pangwali                                      | pgg            |                |                
Panim                                         | pnr            |                |                
Paniya                                        | pcg            |                |                
Panjabi                                       | pan            | pa             |                
Pankararé                                     | pax            |                |                
Pankararú                                     | paz            |                |                
Pankhu                                        | pkh            |                |                
Pannei                                        | pnc            |                |                
Pano                                          | mqz            |                |                
Panoan Katukína                               | knt            |                |                
Panobo                                        | pno            |                |                
Panyi Bai                                     | bfc            |                |                
Pao                                           | ppa            |                |                
Papantla Totonac                              | top            |                |                
Papapana                                      | ppn            |                |                
Papar                                         | dpp            |                |                
Papasena                                      | pas            |                |                
Papel                                         | pbo            |                |                
Papi                                          | ppe            |                |                
Papiamento                                    | pap            |                |                
Papitalai                                     | pat            |                |                
Papora                                        | ppu            |                |                
Papua New Guinean Sign Language               | pgz            |                |                
Papuan Malay                                  | pmy            |                |                
Papuan languages                              | paa            |                |                
Papuma                                        | ppm            |                |                
Parachi                                       | prc            |                |                
Paraguayan Guaraní                            | gug            |                |                
Paraguayan Sign Language                      | pys            |                |                
Parakanã                                      | pak            |                |                
Paranan                                       | agp            |                |                
Paranan                                       | prf            |                |                
Paranawát                                     | paf            |                |                
Paraujano                                     | pbg            |                |                
Parauk                                        | prk            |                |                
Parawen                                       | prw            |                |                
Pardhan                                       | pch            |                |                
Pardhi                                        | pcl            |                |                
Pare                                          | ppt            |                |                
Parecís                                       | pab            |                |                
Parenga                                       | pcj            |                |                
Parkari Koli                                  | kvx            |                |                
Parkwa                                        | pbi            |                |                
Parsi                                         | prp            |                |                
Parsi-Dari                                    | prd            |                |                
Parthian                                      | xpr            |                |                
Parya                                         | paq            |                |                
Pará Arára                                    | aap            |                |                
Pará Gavião                                   | gvp            |                |                
Pasi                                          | psq            |                |                
Pass Valley Yali                              | yac            |                |                
Patamona                                      | pbc            |                |                
Patani                                        | ptn            |                |                
Pataxó Hã-Ha-Hãe                              | pth            |                |                
Patep                                         | ptp            |                |                
Pathiya                                       | pty            |                |                
Patpatar                                      | gfk            |                |                
Pattani Malay                                 | mfa            |                |                
Pattani                                       | lae            |                |                
Pattapu                                       | ptq            |                |                
Patwin                                        | pwi            |                |                
Paulohi                                       | plh            |                |                
Paumarí                                       | pad            |                |                
Paunaka                                       | pnk            |                |                
Pauri Bareli                                  | bfb            |                |                
Pauserna                                      | psm            |                |                
Pawaia                                        | pwa            |                |                
Pawnee                                        | paw            |                |                
Paynamar                                      | pmr            |                |                
Pazeh                                         | pzh            |                |                
Pe                                            | pai            |                |                
Pear                                          | pcb            |                |                
Pech                                          | pay            |                |                
Pecheneg                                      | xpc            |                |                
Pedi                                          | nso            |                |                
Pei                                           | ppq            |                |                
Pekal                                         | pel            |                |                
Pela                                          | bxd            |                |                
Pele-Ata                                      | ata            |                |                
Pelende                                       | ppp            |                |                
Pemon                                         | aoc            |                |                
Penang Sign Language                          | psg            |                |                
Penchal                                       | pek            |                |                
Pendau                                        | ums            |                |                
Pengo                                         | peg            |                |                
Pennsylvania German                           | pdc            |                |                
Penrhyn                                       | pnh            |                |                
Pentlatch                                     | ptw            |                |                
Perai                                         | wet            |                |                
Peranakan Indonesian                          | pea            |                |                
Pere                                          | pfe            |                |                
Peripheral Mongolian                          | mvf            |                |                
Pero                                          | pip            |                |                
Persian                                       | per            | fa             | fas            
Peruvian Sign Language                        | prl            |                |                
Petapa Zapotec                                | zpe            |                |                
Petats                                        | pex            |                |                
Petjo                                         | pey            |                |                
Peñoles Mixtec                                | mil            |                |                
Pfaelzisch                                    | pfl            |                |                
Phai                                          | prt            |                |                
Phake                                         | phk            |                |                
Phala                                         | ypa            |                |                
Phalura                                       | phl            |                |                
Phana'                                        | phq            |                |                
Phangduwali                                   | phw            |                |                
Phende                                        | pem            |                |                
Philippine Sign Language                      | psp            |                |                
Philippine languages                          | phi            |                |                
Phimbi                                        | phm            |                |                
Phoenician                                    | phn            |                |                
Phola                                         | ypg            |                |                
Pholo                                         | yip            |                |                
Phom Naga                                     | nph            |                |                
Phong-Kniang                                  | pnx            |                |                
Phrae Pwo Karen                               | kjt            |                |                
Phrygian                                      | xpg            |                |                
Phu Thai                                      | pht            |                |                
Phuan                                         | phu            |                |                
Phudagi                                       | phd            |                |                
Phuie                                         | pug            |                |                
Phukha                                        | phh            |                |                
Phuma                                         | ypm            |                |                
Phunoi                                        | pho            |                |                
Phuong                                        | phg            |                |                
Phupa                                         | ypp            |                |                
Phupha                                        | yph            |                |                
Phuza                                         | ypz            |                |                
Piamatsina                                    | ptr            |                |                
Piame                                         | pin            |                |                
Piapoco                                       | pio            |                |                
Piaroa                                        | pid            |                |                
Picard                                        | pcd            |                |                
Pichis Ashéninka                              | cpu            |                |                
Pictish                                       | xpi            |                |                
Pidgin Delaware                               | dep            |                |                
Piemontese                                    | pms            |                |                
Pijao                                         | pij            |                |                
Pije                                          | piz            |                |                
Pijin                                         | pis            |                |                
Pilagá                                        | plg            |                |                
Pileni                                        | piv            |                |                
Pima Bajo                                     | pia            |                |                
Pimbwe                                        | piw            |                |                
Pinai-Hagahai                                 | pnn            |                |                
Pindiini                                      | pti            |                |                
Pingelapese                                   | pif            |                |                
Pini                                          | pii            |                |                
Pinigura                                      | pnv            |                |                
Pinjarup                                      | pnj            |                |                
Pinji                                         | pic            |                |                
Pinotepa Nacional Mixtec                      | mio            |                |                
Pintupi-Luritja                               | piu            |                |                
Pinyin                                        | pny            |                |                
Pipil                                         | ppl            |                |                
Pirahã                                        | myp            |                |                
Piratapuyo                                    | pir            |                |                
Pirlatapa                                     | bxi            |                |                
Piro                                          | pie            |                |                
Pirriya                                       | xpa            |                |                
Piru                                          | ppr            |                |                
Pisabo                                        | pig            |                |                
Pisaflores Tepehua                            | tpp            |                |                
Piscataway                                    | psy            |                |                
Pisidian                                      | xps            |                |                
Pitcairn-Norfolk                              | pih            |                |                
Pite Sami                                     | sje            |                |                
Piti                                          | pcn            |                |                
Pitjantjatjara                                | pjt            |                |                
Pitta Pitta                                   | pit            |                |                
Piu                                           | pix            |                |                
Piya-Kwonci                                   | piy            |                |                
Plains Cree                                   | crk            |                |                
Plains Indian Sign Language                   | psd            |                |                
Plains Miwok                                  | pmw            |                |                
Plapo Krumen                                  | ktj            |                |                
Plateau Malagasy                              | plt            |                |                
Plautdietsch                                  | pdt            |                |                
Playero                                       | gob            |                |                
Pnar                                          | pbv            |                |                
Pochuri Naga                                  | npo            |                |                
Pochutec                                      | xpo            |                |                
Podena                                        | pdn            |                |                
Pogolo                                        | poy            |                |                
Pohnpeian                                     | pon            |                |                
Pokangá                                       | pok            |                |                
Poke                                          | pof            |                |                
Pokomo                                        | pkb            |                |                
Polabian                                      | pox            |                |                
Polari                                        | pld            |                |                
Polci                                         | plj            |                |                
Polish Sign Language                          | pso            |                |                
Polish                                        | pol            | pl             |                
Polonombauk                                   | plb            |                |                
Pom                                           | pmo            |                |                
Pomo                                          | pmm            |                |                
Ponam                                         | ncc            |                |                
Ponares                                       | pod            |                |                
Pongyong                                      | pgy            |                |                
Ponosakan                                     | pns            |                |                
Pontic                                        | pnt            |                |                
Ponyo-Gongwang Naga                           | npg            |                |                
Popti'                                        | jac            |                |                
Poqomam                                       | poc            |                |                
Poqomchi'                                     | poh            |                |                
Porohanon                                     | prh            |                |                
Port Sandwich                                 | psw            |                |                
Port Sorell Tasmanian                         | xpl            |                |                
Port Vato                                     | ptv            |                |                
Portuguese Sign Language                      | psr            |                |                
Portuguese                                    | por            | pt             |                
Potawatomi                                    | pot            |                |                
Potiguára                                     | pog            |                |                
Pottangi Ollar Gadaba                         | gdb            |                |                
Poumei Naga                                   | pmx            |                |                
Pouye                                         | bye            |                |                
Powari                                        | pwr            |                |                
Powhatan                                      | pim            |                |                
Poyanáwa                                      | pyn            |                |                
Prakrit languages                             | pra            |                |                
Prasuni                                       | prn            |                |                
Pray 3                                        | pry            |                |                
Primitive Irish                               | pgl            |                |                
Principense                                   | pre            |                |                
Providencia Sign Language                     | prz            |                |                
Prussian                                      | prg            |                |                
Psikye                                        | kvj            |                |                
Pu Ko                                         | puk            |                |                
Pu-Xian Chinese                               | cpx            |                |                
Puare                                         | pux            |                |                
Pudtol Atta                                   | atp            |                |                
Puebla Mazatec                                | pbm            |                |                
Puelche                                       | pue            |                |                
Puerto Rican Sign Language                    | psl            |                |                
Puimei Naga                                   | npu            |                |                
Puinave                                       | pui            |                |                
Pukapuka                                      | pkp            |                |                
Pulaar                                        | fuc            |                |                
Pulabu                                        | pup            |                |                
Pular                                         | fuf            |                |                
Puluwatese                                    | puw            |                |                
Puma                                          | pum            |                |                
Pumpokol                                      | xpm            |                |                
Pumé                                          | yae            |                |                
Punan Aput                                    | pud            |                |                
Punan Bah-Biau                                | pna            |                |                
Punan Batu 1                                  | pnm            |                |                
Punan Merah                                   | puf            |                |                
Punan Merap                                   | puc            |                |                
Punan Tubu                                    | puj            |                |                
Punic                                         | xpu            |                |                
Puno Quechua                                  | qxp            |                |                
Punthamara                                    | xpt            |                |                
Punu                                          | puu            |                |                
Puoc                                          | puo            |                |                
Puquina                                       | puq            |                |                
Puragi                                        | pru            |                |                
Purari                                        | iar            |                |                
Purepecha                                     | tsz            |                |                
Puri                                          | prr            |                |                
Purik                                         | prx            |                |                
Purisimeño                                    | puy            |                |                
Puroik                                        | suv            |                |                
Puruborá                                      | pur            |                |                
Purum Naga                                    | puz            |                |                
Purum                                         | pub            |                |                
Pushto                                        | pus            | ps             |                
Putai                                         | mfl            |                |                
Putoh                                         | put            |                |                
Putukwam                                      | afe            |                |                
Puyo                                          | xpy            |                |                
Puyo-Paekche                                  | xpp            |                |                
Puyuma                                        | pyu            |                |                
Pwaamei                                       | pme            |                |                
Pwapwâ                                        | pop            |                |                
Pwo Eastern Karen                             | kjp            |                |                
Pwo Northern Karen                            | pww            |                |                
Pwo Western Karen                             | pwo            |                |                
Pyapun                                        | pcw            |                |                
Pye Krumen                                    | pye            |                |                
Pyen                                          | pyy            |                |                
Pyu (Myanmar)                                 | pyx            |                |                
Pyu (Papua New Guinea)                        | pby            |                |                
Páez                                          | pbb            |                |                
Pááfang                                       | pfa            |                |                
Päri                                          | lkr            |                |                
Pémono                                        | pev            |                |                
Pévé                                          | lme            |                |                
Pökoot                                        | pko            |                |                
Q'anjob'al                                    | kjb            |                |                
Qabiao                                        | laq            |                |                
Qaqet                                         | byx            |                |                
Qashqa'i                                      | qxq            |                |                
Qatabanian                                    | xqt            |                |                
Qau                                           | gqu            |                |                
Qawasqar                                      | alc            |                |                
Qila Muji                                     | ymq            |                |                
Qimant                                        | ahg            |                |                
Qiubei Zhuang                                 | zqe            |                |                
Quapaw                                        | qua            |                |                
Quebec Sign Language                          | fcs            |                |                
Quechan                                       | yum            |                |                
Quechua                                       | que            | qu             |                
Quechuan (family)                             | qwe            |                |                
Quenya                                        | qya            |                |                
Querétaro Otomi                               | otq            |                |                
Quetzaltepec Mixe                             | pxm            |                |                
Queyu                                         | qvy            |                |                
Quiavicuzas Zapotec                           | zpj            |                |                
Quileute                                      | qui            |                |                
Quinault                                      | qun            |                |                
Quinqui                                       | quq            |                |                
Quioquitani-Quierí Zapotec                    | ztq            |                |                
Quiotepec Chinantec                           | chq            |                |                
Quiripi                                       | qyp            |                |                
Rabha                                         | rah            |                |                
Rade                                          | rad            |                |                
Raetic                                        | xrr            |                |                
Rahambuu                                      | raz            |                |                
Rajah Kabunsuwan Manobo                       | mqk            |                |                
Rajasthani                                    | raj            |                |                
Rajbanshi                                     | rjs            |                |                
Raji                                          | rji            |                |                
Rajong                                        | rjg            |                |                
Rajput Garasia                                | gra            |                |                
Rakahanga-Manihiki                            | rkh            |                |                
Rakhine                                       | rki            |                |                
Ralte                                         | ral            |                |                
Rama                                          | rma            |                |                
Ramoaaina                                     | rai            |                |                
Ramopa                                        | kjx            |                |                
Rampi                                         | lje            |                |                
Rana Tharu                                    | thr            |                |                
Rang                                          | rax            |                |                
Rangkas                                       | rgk            |                |                
Ranglong                                      | rnl            |                |                
Rangpuri                                      | rkt            |                |                
Rao                                           | rao            |                |                
Rapa                                          | ray            |                |                
Rapanui                                       | rap            |                |                
Rapoisi                                       | kyx            |                |                
Rapting                                       | rpt            |                |                
Rara Bakati'                                  | lra            |                |                
Rarotongan                                    | rar            |                |                
Rasawa                                        | rac            |                |                
Ratagnon                                      | btn            |                |                
Ratahan                                       | rth            |                |                
Rathawi                                       | rtw            |                |                
Rathwi Bareli                                 | bgd            |                |                
Raute                                         | rau            |                |                
Ravula                                        | yea            |                |                
Rawa                                          | rwo            |                |                
Rawang                                        | raw            |                |                
Rawat                                         | jnl            |                |                
Rawngtu Chin                                  | weu            |                |                
Rawo                                          | rwa            |                |                
Rayón Zoque                                   | zor            |                |                
Razajerdi                                     | rat            |                |                
Red Gelao                                     | gir            |                |                
Reel                                          | atu            |                |                
Rejang Kayan                                  | ree            |                |                
Rejang                                        | rej            |                |                
Reli                                          | rei            |                |                
Rema                                          | bow            |                |                
Rembarrnga                                    | rmb            |                |                
Rembong                                       | reb            |                |                
Remo                                          | rem            |                |                
Remontado Dumagat                             | agv            |                |                
Rempi                                         | rmp            |                |                
Remun                                         | lkj            |                |                
Rendille                                      | rel            |                |                
Rengao                                        | ren            |                |                
Rennell-Bellona                               | mnv            |                |                
Rennellese Sign Language                      | rsi            |                |                
Repanbitip                                    | rpn            |                |                
Rer Bare                                      | rer            |                |                
Rerau                                         | rea            |                |                
Rerep                                         | pgk            |                |                
Reshe                                         | res            |                |                
Resígaro                                      | rgr            |                |                
Retta                                         | ret            |                |                
Reyesano                                      | rey            |                |                
Riang (India)                                 | ria            |                |                
Riang Lai                                     | yin            |                |                
Riang Lang                                    | ril            |                |                
Riantana                                      | ran            |                |                
Ribun                                         | rir            |                |                
Rien                                          | rie            |                |                
Rigwe                                         | iri            |                |                
Rikbaktsa                                     | rkb            |                |                
Rinconada Bikol                               | bto            |                |                
Rincón Zapotec                                | zar            |                |                
Ringgou                                       | rgu            |                |                
Ririo                                         | rri            |                |                
Ritharrngu                                    | rit            |                |                
Riung                                         | riu            |                |                
Riverain Sango                                | snj            |                |                
Rmeet                                         | lbn            |                |                
Rogo                                          | rod            |                |                
Rohingya                                      | rhg            |                |                
Roma                                          | rmm            |                |                
Romagnol                                      | rgn            |                |                
Romam                                         | rmx            |                |                
Romance languages                             | roa            |                |                
Romanian Sign Language                        | rms            |                |                
Romanian                                      | rum            | ro             | ron            
Romano-Greek                                  | rge            |                |                
Romano-Serbian                                | rsb            |                |                
Romanova                                      | rmv            |                |                
Romansh                                       | roh            | rm             |                
Romany                                        | rom            |                |                
Romblomanon                                   | rol            |                |                
Rombo                                         | rof            |                |                
Romkun                                        | rmk            |                |                
Ron                                           | cla            |                |                
Ronga                                         | rng            |                |                
Rongga                                        | ror            |                |                
Rongmei Naga                                  | nbu            |                |                
Rongpo                                        | rnp            |                |                
Ronji                                         | roe            |                |                
Roon                                          | rnn            |                |                
Roria                                         | rga            |                |                
Rotokas                                       | roo            |                |                
Rotuman                                       | rtm            |                |                
Roviana                                       | rug            |                |                
Ruching Palaung                               | pce            |                |                
Rudbari                                       | rdb            |                |                
Rufiji                                        | rui            |                |                
Ruga                                          | ruh            |                |                
Rukai                                         | dru            |                |                
Ruma                                          | ruz            |                |                
Rumai Palaung                                 | rbb            |                |                
Rumu                                          | klq            |                |                
Runa                                          | rna            |                |                
Rundi                                         | run            | rn             |                
Runga                                         | rou            |                |                
Rungtu Chin                                   | rtc            |                |                
Rungus                                        | drg            |                |                
Rungwa                                        | rnw            |                |                
Russia Buriat                                 | bxr            |                |                
Russian Sign Language                         | rsl            |                |                
Russian                                       | rus            | ru             |                
Rusyn                                         | rue            |                |                
Ruthenian                                     | rsk            |                |                
Rutul                                         | rut            |                |                
Ruuli                                         | ruc            |                |                
Ruund                                         | rnd            |                |                
Ruwila                                        | rwl            |                |                
Rwa                                           | rwk            |                |                
Rwandan Sign Language                         | rsn            |                |                
Réunion Creole French                         | rcf            |                |                
Rāziḥī                                        | rzh            |                |                
S'gaw Karen                                   | ksw            |                |                
Sa                                            | sax            |                |                
Sa'a                                          | apb            |                |                
Sa'ban                                        | snv            |                |                
Sa'och                                        | scq            |                |                
Saafi-Saafi                                   | sav            |                |                
Saam                                          | raq            |                |                
Saamia                                        | lsm            |                |                
Saaroa                                        | sxr            |                |                
Saba                                          | saa            |                |                
Sabaean                                       | xsa            |                |                
Sabah Bisaya                                  | bsy            |                |                
Sabah Malay                                   | msi            |                |                
Sabanê                                        | sae            |                |                
Sabaot                                        | spy            |                |                
Sabine                                        | sbv            |                |                
Sabu                                          | hvn            |                |                
Sabüm                                         | sbo            |                |                
Sacapulteco                                   | quv            |                |                
Sadri                                         | sck            |                |                
Saek                                          | skb            |                |                
Saep                                          | spd            |                |                
Safaliba                                      | saf            |                |                
Safeyoka                                      | apz            |                |                
Safwa                                         | sbk            |                |                
Sagala                                        | sbm            |                |                
Sagalla                                       | tga            |                |                
Saho                                          | ssy            |                |                
Sahu                                          | saj            |                |                
Saidi Arabic                                  | aec            |                |                
Saint Lucian Creole French                    | acf            |                |                
Saisiyat                                      | xsy            |                |                
Sajalong                                      | sjl            |                |                
Sajau Basap                                   | sjb            |                |                
Sakachep                                      | sch            |                |                
Sakalava Malagasy                             | skg            |                |                
Sakao                                         | sku            |                |                
Sakata                                        | skt            |                |                
Sake                                          | sak            |                |                
Sakirabiá                                     | skf            |                |                
Sakizaya                                      | szy            |                |                
Sala                                          | shq            |                |                
Salampasu                                     | slx            |                |                
Salar                                         | slr            |                |                
Salas                                         | sgu            |                |                
Salasaca Highland Quichua                     | qxl            |                |                
Salawati                                      | xmx            |                |                
Salchuq                                       | slq            |                |                
Saleman                                       | sau            |                |                
Saliba                                        | sbe            |                |                
Salinan                                       | sln            |                |                
Salishan languages                            | sal            |                |                
Sallands                                      | sdz            |                |                
Salt-Yui                                      | sll            |                |                
Saluan                                        | loe            |                |                
Salumá                                        | slj            |                |                
Salvadoran Sign Language                      | esn            |                |                
Sam                                           | snx            |                |                
Sama                                          | smd            |                |                
Samaritan Aramaic                             | sam            |                |                
Samaritan                                     | smp            |                |                
Samarokena                                    | tmj            |                |                
Samatao                                       | ysd            |                |                
Samay                                         | syx            |                |                
Samba Daka                                    | ccg            |                |                
Samba Leko                                    | ndi            |                |                
Samba                                         | smx            |                |                
Sambal                                        | xsb            |                |                
Sambalpuri                                    | spv            |                |                
Sambe                                         | xab            |                |                
Samberigi                                     | ssx            |                |                
Samburu                                       | saq            |                |                
Samei                                         | smh            |                |                
Sami languages                                | smi            |                |                
Samo                                          | smq            |                |                
Samoan                                        | smo            | sm             |                
Samogitian                                    | sgs            |                |                
Samosa                                        | swm            |                |                
Samoyedic languages                           | syd            |                |                
Sampang                                       | rav            |                |                
Samre                                         | sxm            |                |                
Samtao                                        | stu            |                |                
Samvedi                                       | smv            |                |                
San Agustín Mixtepec Zapotec                  | ztm            |                |                
San Baltazar Loxicha Zapotec                  | zpx            |                |                
San Blas Kuna                                 | cuk            |                |                
San Dionisio Del Mar Huave                    | hve            |                |                
San Felipe Otlaltepec Popoloca                | pow            |                |                
San Francisco Del Mar Huave                   | hue            |                |                
San Francisco Matlatzinca                     | mat            |                |                
San Jerónimo Tecóatl Mazatec                  | maa            |                |                
San Juan Atzingo Popoloca                     | poe            |                |                
San Juan Colorado Mixtec                      | mjc            |                |                
San Juan Teita Mixtec                         | xtj            |                |                
San Luís Temalacayuca Popoloca                | pps            |                |                
San Marcos Tlacoyalco Popoloca                | pls            |                |                
San Martín Itunyoso Triqui                    | trq            |                |                
San Martín Quechua                            | qvs            |                |                
San Mateo Del Mar Huave                       | huv            |                |                
San Miguel Creole French                      | scf            |                |                
San Miguel El Grande Mixtec                   | mig            |                |                
San Miguel Piedras Mixtec                     | xtp            |                |                
San Pedro Amuzgos Amuzgo                      | azg            |                |                
San Pedro Quiatoni Zapotec                    | zpf            |                |                
San Salvador Kongo                            | kwy            |                |                
San Vicente Coatlán Zapotec                   | zpt            |                |                
Sanaani Arabic                                | ayn            |                |                
Sanapaná                                      | sap            |                |                
Sanapaná                                      | spn            |                |                
Sandawe                                       | sad            |                |                
Sanga (Democratic Republic of Congo)          | sng            |                |                
Sanga (Nigeria)                               | xsn            |                |                
Sangab Mandaya                                | myt            |                |                
Sanggau                                       | scg            |                |                
Sangil                                        | snl            |                |                
Sangir                                        | sxn            |                |                
Sangisari                                     | sgr            |                |                
Sangkong                                      | sgk            |                |                
Sanglechi                                     | sgy            |                |                
Sanglechi-Ishkashimi                          | sgl            |                |                
Sango                                         | sag            | sg             |                
Sangtam Naga                                  | nsa            |                |                
Sangu (Gabon)                                 | snq            |                |                
Sangu (Tanzania)                              | sbp            |                |                
Sani                                          | ysn            |                |                
Sanie                                         | ysy            |                |                
Saniyo-Hiyewe                                 | sny            |                |                
Sankaran Maninka                              | msc            |                |                
Sansi                                         | ssi            |                |                
Sanskrit                                      | san            | sa             |                
Sansu                                         | sca            |                |                
Santa Ana de Tusi Pasco Quechua               | qxt            |                |                
Santa Catarina Albarradas Zapotec             | ztn            |                |                
Santa Inés Ahuatempan Popoloca                | pca            |                |                
Santa Inés Yatzechi Zapotec                   | zpn            |                |                
Santa Lucía Monteverde Mixtec                 | mdv            |                |                
Santa María Del Mar Huave                     | hvv            |                |                
Santa María La Alta Nahuatl                   | nhz            |                |                
Santa María Quiegolani Zapotec                | zpi            |                |                
Santa María Zacatepec Mixtec                  | mza            |                |                
Santa Teresa Cora                             | cok            |                |                
Santali                                       | sat            |                |                
Santiago Xanica Zapotec                       | zpr            |                |                
Santiago del Estero Quichua                   | qus            |                |                
Santo Domingo Albarradas Zapotec              | zas            |                |                
Sanumá                                        | xsu            |                |                
Saparua                                       | spr            |                |                
Sapo                                          | krn            |                |                
Saponi                                        | spi            |                |                
Saposa                                        | sps            |                |                
Sapuan                                        | spu            |                |                
Sapé                                          | spc            |                |                
Sar                                           | mwm            |                |                
Sara Dunjo                                    | koj            |                |                
Sara Kaba Deme                                | kwg            |                |                
Sara Kaba Náà                                 | kwv            |                |                
Sara Kaba                                     | sbz            |                |                
Sara                                          | sre            |                |                
Saraiki                                       | skr            |                |                
Saramaccan                                    | srm            |                |                
Sarangani Blaan                               | bps            |                |                
Sarangani Manobo                              | mbs            |                |                
Sarasira                                      | zsa            |                |                
Saraveca                                      | sar            |                |                
Sardinian                                     | srd            | sc             |                
Sari                                          | asj            |                |                
Sarikoli                                      | srh            |                |                
Sarli                                         | sdf            |                |                
Sarsi                                         | srs            |                |                
Sartang                                       | onp            |                |                
Sarua                                         | swy            |                |                
Sarudu                                        | sdu            |                |                
Saruga                                        | sra            |                |                
Sasak                                         | sas            |                |                
Sasaru                                        | sxs            |                |                
Sassarese Sardinian                           | sdc            |                |                
Satawalese                                    | stw            |                |                
Saterfriesisch                                | stq            |                |                
Sateré-Mawé                                   | mav            |                |                
Saudi Arabian Sign Language                   | sdl            |                |                
Sauraseni Prākrit                             | psu            |                |                
Saurashtra                                    | saz            |                |                
Sauri                                         | srt            |                |                
Sauria Paharia                                | mjt            |                |                
Sause                                         | sao            |                |                
Sausi                                         | ssj            |                |                
Savara                                        | svr            |                |                
Savi                                          | sdg            |                |                
Savosavo                                      | svs            |                |                
Sawai                                         | szw            |                |                
Saweru                                        | swr            |                |                
Sawi                                          | saw            |                |                
Sawila                                        | swt            |                |                
Sawknah                                       | swn            |                |                
Saxwe Gbe                                     | sxw            |                |                
Saya                                          | say            |                |                
Sayula Popoluca                               | pos            |                |                
Scots                                         | sco            |                |                
Scottish Gaelic                               | gla            | gd             |                
Scythian                                      | xsc            |                |                
Sea Island Creole English                     | gul            |                |                
Seba                                          | kdg            |                |                
Sebat Bet Gurage                              | sgw            |                |                
Seberuang                                     | sbx            |                |                
Sebop                                         | sib            |                |                
Sebuyau                                       | snb            |                |                
Sechelt                                       | sec            |                |                
Secoya                                        | sey            |                |                
Sedang                                        | sed            |                |                
Sediq                                         | trv            |                |                
Sedoa                                         | tvw            |                |                
Seeku                                         | sos            |                |                
Segai                                         | sge            |                |                
Segeju                                        | seg            |                |                
Seget                                         | sbg            |                |                
Sehwi                                         | sfw            |                |                
Seimat                                        | ssg            |                |                
Seit-Kaitetu                                  | hik            |                |                
Sekani                                        | sek            |                |                
Sekapan                                       | skp            |                |                
Sekar                                         | skz            |                |                
Seke (Nepal)                                  | skj            |                |                
Seke (Vanuatu)                                | ske            |                |                
Sekele                                        | vaj            |                |                
Seki                                          | syi            |                |                
Seko Padang                                   | skx            |                |                
Seko Tengah                                   | sko            |                |                
Sekpele                                       | lip            |                |                
Selangor Sign Language                        | kgi            |                |                
Selaru                                        | slu            |                |                
Selayar                                       | sly            |                |                
Selee                                         | snw            |                |                
Selepet                                       | spl            |                |                
Selian                                        | sxl            |                |                
Selkup                                        | sel            |                |                
Selungai Murut                                | slg            |                |                
Seluwasan                                     | sws            |                |                
Semai                                         | sea            |                |                
Semandang                                     | sdm            |                |                
Semandang                                     | sdq            |                |                
Semaq Beri                                    | szc            |                |                
Sembakung Murut                               | sbr            |                |                
Semelai                                       | sza            |                |                
Semimi                                        | etz            |                |                
Semitic languages                             | sem            |                |                
Semnam                                        | ssm            |                |                
Semnani                                       | smy            |                |                
Sempan                                        | xse            |                |                
Sena                                          | seh            |                |                
Senara Sénoufo                                | seq            |                |                
Senaya                                        | syn            |                |                
Sene                                          | sej            |                |                
Seneca                                        | see            |                |                
Sened                                         | sds            |                |                
Sengele                                       | szg            |                |                
Senggi                                        | snu            |                |                
Sengo                                         | spk            |                |                
Sengseng                                      | ssz            |                |                
Senhaja De Srair                              | sjs            |                |                
Sensi                                         | sni            |                |                
Sentani                                       | set            |                |                
Senthang Chin                                 | sez            |                |                
Sentinel                                      | std            |                |                
Sepa (Indonesia)                              | spb            |                |                
Sepa (Papua New Guinea)                       | spe            |                |                
Sepik Iwam                                    | iws            |                |                
Sera                                          | sry            |                |                
Serbian                                       | srp            | sr             |                
Serbo-Croatian                                | hbs            | sh             |                
Sere                                          | swf            |                |                
Serer                                         | srr            |                |                
Seri                                          | sei            |                |                
Serili                                        | sve            |                |                
Seroa                                         | kqu            |                |                
Serrano                                       | ser            |                |                
Seru                                          | szd            |                |                
Serua                                         | srw            |                |                
Serudung Murut                                | srk            |                |                
Serui-Laut                                    | seu            |                |                
Seselwa Creole French                         | crs            |                |                
Seta                                          | stf            |                |                
Setaman                                       | stm            |                |                
Seti                                          | sbi            |                |                
Settla                                        | sta            |                |                
Severn Ojibwa                                 | ojs            |                |                
Sewa Bay                                      | sew            |                |                
Seychelles Sign Language                      | lsw            |                |                
Seze                                          | sze            |                |                
Sha                                           | scw            |                |                
Shabak                                        | sdb            |                |                
Shahmirzadi                                   | srz            |                |                
Shahrudi                                      | shm            |                |                
Shall-Zwall                                   | sha            |                |                
Shama-Sambuga                                 | sqa            |                |                
Shamang                                       | xsh            |                |                
Shambala                                      | ksb            |                |                
Shan                                          | shn            |                |                
Shanenawa                                     | swo            |                |                
Shanga                                        | sho            |                |                
Sharanahua                                    | mcd            |                |                
Shark Bay                                     | ssv            |                |                
Sharwa                                        | swq            |                |                
Shasta                                        | sht            |                |                
Shatt                                         | shj            |                |                
Shau                                          | sqh            |                |                
Shawnee                                       | sjw            |                |                
She                                           | shx            |                |                
Shehri                                        | shv            |                |                
Shekhawati                                    | swv            |                |                
Shekkacho                                     | moy            |                |                
Sheko                                         | she            |                |                
Shelta                                        | sth            |                |                
Shempire Senoufo                              | seb            |                |                
Shendu                                        | shl            |                |                
Sheni                                         | scv            |                |                
Sherbro                                       | bun            |                |                
Sherdukpen                                    | sdp            |                |                
Sherpa                                        | xsr            |                |                
Sheshi Kham                                   | kip            |                |                
Shi                                           | shr            |                |                
Shihhi Arabic                                 | ssh            |                |                
Shiki                                         | gua            |                |                
Shilluk                                       | shk            |                |                
Shina                                         | scl            |                |                
Shinabo                                       | snh            |                |                
Shipibo-Conibo                                | shp            |                |                
Sholaga                                       | sle            |                |                
Shom Peng                                     | sii            |                |                
Shona                                         | sna            | sn             |                
Shoo-Minda-Nye                                | bcv            |                |                
Shor                                          | cjs            |                |                
Shoshoni                                      | shh            |                |                
Shua                                          | shg            |                |                
Shuadit                                       | sdt            |                |                
Shuar                                         | jiv            |                |                
Shubi                                         | suj            |                |                
Shughni                                       | sgh            |                |                
Shuhi                                         | sxg            |                |                
Shumashti                                     | sts            |                |                
Shumcho                                       | scu            |                |                
Shuswap                                       | shs            |                |                
Shuwa-Zamani                                  | ksa            |                |                
Shwai                                         | shw            |                |                
Shwe Palaung                                  | pll            |                |                
Sialum                                        | slw            |                |                
Siamou                                        | sif            |                |                
Sian                                          | spg            |                |                
Siane                                         | snp            |                |                
Siang                                         | sya            |                |                
Siar-Lak                                      | sjr            |                |                
Siawi                                         | mmp            |                |                
Sibe                                          | nco            |                |                
Siberian Tatar                                | sty            |                |                
Sibu Melanau                                  | sdx            |                |                
Sicanian                                      | sxc            |                |                
Sicel                                         | scx            |                |                
Sichuan Yi                                    | iii            | ii             |                
Sicilian                                      | scn            |                |                
Siculo Arabic                                 | sqr            |                |                
Sidamo                                        | sid            |                |                
Sidetic                                       | xsd            |                |                
Sie                                           | erg            |                |                
Sierra Leone Sign Language                    | sgx            |                |                
Sierra Negra Nahuatl                          | nsu            |                |                
Sierra de Juárez Zapotec                      | zaa            |                |                
Sighu                                         | sxe            |                |                
Sign Languages                                | sgn            |                |                
Sihan                                         | snr            |                |                
Sihuas Ancash Quechua                         | qws            |                |                
Sika                                          | ski            |                |                
Sikaiana                                      | sky            |                |                
Sikaritai                                     | tty            |                |                
Sikiana                                       | sik            |                |                
Sikkimese                                     | sip            |                |                
Siksika                                       | bla            |                |                
Sikule                                        | skh            |                |                
Sila                                          | slt            |                |                
Silacayoapan Mixtec                           | mks            |                |                
Sileibi                                       | sbq            |                |                
Silesian                                      | szl            |                |                
Silimo                                        | wul            |                |                
Siliput                                       | mkc            |                |                
Silopi                                        | xsp            |                |                
Silt'e                                        | stv            |                |                
Simaa                                         | sie            |                |                
Simba                                         | sbw            |                |                
Simbali                                       | smg            |                |                
Simbari                                       | smb            |                |                
Simbo                                         | sbb            |                |                
Simeku                                        | smz            |                |                
Simeulue                                      | smr            |                |                
Simte                                         | smt            |                |                
Sinagen                                       | siu            |                |                
Sinasina                                      | sst            |                |                
Sinaugoro                                     | snc            |                |                
Sindarin                                      | sjn            |                |                
Sindhi Bhil                                   | sbn            |                |                
Sindhi                                        | snd            | sd             |                
Sindihui Mixtec                               | xts            |                |                
Singa                                         | sgm            |                |                
Singapore Sign Language                       | sls            |                |                
Singpho                                       | sgp            |                |                
Sinhala                                       | sin            | si             |                
Sinicahua Mixtec                              | xti            |                |                
Sininkere                                     | skq            |                |                
Sino-Tibetan languages                        | sit            |                |                
Sinte Romani                                  | rmo            |                |                
Sinyar                                        | sys            |                |                
Sio                                           | xsi            |                |                
Siona                                         | snn            |                |                
Siouan languages                              | sio            |                |                
Sipacapense                                   | qum            |                |                
Sira                                          | swj            |                |                
Siraya                                        | fos            |                |                
Sirenik Yupik                                 | ysr            |                |                
Siri                                          | sir            |                |                
Siriano                                       | sri            |                |                
Sirionó                                       | srq            |                |                
Sirmauri                                      | srx            |                |                
Siroi                                         | ssd            |                |                
Sissala                                       | sld            |                |                
Sissano                                       | sso            |                |                
Siuslaw                                       | sis            |                |                
Sivandi                                       | siy            |                |                
Sivia Sign Language                           | lsv            |                |                
Siwai                                         | siw            |                |                
Siwi                                          | siz            |                |                
Siwu                                          | akp            |                |                
Siyin Chin                                    | csy            |                |                
Skagit                                        | ska            |                |                
Skalvian                                      | svx            |                |                
Skepi Creole Dutch                            | skw            |                |                
Skolt Sami                                    | sms            |                |                
Skou                                          | skv            |                |                
Slave (Athapascan)                            | den            |                |                
Slavic languages                              | sla            |                |                
Slavomolisano                                 | svm            |                |                
Slovak                                        | slo            | sk             | slk            
Slovakian Sign Language                       | svk            |                |                
Slovenian                                     | slv            | sl             |                
Small Flowery Miao                            | sfm            |                |                
Smärky Kanum                                  | kxq            |                |                
Snohomish                                     | sno            |                |                
So (Democratic Republic of Congo)             | soc            |                |                
So'a                                          | ssq            |                |                
Sobei                                         | sob            |                |                
Sochiapam Chinantec                           | cso            |                |                
Soga                                          | xog            |                |                
Sogdian                                       | sog            |                |                
Soi                                           | soj            |                |                
Sok                                           | skk            |                |                
Sokoro                                        | sok            |                |                
Solano                                        | xso            |                |                
Soli                                          | sby            |                |                
Solomon Islands Sign Language                 | szs            |                |                
Solong                                        | aaw            |                |                
Solos                                         | sol            |                |                
Som                                           | smc            |                |                
Somali                                        | som            | so             |                
Somba-Siawari                                 | bmu            |                |                
Somrai                                        | sor            |                |                
Somray                                        | smu            |                |                
Somyev                                        | kgt            |                |                
Sonaga                                        | ysg            |                |                
Sonde                                         | shc            |                |                
Songa                                         | sgo            |                |                
Songe                                         | sop            |                |                
Songhai languages                             | son            |                |                
Songlai Chin                                  | csj            |                |                
Songo                                         | soo            |                |                
Songomeno                                     | soe            |                |                
Songoora                                      | sod            |                |                
Sonha                                         | soi            |                |                
Sonia                                         | siq            |                |                
Soninke                                       | snk            |                |                
Sonsorol                                      | sov            |                |                
Soo                                           | teu            |                |                
Sop                                           | urw            |                |                
Soqotri                                       | sqt            |                |                
Sora                                          | srb            |                |                
Sorbian languages                             | wen            |                |                
Sori-Harengan                                 | sbh            |                |                
Sorkhei                                       | sqo            |                |                
Sorothaptic                                   | sxo            |                |                
Sorsogon Ayta                                 | ays            |                |                
Sos Kundi                                     | sdk            |                |                
Sota Kanum                                    | krz            |                |                
Sou Nama                                      | tlt            |                |                
Sou Upaa                                      | wha            |                |                
Sou                                           | sqq            |                |                
South African Sign Language                   | sfs            |                |                
South American Indian languages               | sai            |                |                
South Awyu                                    | aws            |                |                
South Azerbaijani                             | azb            |                |                
South Bolivian Quechua                        | quh            |                |                
South Caucasian languages                     | ccs            |                |                
South Central Banda                           | lnl            |                |                
South Central Dinka                           | dib            |                |                
South Efate                                   | erk            |                |                
South Fali                                    | fal            |                |                
South Giziga                                  | giz            |                |                
South Lembata                                 | lmf            |                |                
South Levantine Arabic                        | ajp            |                |                
South Marquesan                               | mqm            |                |                
South Muyu                                    | kts            |                |                
South Ndebele                                 | nbl            | nr             |                
South Nuaulu                                  | nxl            |                |                
South Picene                                  | spx            |                |                
South Slavey                                  | xsl            |                |                
South Slavic languages                        | zls            |                |                
South Tairora                                 | omw            |                |                
South Ucayali Ashéninka                       | cpy            |                |                
South Watut                                   | mcy            |                |                
South Wemale                                  | tlw            |                |                
South West Bay                                | sns            |                |                
Southeast Ambrym                              | tvk            |                |                
Southeast Babar                               | vbb            |                |                
Southeast Ijo                                 | ijs            |                |                
Southeast Pashai                              | psi            |                |                
Southeast Tasmanian                           | xpf            |                |                
Southeastern Dinka                            | dks            |                |                
Southeastern Ixtlán Zapotec                   | zpd            |                |                
Southeastern Kolami                           | nit            |                |                
Southeastern Nochixtlán Mixtec                | mxy            |                |                
Southeastern Pomo                             | pom            |                |                
Southeastern Puebla Nahuatl                   | npl            |                |                
Southeastern Tarahumara                       | tcu            |                |                
Southeastern Tepehuan                         | stp            |                |                
Southern Alta                                 | agy            |                |                
Southern Altai                                | alt            |                |                
Southern Amami-Oshima                         | ams            |                |                
Southern Aymara                               | ayc            |                |                
Southern Bai                                  | bfs            |                |                
Southern Balochi                              | bcc            |                |                
Southern Betsimisaraka Malagasy               | bjq            |                |                
Southern Betsimisaraka Malagasy               | bzc            |                |                
Southern Binukidnon                           | mtw            |                |                
Southern Birifor                              | biv            |                |                
Southern Bobo Madaré                          | bwq            |                |                
Southern Bontok                               | obk            |                |                
Southern Carrier                              | caf            |                |                
Southern Catanduanes Bikol                    | bln            |                |                
Southern Conchucos Ancash Quechua             | qxo            |                |                
Southern Dagaare                              | dga            |                |                
Southern Dong                                 | kmc            |                |                
Southern East Cree                            | crj            |                |                
Southern Ghale                                | ghe            |                |                
Southern Gondi                                | ggo            |                |                
Southern Grebo                                | grj            |                |                
Southern Guiyang Hmong                        | hmy            |                |                
Southern Haida                                | hax            |                |                
Southern Hindko                               | hnd            |                |                
Southern Kalapuya                             | sxk            |                |                
Southern Kalinga                              | ksc            |                |                
Southern Katang                               | sct            |                |                
Southern Kisi                                 | kss            |                |                
Southern Kiwai                                | kjd            |                |                
Southern Kurdish                              | sdh            |                |                
Southern Lolopo                               | ysp            |                |                
Southern Luri                                 | luz            |                |                
Southern Ma'di                                | snm            |                |                
Southern Mashan Hmong                         | hma            |                |                
Southern Mnong                                | mnn            |                |                
Southern Muji                                 | ymc            |                |                
Southern Nago                                 | nqg            |                |                
Southern Nambikuára                           | nab            |                |                
Southern Ngbandi                              | nbw            |                |                
Southern Nicobarese                           | nik            |                |                
Southern Nisu                                 | nsd            |                |                
Southern Nuni                                 | nnw            |                |                
Southern Ohlone                               | css            |                |                
Southern One                                  | osu            |                |                
Southern Pame                                 | pmz            |                |                
Southern Pashto                               | pbt            |                |                
Southern Pastaza Quechua                      | qup            |                |                
Southern Ping Chinese                         | csp            |                |                
Southern Pomo                                 | peq            |                |                
Southern Puebla Mixtec                        | mit            |                |                
Southern Puget Sound Salish                   | slh            |                |                
Southern Pumi                                 | pmj            |                |                
Southern Qiandong Miao                        | hms            |                |                
Southern Qiang                                | qxs            |                |                
Southern Rengma Naga                          | nre            |                |                
Southern Rincon Zapotec                       | zsr            |                |                
Southern Roglai                               | rgs            |                |                
Southern Sama                                 | ssb            |                |                
Southern Sami                                 | sma            |                |                
Southern Samo                                 | sbd            |                |                
Southern Sierra Miwok                         | skd            |                |                
Southern Sorsoganon                           | srv            |                |                
Southern Sotho                                | sot            | st             |                
Southern Subanen                              | laa            |                |                
Southern Thai                                 | sou            |                |                
Southern Tidung                               | itd            |                |                
Southern Tiwa                                 | tix            |                |                
Southern Toussian                             | wib            |                |                
Southern Tujia                                | tjs            |                |                
Southern Tutchone                             | tce            |                |                
Southern Uzbek                                | uzs            |                |                
Southern Yamphu                               | lrr            |                |                
Southern Yukaghir                             | yux            |                |                
Southwest Gbaya                               | gso            |                |                
Southwest Palawano                            | plv            |                |                
Southwest Pashai                              | psh            |                |                
Southwest Tanna                               | nwi            |                |                
Southwestern Bontok                           | vbk            |                |                
Southwestern Dinka                            | dik            |                |                
Southwestern Fars                             | fay            |                |                
Southwestern Guiyang Hmong                    | hmg            |                |                
Southwestern Huishui Hmong                    | hmh            |                |                
Southwestern Nisu                             | nsv            |                |                
Southwestern Tamang                           | tsf            |                |                
Southwestern Tarahumara                       | twr            |                |                
Southwestern Tasmanian                        | xpx            |                |                
Southwestern Tepehuan                         | tla            |                |                
Southwestern Tlaxiaco Mixtec                  | meh            |                |                
Sowa                                          | sww            |                |                
Sowanda                                       | sow            |                |                
Soyaltepec Mazatec                            | vmp            |                |                
Soyaltepec Mixtec                             | vmq            |                |                
Spanish Sign Language                         | ssp            |                |                
Spanish                                       | spa            | es             |                
Spiti Bhoti                                   | spt            |                |                
Spokane                                       | spo            |                |                
Squamish                                      | squ            |                |                
Sranan Tongo                                  | srn            |                |                
Sri Lankan Creole Malay                       | sci            |                |                
Sri Lankan Sign Language                      | sqs            |                |                
Standard Arabic                               | arb            |                |                
Standard Estonian                             | ekk            |                |                
Standard Latvian                              | lvs            |                |                
Standard Malay                                | zsm            |                |                
Standard Moroccan Tamazight                   | zgh            |                |                
Stellingwerfs                                 | stl            |                |                
Stod Bhoti                                    | sbu            |                |                
Stoney                                        | sto            |                |                
Straits Salish                                | str            |                |                
Suabo                                         | szp            |                |                
Suarmin                                       | seo            |                |                
Suau                                          | swp            |                |                
Suba                                          | sxb            |                |                
Suba-Simbiti                                  | ssc            |                |                
Subi                                          | xsj            |                |                
Subiya                                        | sbs            |                |                
Subtiaba                                      | sut            |                |                
Sudanese Arabic                               | apd            |                |                
Sudanese Creole Arabic                        | pga            |                |                
Sudest                                        | tgo            |                |                
Sudovian                                      | xsv            |                |                
Suena                                         | sue            |                |                
Suga                                          | sgi            |                |                
Suganga                                       | sug            |                |                
Sugut Dusun                                   | kzs            |                |                
Sui                                           | swi            |                |                
Suki                                          | sui            |                |                
Suku                                          | sub            |                |                
Sukuma                                        | suk            |                |                
Sukur                                         | syk            |                |                
Sukurum                                       | zsu            |                |                
Sula                                          | szn            |                |                
Sulka                                         | sua            |                |                
Sulod                                         | srg            |                |                
Suma                                          | sqm            |                |                
Sumariup                                      | siv            |                |                
Sumau                                         | six            |                |                
Sumbawa                                       | smw            |                |                
Sumbwa                                        | suw            |                |                
Sumerian                                      | sux            |                |                
Sumi Naga                                     | nsm            |                |                
Sumo-Mayangna                                 | sum            |                |                
Sumtu Chin                                    | csv            |                |                
Sunam                                         | ssk            |                |                
Sundanese                                     | sun            | su             |                
Sunwar                                        | suz            |                |                
Suoy                                          | syo            |                |                
Supyire Senoufo                               | spp            |                |                
Sur                                           | tdl            |                |                
Surbakhal                                     | sbj            |                |                
Surgujia                                      | sgj            |                |                
Surigaonon                                    | sgd            |                |                
Surigaonon                                    | sul            |                |                
Surjapuri                                     | sjp            |                |                
Sursurunga                                    | sgz            |                |                
Suruahá                                       | swx            |                |                
Surubu                                        | sde            |                |                
Suruí Do Pará                                 | mdz            |                |                
Suruí                                         | sru            |                |                
Susquehannock                                 | sqn            |                |                
Susu                                          | sus            |                |                
Susuami                                       | ssu            |                |                
Suundi                                        | sdj            |                |                
Suwawa                                        | swu            |                |                
Suyá                                          | suy            |                |                
Svan                                          | sva            |                |                
Swabian                                       | swg            |                |                
Swahili (individual language)                 | swh            |                |                
Swahili (macrolanguage)                       | swa            | sw             |                
Swampy Cree                                   | csw            |                |                
Swati                                         | ssw            | ss             |                
Swedish Sign Language                         | swl            |                |                
Swedish                                       | swe            | sv             |                
Swiss German                                  | gsw            |                |                
Swiss-French Sign Language                    | ssr            |                |                
Swiss-German Sign Language                    | sgg            |                |                
Swiss-Italian Sign Language                   | slf            |                |                
Swo                                           | sox            |                |                
Syenara Senoufo                               | shz            |                |                
Sylheti                                       | syl            |                |                
Syriac                                        | syr            |                |                
Sáliba                                        | slc            |                |                
São Paulo Kaingáng                            | zkp            |                |                
Sãotomense                                    | cri            |                |                
Sìcìté Sénoufo                                | sep            |                |                
Sô                                            | sss            |                |                
T'apo                                         | lgn            |                |                
T'en                                          | tct            |                |                
Ta'izzi-Adeni Arabic                          | acq            |                |                
Taabwa                                        | tap            |                |                
Tabaa Zapotec                                 | zat            |                |                
Tabaru                                        | tby            |                |                
Tabasco Chontal                               | chf            |                |                
Tabasco Nahuatl                               | nhc            |                |                
Tabasco Zoque                                 | zoq            |                |                
Tabassaran                                    | tab            |                |                
Tabla                                         | tnm            |                |                
Tabo                                          | knv            |                |                
Tabriak                                       | tzx            |                |                
Tacahua Mixtec                                | xtt            |                |                
Tacana                                        | tna            |                |                
Tachawit                                      | shy            |                |                
Tachelhit                                     | shi            |                |                
Tachoni                                       | lts            |                |                
Tadaksahak                                    | dsq            |                |                
Tado                                          | klw            |                |                
Tadyawan                                      | tdy            |                |                
Tae'                                          | rob            |                |                
Tafi                                          | tcd            |                |                
Tagabawa                                      | bgs            |                |                
Tagakaulo                                     | klg            |                |                
Tagal Murut                                   | mvv            |                |                
Tagalaka                                      | tgz            |                |                
Tagalog                                       | tgl            | tl             |                
Tagargrent                                    | oua            |                |                
Tagbanwa                                      | tbw            |                |                
Tagbu                                         | tbm            |                |                
Tagdal                                        | tda            |                |                
Tagin                                         | tgj            |                |                
Tagish                                        | tgx            |                |                
Tagoi                                         | tag            |                |                
Tagwana Senoufo                               | tgw            |                |                
Tahaggart Tamahaq                             | thv            |                |                
Tahitian                                      | tah            | ty             |                
Tahltan                                       | tht            |                |                
Tai Daeng                                     | tyr            |                |                
Tai Dam                                       | blt            |                |                
Tai Do                                        | tyj            |                |                
Tai Dón                                       | twh            |                |                
Tai Hang Tong                                 | thc            |                |                
Tai Hongjin                                   | tiz            |                |                
Tai Laing                                     | tjl            |                |                
Tai Loi                                       | tlq            |                |                
Tai Long                                      | thi            |                |                
Tai Mène                                      | tmp            |                |                
Tai Nüa                                       | tdd            |                |                
Tai Pao                                       | tpo            |                |                
Tai Thanh                                     | tmm            |                |                
Tai Ya                                        | cuu            |                |                
Tai languages                                 | tai            |                |                
Tai                                           | taw            |                |                
Taiap                                         | gpn            |                |                
Taikat                                        | aos            |                |                
Tainae                                        | ago            |                |                
Taino                                         | tnq            |                |                
Tairaha                                       | bxa            |                |                
Tairuma                                       | uar            |                |                
Taita                                         | dav            |                |                
Taivoan                                       | tvx            |                |                
Taiwan Sign Language                          | tss            |                |                
Taje                                          | pee            |                |                
Tajik                                         | tgk            | tg             |                
Tajiki Arabic                                 | abh            |                |                
Tajio                                         | tdj            |                |                
Tajuasohn                                     | tja            |                |                
Takelma                                       | tkm            |                |                
Takestani                                     | tks            |                |                
Takia                                         | tbc            |                |                
Takpa                                         | tkk            |                |                
Takua                                         | tkz            |                |                
Takuu                                         | nho            |                |                
Takwane                                       | tke            |                |                
Tal                                           | tal            |                |                
Tala                                          | tak            |                |                
Talaud                                        | tld            |                |                
Taliabu                                       | tlv            |                |                
Talieng                                       | tdf            |                |                
Talinga-Bwisi                                 | tlj            |                |                
Talise                                        | tlr            |                |                
Talodi                                        | tlo            |                |                
Taloki                                        | tlk            |                |                
Talondo'                                      | tln            |                |                
Talossan                                      | tzl            |                |                
Talu                                          | yta            |                |                
Talur                                         | ilw            |                |                
Talysh                                        | tly            |                |                
Tama (Chad)                                   | tma            |                |                
Tama (Colombia)                               | ten            |                |                
Tamagario                                     | tcg            |                |                
Taman (Indonesia)                             | tmn            |                |                
Taman (Myanmar)                               | tcl            |                |                
Tamanaku                                      | tmz            |                |                
Tamashek                                      | tmh            |                |                
Tamasheq                                      | taq            |                |                
Tamazola Mixtec                               | vmx            |                |                
Tambas                                        | tdk            |                |                
Tambora                                       | xxt            |                |                
Tambotalo                                     | tls            |                |                
Tambunan Dusun                                | kzt            |                |                
Tami                                          | tmy            |                |                
Tamil                                         | tam            | ta             |                
Tamki                                         | tax            |                |                
Tamnim Citak                                  | tml            |                |                
Tampias Lobu                                  | low            |                |                
Tampuan                                       | tpu            |                |                
Tampulma                                      | tpm            |                |                
Tanacross                                     | tcb            |                |                
Tanahmerah                                    | tcm            |                |                
Tanaina                                       | tfn            |                |                
Tanapag                                       | tpv            |                |                
Tandaganon                                    | tgn            |                |                
Tandia                                        | tni            |                |                
Tandroy-Mahafaly Malagasy                     | tdx            |                |                
Tanema                                        | tnx            |                |                
Tangale                                       | tan            |                |                
Tangchangya                                   | tnv            |                |                
Tangga                                        | tgg            |                |                
Tanggu                                        | tgu            |                |                
Tangkhul Naga (India)                         | nmf            |                |                
Tangkhul Naga (Myanmar)                       | ntx            |                |                
Tangko                                        | tkx            |                |                
Tanglang                                      | ytl            |                |                
Tangoa                                        | tgp            |                |                
Tangshewi                                     | tnf            |                |                
Tanguat                                       | tbs            |                |                
Tangut                                        | txg            |                |                
Tanimbili                                     | tbe            |                |                
Tanimuca-Retuarã                              | tnc            |                |                
Tanjijili                                     | uji            |                |                
Tanosy Malagasy                               | txy            |                |                
Tanudan Kalinga                               | kml            |                |                
Tanzanian Sign Language                       | tza            |                |                
Tapeba                                        | tbb            |                |                
Tapei                                         | afp            |                |                
Tapieté                                       | tpj            |                |                
Tapirapé                                      | taf            |                |                
Tarao Naga                                    | tro            |                |                
Tareng                                        | tgr            |                |                
Tariana                                       | tae            |                |                
Tarifit                                       | rif            |                |                
Tarjumo                                       | txj            |                |                
Tarok                                         | yer            |                |                
Tarpia                                        | tpf            |                |                
Tartessian                                    | txr            |                |                
Taruma                                        | tdm            |                |                
Tasawaq                                       | twq            |                |                
Tase Naga                                     | nst            |                |                
Tasmanian                                     | xtz            |                |                
Tasmate                                       | tmt            |                |                
Tataltepec Chatino                            | cta            |                |                
Tatana                                        | txx            |                |                
Tatar                                         | tat            | tt             |                
Tatuyo                                        | tav            |                |                
Tauade                                        | ttd            |                |                
Taulil                                        | tuh            |                |                
Taungyo                                       | tco            |                |                
Taupota                                       | tpa            |                |                
Tause                                         | tad            |                |                
Taushiro                                      | trr            |                |                
Tausug                                        | tsg            |                |                
Tauya                                         | tya            |                |                
Taveta                                        | tvs            |                |                
Tavoyan                                       | tvn            |                |                
Tavringer Romani                              | rmu            |                |                
Tawala                                        | tbo            |                |                
Tawallammat Tamajaq                           | ttq            |                |                
Tawandê                                       | xtw            |                |                
Tawang Monpa                                  | twm            |                |                
Tawara                                        | twl            |                |                
Taworta                                       | tbp            |                |                
Tawoyan                                       | twy            |                |                
Tawr Chin                                     | tcp            |                |                
Tay Boi                                       | tas            |                |                
Tay Khang                                     | tnu            |                |                
Tayabas Ayta                                  | ayy            |                |                
Tayart Tamajeq                                | thz            |                |                
Tayo                                          | cks            |                |                
Taznatit                                      | grr            |                |                
Tboli                                         | tbl            |                |                
Tchitchege                                    | tck            |                |                
Tchumbuli                                     | bqa            |                |                
Te'un                                         | tve            |                |                
Teanu                                         | tkw            |                |                
Tebul Sign Language                           | tsy            |                |                
Tebul Ure Dogon                               | dtu            |                |                
Tecpatlán Totonac                             | tcw            |                |                
Tedaga                                        | tuq            |                |                
Tedim Chin                                    | ctd            |                |                
Tee                                           | tkq            |                |                
Tefaro                                        | tfo            |                |                
Tegali                                        | ras            |                |                
Tehit                                         | kps            |                |                
Tehuelche                                     | teh            |                |                
Tejalapan Zapotec                             | ztt            |                |                
Teke-Ebo                                      | ebo            |                |                
Teke-Fuumu                                    | ifm            |                |                
Teke-Kukuya                                   | kkw            |                |                
Teke-Laali                                    | lli            |                |                
Teke-Nzikou                                   | nzu            |                |                
Teke-Tege                                     | teg            |                |                
Teke-Tsaayi                                   | tyi            |                |                
Teke-Tyee                                     | tyx            |                |                
Tektiteko                                     | ttc            |                |                
Tela-Masbuar                                  | tvm            |                |                
Telefol                                       | tlf            |                |                
Telugu                                        | tel            | te             |                
Tem                                           | kdh            |                |                
Temacine Tamazight                            | tjo            |                |                
Temascaltepec Nahuatl                         | nhv            |                |                
Tembo (Kitembo)                               | tbt            |                |                
Tembo (Motembo)                               | tmv            |                |                
Tembé                                         | tqb            |                |                
Teme                                          | tdo            |                |                
Temein                                        | teq            |                |                
Temi                                          | soz            |                |                
Temiar                                        | tea            |                |                
Temoaya Otomi                                 | ott            |                |                
Temoq                                         | tmo            |                |                
Tempasuk Dusun                                | tdu            |                |                
Temuan                                        | tmw            |                |                
Ten'edn                                       | tnz            |                |                
Tena Lowland Quichua                          | quw            |                |                
Tenango Otomi                                 | otn            |                |                
Tene Kan Dogon                                | dtk            |                |                
Tenggarong Kutai Malay                        | vkt            |                |                
Tengger                                       | tes            |                |                
Tenharim                                      | pah            |                |                
Tenino                                        | tqn            |                |                
Tenis                                         | tns            |                |                
Tennet                                        | tex            |                |                
Teop                                          | tio            |                |                
Teor                                          | tev            |                |                
Tepecano                                      | tep            |                |                
Tepetotutla Chinantec                         | cnt            |                |                
Tepeuxila Cuicatec                            | cux            |                |                
Tepinapa Chinantec                            | cte            |                |                
Tepo Krumen                                   | ted            |                |                
Ter Sami                                      | sjt            |                |                
Tera                                          | ttr            |                |                
Terebu                                        | trb            |                |                
Terei                                         | buo            |                |                
Tereno                                        | ter            |                |                
Teressa                                       | tef            |                |                
Tereweng                                      | twg            |                |                
Teribe                                        | tfr            |                |                
Terik                                         | tec            |                |                
Termanu                                       | twu            |                |                
Ternate                                       | tft            |                |                
Ternateño                                     | tmg            |                |                
Tesaka Malagasy                               | tkg            |                |                
Tese                                          | keg            |                |                
Teshenawa                                     | twc            |                |                
Teso                                          | teo            |                |                
Tetela                                        | tll            |                |                
Tetelcingo Nahuatl                            | nhg            |                |                
Tetete                                        | teb            |                |                
Tetserret                                     | tez            |                |                
Tetum                                         | tet            |                |                
Tetun Dili                                    | tdt            |                |                
Teutila Cuicatec                              | cut            |                |                
Tewa (Indonesia)                              | twe            |                |                
Tewa (USA)                                    | tew            |                |                
Tewe                                          | twx            |                |                
Texcatepec Otomi                              | otx            |                |                
Texistepec Popoluca                           | poq            |                |                
Texmelucan Zapotec                            | zpz            |                |                
Tezoatlán Mixtec                              | mxb            |                |                
Tha                                           | thy            |                |                
Thachanadan                                   | thn            |                |                
Thado Chin                                    | tcz            |                |                
Thai Sign Language                            | tsq            |                |                
Thai Song                                     | soa            |                |                
Thai                                          | tha            | th             |                
Thaiphum Chin                                 | cth            |                |                
Thakali                                       | ths            |                |                
Thangal Naga                                  | nki            |                |                
Thangmi                                       | thf            |                |                
Thao                                          | ssf            |                |                
Tharaka                                       | thk            |                |                
Thawa                                         | xtv            |                |                
Thaypan                                       | typ            |                |                
The                                           | thx            |                |                
Thiin                                         | iin            |                |                
Tho                                           | tou            |                |                
Thompson                                      | thp            |                |                
Thopho                                        | ytp            |                |                
Thracian                                      | txh            |                |                
Thu Lao                                       | tyl            |                |                
Thudam                                        | thw            |                |                
Thulung                                       | tdh            |                |                
Thur                                          | lth            |                |                
Thuri                                         | thu            |                |                
Tiagbamrin Aizi                               | ahi            |                |                
Tiale                                         | mnl            |                |                
Tiang                                         | tbj            |                |                
Tibea                                         | ngy            |                |                
Tibetan Sign Language                         | lsn            |                |                
Tibetan                                       | tib            | bo             | bod            
Tibeto-Burman languages                       | tbq            |                |                
Tichurong                                     | tcn            |                |                
Ticuna                                        | tca            |                |                
Tidaá Mixtec                                  | mtx            |                |                
Tidikelt Tamazight                            | tia            |                |                
Tidong                                        | tid            |                |                
Tidore                                        | tvo            |                |                
Tiemacèwè Bozo                                | boo            |                |                
Tiene                                         | tii            |                |                
Tifal                                         | tif            |                |                
Tigak                                         | tgc            |                |                
Tigon Mbembe                                  | nza            |                |                
Tigre                                         | tig            |                |                
Tigrinya                                      | tir            | ti             |                
Tii                                           | txq            |                |                
Tijaltepec Mixtec                             | xtl            |                |                
Tikar                                         | tik            |                |                
Tikopia                                       | tkp            |                |                
Tilapa Otomi                                  | otl            |                |                
Tillamook                                     | til            |                |                
Tilquiapan Zapotec                            | zts            |                |                
Tilung                                        | tij            |                |                
Tima                                          | tms            |                |                
Timbe                                         | tim            |                |                
Timne                                         | tem            |                |                
Timor Pidgin                                  | tvy            |                |                
Timucua                                       | tjm            |                |                
Timugon Murut                                 | tih            |                |                
Tinani                                        | lbf            |                |                
Tindi                                         | tin            |                |                
Tingal                                        | tie            |                |                
Tingui-Boto                                   | tgv            |                |                
Tinigua                                       | tit            |                |                
Tinoc Kallahan                                | tne            |                |                
Tinputz                                       | tpz            |                |                
Tippera                                       | tpe            |                |                
Tira                                          | tic            |                |                
Tirahi                                        | tra            |                |                
Tiranige Diga Dogon                           | tde            |                |                
Tiri                                          | cir            |                |                
Tirmaga-Chai Suri                             | suq            |                |                
Tiruray                                       | tiy            |                |                
Tita                                          | tdq            |                |                
Titan                                         | ttv            |                |                
Tiv                                           | tiv            |                |                
Tiwa                                          | lax            |                |                
Tiwi                                          | tiw            |                |                
Tiyaa                                         | tyy            |                |                
Tiéfo                                         | tiq            |                |                
Tiéyaxo Bozo                                  | boz            |                |                
Tjungundji                                    | tjj            |                |                
Tjupany                                       | tjp            |                |                
Tjurruru                                      | tju            |                |                
Tlachichilco Tepehua                          | tpt            |                |                
Tlacoapa Me'phaa                              | tpl            |                |                
Tlacoatzintepec Chinantec                     | ctl            |                |                
Tlacolulita Zapotec                           | zpk            |                |                
Tlahuitoltepec Mixe                           | mxp            |                |                
Tlamacazapa Nahuatl                           | nuz            |                |                
Tlazoyaltepec Mixtec                          | mqh            |                |                
Tlingit                                       | tli            |                |                
To                                            | toz            |                |                
To'abaita                                     | mlu            |                |                
Toaripi                                       | tqo            |                |                
Toba                                          | tob            |                |                
Toba-Maskoy                                   | tmf            |                |                
Tobagonian Creole English                     | tgh            |                |                
Tobanga                                       | tng            |                |                
Tobati                                        | tti            |                |                
Tobelo                                        | tlb            |                |                
Tobian                                        | tox            |                |                
Tobilung                                      | tgb            |                |                
Tobo                                          | tbv            |                |                
Tocantins Asurini                             | asu            |                |                
Tocho                                         | taz            |                |                
Toda                                          | tcx            |                |                
Todrah                                        | tdr            |                |                
Tofanma                                       | tlg            |                |                
Tofin Gbe                                     | tfi            |                |                
Togbo-Vara Banda                              | tor            |                |                
Togoyo                                        | tgy            |                |                
Tohono O'odham                                | ood            |                |                
Tojolabal                                     | toj            |                |                
Tok Pisin                                     | tpi            |                |                
Tokano                                        | zuh            |                |                
Tokelau                                       | tkl            |                |                
Tokharian A                                   | xto            |                |                
Tokharian B                                   | txb            |                |                
Toki Pona                                     | tok            |                |                
Toku-No-Shima                                 | tkn            |                |                
Tol                                           | jic            |                |                
Tolaki                                        | lbw            |                |                
Tolomako                                      | tlm            |                |                
Tolowa                                        | tol            |                |                
Toma                                          | tod            |                |                
Tomadino                                      | tdi            |                |                
Tombelala                                     | ttp            |                |                
Tombonuo                                      | txa            |                |                
Tombulu                                       | tom            |                |                
Tomedes                                       | toe            |                |                
Tomini                                        | txm            |                |                
Tommo So Dogon                                | dto            |                |                
Tomo Kan Dogon                                | dtm            |                |                
Tomoip                                        | tqp            |                |                
Tondano                                       | tdn            |                |                
Tondi Songway Kiini                           | tst            |                |                
Tonga (Nyasa)                                 | tog            |                |                
Tonga (Tonga Islands)                         | ton            | to             |                
Tonga (Zambia)                                | toi            |                |                
Tongwe                                        | tny            |                |                
Tonjon                                        | tjn            |                |                
Tonkawa                                       | tqw            |                |                
Tonsawang                                     | tnw            |                |                
Tonsea                                        | txs            |                |                
Tontemboan                                    | tnt            |                |                
Tooro                                         | ttj            |                |                
Topoiyo                                       | toy            |                |                
Toposa                                        | toq            |                |                
Toraja-Sa'dan                                 | sda            |                |                
Toram                                         | trj            |                |                
Torau                                         | ttu            |                |                
Tornedalen Finnish                            | fit            |                |                
Toro So Dogon                                 | dts            |                |                
Toro Tegu Dogon                               | dtt            |                |                
Toro                                          | tdv            |                |                
Toromono                                      | tno            |                |                
Torona                                        | tqr            |                |                
Torres Strait Creole                          | tcs            |                |                
Torricelli                                    | tei            |                |                
Torwali                                       | trw            |                |                
Torá                                          | trz            |                |                
Tosk Albanian                                 | als            |                |                
Totela                                        | ttl            |                |                
Toto                                          | txo            |                |                
Totoli                                        | txe            |                |                
Totomachapan Zapotec                          | zph            |                |                
Totontepec Mixe                               | mto            |                |                
Totoro                                        | ttk            |                |                
Touo                                          | tqu            |                |                
Toura (Côte d'Ivoire)                         | neb            |                |                
Toura (Papua New Guinea)                      | don            |                |                
Towei                                         | ttn            |                |                
Trans-New Guinea languages                    | ngf            |                |                
Transalpine Gaulish                           | xtg            |                |                
Traveller Danish                              | rmd            |                |                
Traveller Norwegian                           | rmg            |                |                
Traveller Scottish                            | trl            |                |                
Tregami                                       | trm            |                |                
Tremembé                                      | tme            |                |                
Trieng                                        | stg            |                |                
Trimuris                                      | tip            |                |                
Tring                                         | tgq            |                |                
Tringgus-Sembaan Bidayuh                      | trx            |                |                
Trinidad and Tobago Sign Language             | lst            |                |                
Trinidadian Creole English                    | trf            |                |                
Trinitario                                    | trn            |                |                
Trió                                          | tri            |                |                
Truká                                         | tka            |                |                
Trumai                                        | tpy            |                |                
Ts'ün-Lao                                     | tsl            |                |                
Tsaangi                                       | tsa            |                |                
Tsakhur                                       | tkr            |                |                
Tsakonian                                     | tsd            |                |                
Tsakwambo                                     | kvz            |                |                
Tsamai                                        | tsb            |                |                
Tsat                                          | huq            |                |                
Tseku                                         | tsk            |                |                
Tsetsaut                                      | txc            |                |                
Tshangla                                      | tsj            |                |                
Tsikimba                                      | kdl            |                |                
Tsimané                                       | cas            |                |                
Tsimihety Malagasy                            | xmw            |                |                
Tsimshian                                     | tsi            |                |                
Tsishingini                                   | tsw            |                |                
Tso                                           | ldp            |                |                
Tsoa                                          | hio            |                |                
Tsogo                                         | tsv            |                |                
Tsonga                                        | tso            | ts             |                
Tsotso                                        | lto            |                |                
Tsou                                          | tsu            |                |                
Tsucuba                                       | cbq            |                |                
Tsum                                          | ttz            |                |                
Tsuvadi                                       | tvd            |                |                
Tsuvan                                        | tsh            |                |                
Tswa                                          | tsc            |                |                
Tswana                                        | tsn            | tn             |                
Tswapong                                      | two            |                |                
Tu                                            | mjg            |                |                
Tuamotuan                                     | pmt            |                |                
Tubar                                         | tbu            |                |                
Tucano                                        | tuo            |                |                
Tugen                                         | tuy            |                |                
Tugun                                         | tzn            |                |                
Tugutil                                       | tuj            |                |                
Tukang Besi North                             | khc            |                |                
Tukang Besi South                             | bhq            |                |                
Tuki                                          | bag            |                |                
Tukpa                                         | tpq            |                |                
Tukudede                                      | tkd            |                |                
Tukumanféd                                    | tkf            |                |                
Tula                                          | tul            |                |                
Tulehu                                        | tlu            |                |                
Tulishi                                       | tey            |                |                
Tulu                                          | tcy            |                |                
Tulu-Bohuai                                   | rak            |                |                
Tuma-Irumu                                    | iou            |                |                
Tumak                                         | tmc            |                |                
Tumari Kanuri                                 | krt            |                |                
Tumbuka                                       | tum            |                |                
Tumi                                          | kku            |                |                
Tumleo                                        | tmq            |                |                
Tumshuqese                                    | xtq            |                |                
Tumtum                                        | tbr            |                |                
Tumulung Sisaala                              | sil            |                |                
Tumzabt                                       | mzb            |                |                
Tundra Enets                                  | enh            |                |                
Tunen                                         | baz            |                |                
Tunen                                         | tvu            |                |                
Tungag                                        | lcm            |                |                
Tunggare                                      | trt            |                |                
Tungus languages                              | tuw            |                |                
Tunia                                         | tug            |                |                
Tunica                                        | tun            |                |                
Tunisian Arabic                               | aeb            |                |                
Tunisian Sign Language                        | tse            |                |                
Tunjung                                       | tjg            |                |                
Tunni                                         | tqq            |                |                
Tunzu                                         | dza            |                |                
Tuotomb                                       | ttf            |                |                
Tuparí                                        | tpr            |                |                
Tupi languages                                | tup            |                |                
Tupinambá                                     | tpn            |                |                
Tupinikin                                     | tpk            |                |                
Tupuri                                        | tui            |                |                
Tupí                                          | tpw            |                |                
Turaka                                        | trh            |                |                
Turi                                          | trd            |                |                
Turiwára                                      | twt            |                |                
Turka                                         | tuz            |                |                
Turkana                                       | tuv            |                |                
Turkic languages                              | trk            |                |                
Turkish Sign Language                         | tsm            |                |                
Turkish                                       | tur            | tr             |                
Turkmen                                       | tuk            | tk             |                
Turks And Caicos Creole English               | tch            |                |                
Turoyo                                        | tru            |                |                
Turumsa                                       | tqm            |                |                
Turung                                        | try            |                |                
Tuscarora                                     | tus            |                |                
Tutelo                                        | tta            |                |                
Tutong                                        | ttg            |                |                
Tutsa Naga                                    | tvt            |                |                
Tutuba                                        | tmi            |                |                
Tututepec Mixtec                              | mtu            |                |                
Tututni                                       | tuu            |                |                
Tuvalu                                        | tvl            |                |                
Tuvinian                                      | tyv            |                |                
Tuwali Ifugao                                 | ifk            |                |                
Tuwari                                        | tww            |                |                
Tuwuli                                        | bov            |                |                
Tuxináwa                                      | tux            |                |                
Tuxá                                          | tud            |                |                
Tuyuca                                        | tue            |                |                
Twana                                         | twa            |                |                
Twendi                                        | twn            |                |                
Twents                                        | twd            |                |                
Twi                                           | twi            | tw             |                
Tyap                                          | kcg            |                |                
Tz'utujil                                     | tzj            |                |                
Tzeltal                                       | tzh            |                |                
Tzotzil                                       | tzo            |                |                
Tày Sa Pa                                     | tys            |                |                
Tày Tac                                       | tyt            |                |                
Tày                                           | tyz            |                |                
Téén                                          | lor            |                |                
Tübatulabal                                   | tub            |                |                
U                                             | uuu            |                |                
Uab Meto                                      | aoz            |                |                
Uamué                                         | uam            |                |                
Uare                                          | ksj            |                |                
Ubaghara                                      | byc            |                |                
Ubang                                         | uba            |                |                
Ubi                                           | ubi            |                |                
Ubir                                          | ubr            |                |                
Ubykh                                         | uby            |                |                
Ucayali-Yurúa Ashéninka                       | cpb            |                |                
Uda                                           | uda            |                |                
Udi                                           | udi            |                |                
Udihe                                         | ude            |                |                
Udmurt                                        | udm            |                |                
Uduk                                          | udu            |                |                
Ufim                                          | ufi            |                |                
Ugandan Sign Language                         | ugn            |                |                
Ugaritic                                      | uga            |                |                
Ughele                                        | uge            |                |                
Ugong                                         | ugo            |                |                
Uhami                                         | uha            |                |                
Uighur                                        | uig            | ug             |                
Uisai                                         | uis            |                |                
Ujir                                          | udj            |                |                
Ukaan                                         | kcf            |                |                
Ukhwejo                                       | ukh            |                |                
Ukit                                          | umi            |                |                
Ukpe-Bayobiri                                 | ukp            |                |                
Ukpet-Ehom                                    | akd            |                |                
Ukrainian Sign Language                       | ukl            |                |                
Ukrainian                                     | ukr            | uk             |                
Ukue                                          | uku            |                |                
Ukuriguma                                     | ukg            |                |                
Ukwa                                          | ukq            |                |                
Ukwuani-Aboh-Ndoni                            | ukw            |                |                
Ulau-Suain                                    | svb            |                |                
Ulch                                          | ulc            |                |                
Ulithian                                      | uli            |                |                
Ullatan                                       | ull            |                |                
Ulukwumi                                      | ulb            |                |                
Ulumanda'                                     | ulm            |                |                
Ulwa                                          | ulw            |                |                
Uma                                           | ppk            |                |                
Uma' Lasan                                    | xky            |                |                
Uma' Lung                                     | ulu            |                |                
Umanakaina                                    | gdn            |                |                
Umatilla                                      | uma            |                |                
Umbindhamu                                    | umd            |                |                
Umbrian                                       | xum            |                |                
Umbu-Ungu                                     | ubu            |                |                
Umbugarla                                     | umr            |                |                
Umbundu                                       | umb            |                |                
Ume Sami                                      | sju            |                |                
Umeda                                         | upi            |                |                
Umiida                                        | xud            |                |                
Umiray Dumaget Agta                           | due            |                |                
Umon                                          | umm            |                |                
Umotína                                       | umo            |                |                
Umpila                                        | ump            |                |                
Una                                           | mtg            |                |                
Unami                                         | unm            |                |                
Uncoded languages                             | mis            |                |                
Unde Kaili                                    | unz            |                |                
Undetermined                                  | und            |                |                
Uneapa                                        | bbn            |                |                
Uneme                                         | une            |                |                
Unggaranggu                                   | xun            |                |                
Unggumi                                       | xgu            |                |                
Uni                                           | uni            |                |                
Unserdeutsch                                  | uln            |                |                
Unua                                          | onu            |                |                
Unubahe                                       | unu            |                |                
Uokha                                         | uok            |                |                
Upper Chehalis                                | cjh            |                |                
Upper Grand Valley Dani                       | dna            |                |                
Upper Guinea Crioulo                          | pov            |                |                
Upper Kinabatangan                            | dmg            |                |                
Upper Kuskokwim                               | kuu            |                |                
Upper Necaxa Totonac                          | tku            |                |                
Upper Saxon                                   | sxu            |                |                
Upper Sorbian                                 | hsb            |                |                
Upper Ta'oih                                  | tth            |                |                
Upper Tanana                                  | tau            |                |                
Upper Tanudan Kalinga                         | kgh            |                |                
Upper Taromi                                  | tov            |                |                
Upper Umpqua                                  | xup            |                |                
Ura (Papua New Guinea)                        | uro            |                |                
Ura (Vanuatu)                                 | uur            |                |                
Uradhi                                        | urf            |                |                
Urak Lawoi'                                   | urk            |                |                
Urali                                         | url            |                |                
Uralic languages                              | urj            |                |                
Urapmin                                       | urm            |                |                
Urarina                                       | ura            |                |                
Urartian                                      | xur            |                |                
Urat                                          | urt            |                |                
Urdu                                          | urd            | ur             |                
Urhobo                                        | urh            |                |                
Uri                                           | uvh            |                |                
Urigina                                       | urg            |                |                
Urim                                          | uri            |                |                
Urimo                                         | urx            |                |                
Uripiv-Wala-Rano-Atchin                       | upv            |                |                
Urningangg                                    | urc            |                |                
Uru                                           | ure            |                |                
Uru-Eu-Wau-Wau                                | urz            |                |                
Uru-Pa-In                                     | urp            |                |                
Uruangnirin                                   | urn            |                |                
Uruava                                        | urv            |                |                
Urubú-Kaapor Sign Language                    | uks            |                |                
Urubú-Kaapor                                  | urb            |                |                
Uruguayan Sign Language                       | ugy            |                |                
Urum                                          | uum            |                |                
Urumi                                         | uru            |                |                
Usaghade                                      | usk            |                |                
Usan                                          | wnu            |                |                
Usarufa                                       | usa            |                |                
Ushojo                                        | ush            |                |                
Usila Chinantec                               | cuc            |                |                
Usku                                          | ulf            |                |                
Uspanteco                                     | usp            |                |                
Usui                                          | usi            |                |                
Utarmbung                                     | omo            |                |                
Ute-Southern Paiute                           | ute            |                |                
Uto-Aztecan languages                         | azc            |                |                
Utu                                           | utu            |                |                
Uvbie                                         | evh            |                |                
Uya                                           | usu            |                |                
Uyajitaya                                     | duk            |                |                
Uzbek                                         | uzb            | uz             |                
Uzbeki Arabic                                 | auz            |                |                
Uzekwe                                        | eze            |                |                
Vaagri Booli                                  | vaa            |                |                
Vafsi                                         | vaf            |                |                
Vaghat-Ya-Bijim-Legeri                        | bij            |                |                
Vaghri                                        | vgr            |                |                
Vaghua                                        | tva            |                |                
Vagla                                         | vag            |                |                
Vai                                           | vai            |                |                
Vaiphei                                       | vap            |                |                
Vale                                          | vae            |                |                
Valencian Sign Language                       | vsv            |                |                
Valle Nacional Chinantec                      | cvn            |                |                
Valley Maidu                                  | vmv            |                |                
Valman                                        | van            |                |                
Valpei                                        | vlp            |                |                
Vamale                                        | mkt            |                |                
Vame                                          | mlr            |                |                
Vandalic                                      | xvn            |                |                
Vangunu                                       | mpr            |                |                
Vanimo                                        | vam            |                |                
Vano                                          | vnk            |                |                
Vanuma                                        | vau            |                |                
Vao                                           | vao            |                |                
Varhadi-Nagpuri                               | vah            |                |                
Varisi                                        | vrs            |                |                
Varli                                         | vav            |                |                
Vasavi                                        | vas            |                |                
Veddah                                        | ved            |                |                
Vehes                                         | val            |                |                
Veluws                                        | vel            |                |                
Vemgo-Mabas                                   | vem            |                |                
Venda                                         | ven            | ve             |                
Venetian                                      | vec            |                |                
Venetic                                       | xve            |                |                
Venezuelan Sign Language                      | vsl            |                |                
Vengo                                         | bav            |                |                
Ventureño                                     | veo            |                |                
Veps                                          | vep            |                |                
Vera'a                                        | vra            |                |                
Vestinian                                     | xvs            |                |                
Vidunda                                       | vid            |                |                
Viemo                                         | vig            |                |                
Vietnamese                                    | vie            | vi             |                
Vilela                                        | vil            |                |                
Vili                                          | vif            |                |                
Villa Viciosa Agta                            | dyg            |                |                
Vincentian Creole English                     | svc            |                |                
Vinmavis                                      | vnm            |                |                
Vinza                                         | vin            |                |                
Virgin Islands Creole English                 | vic            |                |                
Vishavan                                      | vis            |                |                
Viti                                          | vit            |                |                
Vitou                                         | vto            |                |                
Vitu                                          | wiv            |                |                
Vlaams                                        | vls            |                |                
Vlaamse Gebarentaal                           | vgt            |                |                
Vlax Romani                                   | rmy            |                |                
Volapük                                       | vol            | vo             |                
Volscian                                      | xvo            |                |                
Vono                                          | kch            |                |                
Voro                                          | vor            |                |                
Votic                                         | vot            |                |                
Vumbu                                         | vum            |                |                
Vunapu                                        | vnp            |                |                
Vunjo                                         | vun            |                |                
Vurës                                         | msn            |                |                
Vute                                          | vut            |                |                
Vwanji                                        | wbi            |                |                
Võro                                          | vro            |                |                
Wa                                            | wbm            |                |                
Wa'ema                                        | wag            |                |                
Waama                                         | wwa            |                |                
Waamwang                                      | wmn            |                |                
Waata                                         | ssn            |                |                
Wab                                           | wab            |                |                
Wabo                                          | wbb            |                |                
Waboda                                        | kmx            |                |                
Waci Gbe                                      | wci            |                |                
Wadaginam                                     | wdg            |                |                
Waddar                                        | wbq            |                |                
Wadi Wadi                                     | xwd            |                |                
Wadikali                                      | wdk            |                |                
Wadiyara Koli                                 | kxp            |                |                
Wadjabangayi                                  | wdy            |                |                
Wadjiginy                                     | wdj            |                |                
Wadjigu                                       | wdu            |                |                
Wae Rana                                      | wrx            |                |                
Waffa                                         | waj            |                |                
Wagawaga                                      | wgb            |                |                
Wagawaga                                      | wgw            |                |                
Wagaya                                        | wga            |                |                
Wagdi                                         | wbr            |                |                
Wagi                                          | fad            |                |                
Wagiman                                       | waq            |                |                
Wahau Kayan                                   | whu            |                |                
Wahau Kenyah                                  | whk            |                |                
Wahgi                                         | wgi            |                |                
Waigali                                       | wbk            |                |                
Waigeo                                        | wgo            |                |                
Wailaki                                       | wlk            |                |                
Wailapa                                       | wlr            |                |                
Waima                                         | rro            |                |                
Waima'a                                       | wmh            |                |                
Waimaha                                       | bao            |                |                
Waimiri-Atroari                               | atr            |                |                
Waioli                                        | wli            |                |                
Waiwai                                        | waw            |                |                
Waja                                          | wja            |                |                
Wajarri                                       | wbv            |                |                
Wajuk                                         | xwj            |                |                
Waka                                          | wav            |                |                
Wakabunga                                     | wwb            |                |                
Wakashan languages                            | wak            |                |                
Wakawaka                                      | wkw            |                |                
Wakde                                         | wkd            |                |                
Wakhi                                         | wbl            |                |                
Wakoná                                        | waf            |                |                
Wala                                          | lgl            |                |                
Walak                                         | wlw            |                |                
Walangama                                     | nlw            |                |                
Wali (Ghana)                                  | wlx            |                |                
Wali (Sudan)                                  | wll            |                |                
Waling                                        | wly            |                |                
Walio                                         | wla            |                |                
Walla Walla                                   | waa            |                |                
Wallisian                                     | wls            |                |                
Walloon                                       | wln            | wa             |                
Walmajarri                                    | wmt            |                |                
Walo Kumbe Dogon                              | dwl            |                |                
Walser                                        | wae            |                |                
Walungge                                      | ola            |                |                
Waluwarra                                     | wrb            |                |                
Wamas                                         | wmc            |                |                
Wambaya                                       | wmb            |                |                
Wambon                                        | wms            |                |                
Wambule                                       | wme            |                |                
Wamesa                                        | wad            |                |                
Wamey                                         | cou            |                |                
Wamin                                         | wmi            |                |                
Wampanoag                                     | wam            |                |                
Wampar                                        | lbq            |                |                
Wampur                                        | waz            |                |                
Wan                                           | wan            |                |                
Wanambre                                      | wnb            |                |                
Wanap                                         | wnp            |                |                
Wancho Naga                                   | nnp            |                |                
Wanda                                         | wbh            |                |                
Wandala                                       | mfi            |                |                
Wandarang                                     | wnd            |                |                
Wandji                                        | wdd            |                |                
Waneci                                        | wne            |                |                
Wanga                                         | lwg            |                |                
Wangaaybuwan-Ngiyambaa                        | wyb            |                |                
Wanggamala                                    | wnm            |                |                
Wanggom                                       | wng            |                |                
Wangkangurru                                  | wgg            |                |                
Wangkayutyuru                                 | wky            |                |                
Wangkumara                                    | xwk            |                |                
Wannu                                         | jub            |                |                
Wano                                          | wno            |                |                
Wantoat                                       | wnc            |                |                
Wanukaka                                      | wnk            |                |                
Wanyi                                         | wny            |                |                
Wané                                          | hwa            |                |                
Waorani                                       | auc            |                |                
Wapan                                         | juk            |                |                
Wapishana                                     | wap            |                |                
Wappo                                         | wao            |                |                
War-Jaintia                                   | aml            |                |                
Wara                                          | wbf            |                |                
Warao                                         | wba            |                |                
Warapu                                        | wra            |                |                
Waray (Australia)                             | wrz            |                |                
Waray (Philippines)                           | war            |                |                
Wardaman                                      | wrr            |                |                
Wardandi                                      | wxw            |                |                
Warduji                                       | wrd            |                |                
Warembori                                     | wsa            |                |                
Wares                                         | wai            |                |                
Waris                                         | wrs            |                |                
Waritai                                       | wbe            |                |                
Wariyangga                                    | wri            |                |                
Warji                                         | wji            |                |                
Warkay-Bipim                                  | bgv            |                |                
Warlmanpa                                     | wrl            |                |                
Warlpiri                                      | wbp            |                |                
Warnang                                       | wrn            |                |                
Warnman                                       | wbt            |                |                
Waropen                                       | wrp            |                |                
Warrgamay                                     | wgy            |                |                
Warrwa                                        | wwr            |                |                
Waru                                          | wru            |                |                
Warumungu                                     | wrm            |                |                
Waruna                                        | wrv            |                |                
Warungu                                       | wrg            |                |                
Warwar Feni                                   | hrw            |                |                
Wasa                                          | wss            |                |                
Wasco-Wishram                                 | wac            |                |                
Wasembo                                       | gsp            |                |                
Washo                                         | was            |                |                
Waskia                                        | wsk            |                |                
Wasu                                          | wsu            |                |                
Watakataui                                    | wtk            |                |                
Watam                                         | wax            |                |                
Wathawurrung                                  | wth            |                |                
Watiwa                                        | wtf            |                |                
Watubela                                      | wah            |                |                
Waube                                         | kop            |                |                
Waurá                                         | wau            |                |                
Wauyai                                        | wuy            |                |                
Wawa                                          | www            |                |                
Wawonii                                       | wow            |                |                
Waxianghua                                    | wxa            |                |                
Wayampi                                       | oym            |                |                
Wayana                                        | way            |                |                
Wayanad Chetti                                | ctt            |                |                
Wayoró                                        | wyr            |                |                
Wayu                                          | vay            |                |                
Wayuu                                         | guc            |                |                
Wedau                                         | wed            |                |                
Weh                                           | weh            |                |                
Wejewa                                        | wew            |                |                
Welaun                                        | wlh            |                |                
Weliki                                        | klh            |                |                
Welsh Romani                                  | rmw            |                |                
Welsh                                         | wel            | cy             | cym            
Wemale                                        | weo            |                |                
Wemba Wemba                                   | xww            |                |                
Weme Gbe                                      | wem            |                |                
Wendat                                        | wdt            |                |                
Wergaia                                       | weg            |                |                
Weri                                          | wer            |                |                
Wersing                                       | kvw            |                |                
West Albay Bikol                              | fbl            |                |                
West Ambae                                    | nnd            |                |                
West Bengal Sign Language                     | wbs            |                |                
West Berawan                                  | zbw            |                |                
West Central Banda                            | bbp            |                |                
West Central Oromo                            | gaz            |                |                
West Coast Bajau                              | bdr            |                |                
West Damar                                    | drn            |                |                
West Germanic languages                       | gmw            |                |                
West Goodenough                               | ddi            |                |                
West Kewa                                     | kew            |                |                
West Lembata                                  | lmj            |                |                
West Makian                                   | mqs            |                |                
West Masela                                   | mss            |                |                
West Slavic languages                         | zlw            |                |                
West Tarangan                                 | txn            |                |                
West Uvean                                    | uve            |                |                
West Yugur                                    | ybe            |                |                
West-Central Limba                            | lia            |                |                
Western Abnaki                                | abe            |                |                
Western Apache                                | apw            |                |                
Western Armenian                              | hyw            |                |                
Western Arrarnta                              | are            |                |                
Western Balochi                               | bgn            |                |                
Western Bolivian Guaraní                      | gnw            |                |                
Western Bru                                   | brv            |                |                
Western Bukidnon Manobo                       | mbb            |                |                
Western Cham                                  | cja            |                |                
Western Dani                                  | dnw            |                |                
Western Durango Nahuatl                       | azn            |                |                
Western Fijian                                | wyy            |                |                
Western Frisian                               | fry            | fy             |                
Western Highland Chatino                      | ctp            |                |                
Western Highland Purepecha                    | pua            |                |                
Western Huasteca Nahuatl                      | nhw            |                |                
Western Juxtlahuaca Mixtec                    | jmx            |                |                
Western Kanjobal                              | knj            |                |                
Western Karaboro                              | kza            |                |                
Western Katu                                  | kuf            |                |                
Western Kayah                                 | kyu            |                |                
Western Keres                                 | kjq            |                |                
Western Krahn                                 | krw            |                |                
Western Lalu                                  | ywl            |                |                
Western Lawa                                  | lcp            |                |                
Western Magar                                 | mrd            |                |                
Western Malayo-Polynesian languages           | pqw            |                |                
Western Maninkakan                            | mlq            |                |                
Western Mari                                  | mrj            |                |                
Western Mashan Hmong                          | hmw            |                |                
Western Meohang                               | raf            |                |                
Western Minyag                                | wmg            |                |                
Western Muria                                 | mut            |                |                
Western Neo-Aramaic                           | amw            |                |                
Western Niger Fulfulde                        | fuh            |                |                
Western Ojibwa                                | ojw            |                |                
Western Panjabi                               | pnb            |                |                
Western Parbate Kham                          | kjl            |                |                
Western Penan                                 | pne            |                |                
Western Sisaala                               | ssl            |                |                
Western Subanon                               | suc            |                |                
Western Tamang                                | tdg            |                |                
Western Tawbuid                               | twb            |                |                
Western Tlacolula Valley Zapotec              | zab            |                |                
Western Totonac                               | tqt            |                |                
Western Tunebo                                | tnb            |                |                
Western Xiangxi Miao                          | mmr            |                |                
Western Xwla Gbe                              | xwl            |                |                
Western Yiddish                               | yih            |                |                
Westphalien                                   | wep            |                |                
Wetamut                                       | wwo            |                |                
Wewaw                                         | wea            |                |                
Weyto                                         | woy            |                |                
White Gelao                                   | giw            |                |                
White Lachi                                   | lwh            |                |                
Whitesands                                    | tnp            |                |                
Wiarumus                                      | tua            |                |                
Wichita                                       | wic            |                |                
Wichí Lhamtés Güisnay                         | mzh            |                |                
Wichí Lhamtés Nocten                          | mtp            |                |                
Wichí Lhamtés Vejoz                           | wlv            |                |                
Wik Ngathan                                   | wig            |                |                
Wik-Epa                                       | wie            |                |                
Wik-Iiyanh                                    | wij            |                |                
Wik-Keyangan                                  | wif            |                |                
Wik-Me'anha                                   | wih            |                |                
Wik-Mungkan                                   | wim            |                |                
Wikalkan                                      | wik            |                |                
Wikngenchera                                  | wua            |                |                
Wilawila                                      | wil            |                |                
Wintu                                         | wit            |                |                
Wintu                                         | wnw            |                |                
Winyé                                         | kst            |                |                
Wipi                                          | gdr            |                |                
Wiradjuri                                     | wrh            |                |                
Wiraféd                                       | wir            |                |                
Wirangu                                       | wgu            |                |                
Wirangu                                       | wiw            |                |                
Wiru                                          | wiu            |                |                
Wiyot                                         | wiy            |                |                
Woccon                                        | xwc            |                |                
Wogamusin                                     | wog            |                |                
Wogeo                                         | woc            |                |                
Woi                                           | wbw            |                |                
Woiwurrung                                    | wyi            |                |                
Wojenaka                                      | jod            |                |                
Wolane                                        | wle            |                |                
Wolani                                        | wod            |                |                
Wolaytta                                      | wal            |                |                
Woleaian                                      | woe            |                |                
Wolio                                         | wlo            |                |                
Wolof                                         | wol            | wo             |                
Wom (Nigeria)                                 | wom            |                |                
Wom (Papua New Guinea)                        | wmo            |                |                
Womo                                          | wmx            |                |                
Wongo                                         | won            |                |                
Woods Cree                                    | cwd            |                |                
Woria                                         | wor            |                |                
Worimi                                        | kda            |                |                
Worodougou                                    | jud            |                |                
Worora                                        | unp            |                |                
Worrorra                                      | wro            |                |                
Wotapuri-Katarqalai                           | wsv            |                |                
Wotjobaluk                                    | xwt            |                |                
Wotu                                          | wtw            |                |                
Woun Meu                                      | noa            |                |                
Written Oirat                                 | xwo            |                |                
Wu Chinese                                    | wuu            |                |                
Wuding-Luquan Yi                              | ywq            |                |                
Wudu                                          | wud            |                |                
Wuliwuli                                      | wlu            |                |                
Wulna                                         | wux            |                |                
Wumboko                                       | bqm            |                |                
Wumbvu                                        | wum            |                |                
Wumeng Nasu                                   | ywu            |                |                
Wunai Bunu                                    | bwn            |                |                
Wunambal                                      | wub            |                |                
Wunumara                                      | wnn            |                |                
Wurrugu                                       | wur            |                |                
Wusa Nasu                                     | yig            |                |                
Wushi                                         | bse            |                |                
Wusi                                          | wsi            |                |                
Wutung                                        | wut            |                |                
Wutunhua                                      | wuh            |                |                
Wuvulu-Aua                                    | wuv            |                |                
Wuzlam                                        | udl            |                |                
Wyandot                                       | wya            |                |                
Wyandot                                       | wyn            |                |                
Wymysorys                                     | wym            |                |                
Wára                                          | tci            |                |                
Wãpha                                         | juw            |                |                
Wè Northern                                   | wob            |                |                
Wè Southern                                   | gxx            |                |                
Wè Western                                    | wec            |                |                
Xaasongaxango                                 | kao            |                |                
Xadani Zapotec                                | zax            |                |                
Xakriabá                                      | xkr            |                |                
Xamtanga                                      | xan            |                |                
Xanaguía Zapotec                              | ztg            |                |                
Xavánte                                       | xav            |                |                
Xerénte                                       | xer            |                |                
Xetá                                          | xet            |                |                
Xhosa                                         | xho            | xh             |                
Xiandao                                       | xia            |                |                
Xiang Chinese                                 | hsn            |                |                
Xibe                                          | sjo            |                |                
Xicotepec De Juárez Totonac                   | too            |                |                
Xinca                                         | xin            |                |                
Xingú Asuriní                                 | asn            |                |                
Xipaya                                        | xiy            |                |                
Xipináwa                                      | xip            |                |                
Xiri                                          | xii            |                |                
Xiriâna                                       | xir            |                |                
Xishanba Lalo                                 | ywt            |                |                
Xokleng                                       | xok            |                |                
Xukurú                                        | xoo            |                |                
Xwela Gbe                                     | xwe            |                |                
Xârâcùù                                       | ane            |                |                
Xârâgurè                                      | axx            |                |                
Yaaku                                         | muu            |                |                
Yabarana                                      | yar            |                |                
Yabaâna                                       | ybn            |                |                
Yabem                                         | jae            |                |                
Yaben                                         | ybm            |                |                
Yabong                                        | ybo            |                |                
Yabula Yabula                                 | yxy            |                |                
Yace                                          | ekr            |                |                
Yaeyama                                       | rys            |                |                
Yafi                                          | wfg            |                |                
Yagara                                        | yxg            |                |                
Yagaria                                       | ygr            |                |                
Yagnobi                                       | yai            |                |                
Yagomi                                        | ygm            |                |                
Yagua                                         | yad            |                |                
Yagwoia                                       | ygw            |                |                
Yahadian                                      | ner            |                |                
Yahang                                        | rhp            |                |                
Yahuna                                        | ynu            |                |                
Yaka (Central African Republic)               | axk            |                |                
Yaka (Congo)                                  | iyx            |                |                
Yaka (Democratic Republic of Congo)           | yaf            |                |                
Yakaikeke                                     | ykk            |                |                
Yakama                                        | yak            |                |                
Yakan                                         | yka            |                |                
Yakha                                         | ybh            |                |                
Yakoma                                        | yky            |                |                
Yakut                                         | sah            |                |                
Yala                                          | yba            |                |                
Yalahatan                                     | jal            |                |                
Yalakalore                                    | xyl            |                |                
Yalarnnga                                     | ylr            |                |                
Yale                                          | nce            |                |                
Yaleba                                        | ylb            |                |                
Yalunka                                       | yal            |                |                
Yalálag Zapotec                               | zpu            |                |                
Yamap                                         | ymp            |                |                
Yamba                                         | yam            |                |                
Yambes                                        | ymb            |                |                
Yambeta                                       | yat            |                |                
Yamdena                                       | jmd            |                |                
Yameo                                         | yme            |                |                
Yami                                          | tao            |                |                
Yaminahua                                     | yaa            |                |                
Yamna                                         | ymn            |                |                
Yamongeri                                     | ymg            |                |                
Yamphe                                        | yma            |                |                
Yamphu                                        | ybi            |                |                
Yan-nhangu                                    | jay            |                |                
Yan-nhaŋu Sign Language                       | yhs            |                |                
Yana                                          | ynn            |                |                
Yanahuanca Pasco Quechua                      | qur            |                |                
Yanda Dom Dogon                               | dym            |                |                
Yanda                                         | yda            |                |                
Yandjibara                                    | xyb            |                |                
Yandruwandha                                  | ynd            |                |                
Yanesha'                                      | ame            |                |                
Yang Zhuang                                   | zyg            |                |                
Yangben                                       | yav            |                |                
Yangbye                                       | ybd            |                |                
Yangho                                        | ynh            |                |                
Yangkam                                       | bsx            |                |                
Yangman                                       | jng            |                |                
Yango                                         | yng            |                |                
Yangulam                                      | ynl            |                |                
Yangum Dey                                    | yde            |                |                
Yangum Gel                                    | ygl            |                |                
Yangum Mon                                    | ymo            |                |                
Yankunytjatjara                               | kdd            |                |                
Yanomamö                                      | guu            |                |                
Yanomámi                                      | wca            |                |                
Yansi                                         | yns            |                |                
Yanyuwa                                       | jao            |                |                
Yao                                           | yao            |                |                
Yaosakor Asmat                                | asy            |                |                
Yaouré                                        | yre            |                |                
Yapese                                        | yap            |                |                
Yapunda                                       | yev            |                |                
Yaqay                                         | jaq            |                |                
Yaqui                                         | yaq            |                |                
Yarawata                                      | yrw            |                |                
Yardliyawarra                                 | yxl            |                |                
Yareba                                        | yrb            |                |                
Yareni Zapotec                                | zae            |                |                
Yarluyandi                                    | yry            |                |                
Yaroamë                                       | yro            |                |                
Yarsun                                        | yrs            |                |                
Yarí                                          | yri            |                |                
Yasa                                          | yko            |                |                
Yassic                                        | ysc            |                |                
Yatay                                         | yty            |                |                
Yatee Zapotec                                 | zty            |                |                
Yatzachi Zapotec                              | zav            |                |                
Yau (Morobe Province)                         | yuw            |                |                
Yau (Sandaun Province)                        | yyu            |                |                
Yaul                                          | yla            |                |                
Yauma                                         | yax            |                |                
Yaur                                          | jau            |                |                
Yautepec Zapotec                              | zpb            |                |                
Yauyos Quechua                                | qux            |                |                
Yavitero                                      | yvt            |                |                
Yawa                                          | yva            |                |                
Yawalapití                                    | yaw            |                |                
Yawanawa                                      | ywn            |                |                
Yawarawarga                                   | yww            |                |                
Yaweyuha                                      | yby            |                |                
Yawijibaya                                    | jbw            |                |                
Yawiyo                                        | ybx            |                |                
Yawuru                                        | ywr            |                |                
Yaygir                                        | xya            |                |                
Yazgulyam                                     | yah            |                |                
Yecuatla Totonac                              | tlc            |                |                
Yei                                           | jei            |                |                
Yekhee                                        | ets            |                |                
Yekora                                        | ykr            |                |                
Yela                                          | yel            |                |                
Yele                                          | yle            |                |                
Yelmek                                        | jel            |                |                
Yelogu                                        | ylg            |                |                
Yemba                                         | ybb            |                |                
Yemsa                                         | jnj            |                |                
Yendang                                       | yen            |                |                
Yendang                                       | ynq            |                |                
Yeni                                          | yei            |                |                
Yeniche                                       | yec            |                |                
Yerakai                                       | yra            |                |                
Yeretuar                                      | gop            |                |                
Yerong                                        | yrn            |                |                
Yerukula                                      | yeu            |                |                
Yessan-Mayo                                   | yss            |                |                
Yetfa                                         | yet            |                |                
Yevanic                                       | yej            |                |                
Yeyi                                          | yey            |                |                
Yiddish Sign Language                         | yds            |                |                
Yiddish                                       | yid            | yi             |                
Yidgha                                        | ydg            |                |                
Yidiny                                        | yii            |                |                
Yil                                           | yll            |                |                
Yimas                                         | yee            |                |                
Yimchungru Naga                               | yim            |                |                
Yinbaw Karen                                  | kvu            |                |                
Yindjibarndi                                  | yij            |                |                
Yindjilandji                                  | yil            |                |                
Yine                                          | pib            |                |                
Yinggarda                                     | yia            |                |                
Yinhawangka                                   | ywg            |                |                
Yiningayi                                     | ygi            |                |                
Yintale Karen                                 | kvy            |                |                
Yinwum                                        | yxm            |                |                
Yir Yoront                                    | yiy            |                |                
Yir Yoront                                    | yyr            |                |                
Yirandali                                     | ljw            |                |                
Yirrk-Mel                                     | yrm            |                |                
Yis                                           | yis            |                |                
Yitha Yitha                                   | xth            |                |                
Yoba                                          | yob            |                |                
Yocoboué Dida                                 | gud            |                |                
Yogad                                         | yog            |                |                
Yoidik                                        | ydk            |                |                
Yoke                                          | yki            |                |                
Yokuts                                        | yok            |                |                
Yola                                          | yol            |                |                
Yoloxochitl Mixtec                            | xty            |                |                
Yolŋu Sign Language                           | ygs            |                |                
Yom                                           | pil            |                |                
Yombe                                         | yom            |                |                
Yonaguni                                      | yoi            |                |                
Yong                                          | yno            |                |                
Yongbei Zhuang                                | zyb            |                |                
Yongkom                                       | yon            |                |                
Yongnan Zhuang                                | zyn            |                |                
Yopno                                         | yut            |                |                
Yora                                          | mts            |                |                
Yoron                                         | yox            |                |                
Yorta Yorta                                   | xyy            |                |                
Yoruba                                        | yor            | yo             |                
Yos                                           | yos            |                |                
Yosondúa Mixtec                               | mpm            |                |                
Yotti                                         | yot            |                |                
Youjiang Zhuang                               | zyj            |                |                
Youle Jinuo                                   | jiu            |                |                
Younuo Bunu                                   | buh            |                |                
Yout Wam                                      | ytw            |                |                
Yoy                                           | yoy            |                |                
Yuanga                                        | nua            |                |                
Yucatec Maya Sign Language                    | msd            |                |                
Yucateco                                      | yua            |                |                
Yuchi                                         | yuc            |                |                
Yucuañe Mixtec                                | mvg            |                |                
Yucuna                                        | ycn            |                |                
Yue Chinese                                   | yue            |                |                
Yug                                           | yug            |                |                
Yugambal                                      | yub            |                |                
Yugh                                          | yuu            |                |                
Yugoslavian Sign Language                     | ysl            |                |                
Yugul                                         | ygu            |                |                
Yuhup                                         | yab            |                |                
Yuki                                          | yuk            |                |                
Yukpa                                         | yup            |                |                
Yukuben                                       | ybl            |                |                
Yulu                                          | yul            |                |                
Yupik languages                               | ypk            |                |                
Yuqui                                         | yuq            |                |                
Yuracare                                      | yuz            |                |                
Yurats                                        | rts            |                |                
Yurok                                         | yur            |                |                
Yuru                                          | ljx            |                |                
Yurutí                                        | yui            |                |                
Yutanduchi Mixtec                             | mab            |                |                
Yuwana                                        | yau            |                |                
Yuyu                                          | yxu            |                |                
Ywom                                          | gek            |                |                
Yámana                                        | yag            |                |                
Zaachila Zapotec                              | ztx            |                |                
Zabana                                        | kji            |                |                
Zacatepec Chatino                             | ctz            |                |                
Zacatlán-Ahuacatlán-Tepetzintla Nahuatl       | nhi            |                |                
Zaghawa                                       | zag            |                |                
Zaiwa                                         | atb            |                |                
Zakhring                                      | zkr            |                |                
Zambian Sign Language                         | zsl            |                |                
Zan Gula                                      | zna            |                |                
Zanaki                                        | zak            |                |                
Zande (individual language)                   | zne            |                |                
Zande languages                               | znd            |                |                
Zangskari                                     | zau            |                |                
Zangwal                                       | zah            |                |                
Zaniza Zapotec                                | zpw            |                |                
Zapotec                                       | zap            |                |                
Zaramo                                        | zaj            |                |                
Zari                                          | zaz            |                |                
Zarma                                         | dje            |                |                
Zarphatic                                     | zrp            |                |                
Zauzou                                        | zal            |                |                
Zay                                           | zwa            |                |                
Zayein Karen                                  | kxk            |                |                
Zayse-Zergulla                                | zay            |                |                
Zaza                                          | zza            |                |                
Zazao                                         | jaj            |                |                
Zeem                                          | zua            |                |                
Zeeuws                                        | zea            |                |                
Zemba                                         | dhm            |                |                
Zeme Naga                                     | nzm            |                |                
Zemgalian                                     | xzm            |                |                
Zenag                                         | zeg            |                |                
Zenaga                                        | zen            |                |                
Zenzontepec Chatino                           | czn            |                |                
Zerenkel                                      | zrn            |                |                
Zhaba                                         | zhb            |                |                
Zhang-Zhung                                   | xzh            |                |                
Zhire                                         | zhi            |                |                
Zhoa                                          | zhw            |                |                
Zhuang                                        | zha            | za             |                
Zia                                           | zia            |                |                
Zialo                                         | zil            |                |                
Zigula                                        | ziw            |                |                
Zimakani                                      | zik            |                |                
Zimba                                         | zmb            |                |                
Zimbabwe Sign Language                        | zib            |                |                
Zinza                                         | zin            |                |                
Zire                                          | sih            |                |                
Ziriya                                        | zir            |                |                
Zizilivakan                                   | ziz            |                |                
Zo'é                                          | pto            |                |                
Zokhuo                                        | yzk            |                |                
Zoogocho Zapotec                              | zpq            |                |                
Zoroastrian Dari                              | gbz            |                |                
Zotung Chin                                   | czt            |                |                
Zou                                           | zom            |                |                
Zula                                          | zla            |                |                
Zulgo-Gemzek                                  | gnd            |                |                
Zulu                                          | zul            | zu             |                
Zumaya                                        | zuy            |                |                
Zumbun                                        | jmb            |                |                
Zuni                                          | zun            |                |                
Zuojiang Zhuang                               | zzj            |                |                
Zyphe Chin                                    | zyp            |                |                
Záparo                                        | zro            |                |                
sTodsde                                       | jih            |                |                
us-Saare                                      | uss            |                |                
ut-Hun                                        | uth            |                |                
ut-Ma'in                                      | gel            |                |                
Àhàn                                          | ahn            |                |                
Áncá                                          | acb            |                |                
Ömie                                          | aom            |                |                
Önge                                          | oon            |                |                
ǀGwi                                          | gwj            |                |                
ǀXam                                          | xam            |                |                
ǁAni                                          | hnh            |                |                
ǁGana                                         | gnk            |                |                
ǁXegwi                                        | xeg            |                |                
ǂHua                                          | huc            |                |                
ǂKxʼauǁʼein                                   | aue            |                |                
ǂUngkue                                       | gku            |                |                
ǃOǃung                                        | oun            |                |                
ǃXóõ                                          | nmn            |                |                
"#;
