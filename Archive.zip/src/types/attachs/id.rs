use crate::types::RangeU32;
use std::str::FromStr;

#[derive(Clone, Eq, Hash, PartialEq)]
pub enum AttachID {
    U32(u32),
    RangeU32(RangeU32),
}

impl FromStr for AttachID {
    type Err = String;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let s = s.trim();

        if let Ok(n) = s.parse::<u32>() {
            Ok(Self::U32(n))
        } else if let Ok(rng) = RangeU32::from_str(s) {
            Ok(Self::RangeU32(rng))
        } else {
            Err(format!(
                "Invalid attach ID '{}' (must be num or range (n-m) of num)",
                s
            ))
        }
    }
}
