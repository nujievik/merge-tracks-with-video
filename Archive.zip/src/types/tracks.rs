mod base;
pub mod flags;
pub(super) mod from_arg_matches;
mod id;
mod names;

use id::TrackID;
use std::collections::{HashMap, HashSet};

#[derive(Clone)]
pub struct Tracks {
    pub audio: BaseTracksFields,
    pub subs: BaseTracksFields,
    pub video: BaseTracksFields,
    pub buttons: BaseTracksFields,
    pub flags: TracksFlags,
}

#[derive(Clone)]
pub struct BaseTracksFields {
    pub no_flag: bool,
    pub inverse: bool,
    pub ids: Option<HashSet<TrackID>>,
}

#[derive(Clone)]
pub struct TracksFlags {
    pub defaults: BaseTracksFlagsFields,
    pub forceds: BaseTracksFlagsFields,
    pub enableds: BaseTracksFlagsFields,
}

#[derive(Clone)]
pub struct BaseTracksFlagsFields {
    pub add: Option<bool>,
    pub lim_true: u32,
    pub unmapped: Option<bool>,
    pub map: Option<HashMap<TrackID, bool>>,
}
