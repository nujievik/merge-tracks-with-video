mod global;
mod io;
mod other;
mod target;
mod val_parsers;

use super::AppConfig;
use crate::types::retiming::{Retiming, RetimingArg};
use crate::types::tracks::TracksFlags;
use crate::types::tracks::flags::from_arg_matches::TracksFlagsArg;
use crate::types::traits::ClapArgID;
use clap::{Arg, ArgAction, Command, builder::ValueParser};
use val_parsers::patterns_parser;

impl clap::CommandFactory for AppConfig {
    fn command() -> Command {
        Blocks::new()
            .io()
            .global()
            .inverse()
            .retiming()
            .target()
            .other()
            .version()
            .help()
            .unwrap()
    }

    fn command_for_update() -> Command {
        Self::command()
    }
}

struct Blocks {
    cmd: Command,
}

impl Blocks {
    pub fn new() -> Self {
        Self {
            cmd: Command::new(env!("CARGO_PKG_NAME"))
                .no_binary_name(true)
                .version(concat!("v", env!("CARGO_PKG_VERSION")))
                .disable_help_flag(true)
                .disable_version_flag(true)
                .override_usage(concat!(env!("CARGO_PKG_NAME"), " [options]")),
        }
    }

    pub fn unwrap(self) -> Command {
        self.cmd
    }

    pub fn inverse(mut self) -> Self {
        let mut cmd = self.cmd.next_help_heading("Inverse on Pro");

        for help in TracksFlagsArg::iter_help() {
            let add = help.help_to_add();
            let add_str = TracksFlags::as_str(add);
            let no_add = help.help_to_no_add();

            cmd = cmd
                .arg(
                    Arg::new(TracksFlags::as_str(help))
                        .long(help.long())
                        .help(help.help())
                        .action(ArgAction::SetTrue),
                )
                .arg(
                    Arg::new(add_str)
                        .long(add.long())
                        .action(ArgAction::SetTrue)
                        .hide(true),
                )
                .arg(
                    Arg::new(TracksFlags::as_str(no_add))
                        .long(no_add.long())
                        .action(ArgAction::SetTrue)
                        .hide(true)
                        .conflicts_with(add_str),
                );
        }

        self.cmd = cmd;
        self
    }

    pub fn retiming(mut self) -> Self {
        self.cmd = self
            .cmd
            .next_help_heading("Retiming options")
            .arg(
                Arg::new(Retiming::as_str(RetimingArg::RmSegments))
                    .long("rm-segments")
                    .alias("remove-segments")
                    .value_name("n[,m]...")
                    .help("Remove segments with name patterns")
                    .value_parser(ValueParser::new(patterns_parser)),
            )
            .arg(
                Arg::new(Retiming::as_str(RetimingArg::NoLinked))
                    .long("no-linked")
                    .help("Remove linked segments")
                    .action(ArgAction::SetTrue),
            )
            .arg(
                Arg::new(Retiming::as_str(RetimingArg::Less))
                    .long("less-retiming")
                    .help("No retiming if linked segments outside main")
                    .action(ArgAction::SetTrue),
            );

        self
    }
}
