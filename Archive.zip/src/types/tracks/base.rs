use super::{BaseTracksFields, id::TrackID};
use std::collections::HashSet;
use std::str::FromStr;

impl BaseTracksFields {
    pub fn new() -> Self {
        Self {
            no_flag: Self::default_no_flag(),
            inverse: false,
            ids: None,
        }
    }

    pub fn default_no_flag() -> bool {
        false
    }

    pub fn no_flag(mut self, no_flag: bool) -> Self {
        self.no_flag = no_flag;
        self
    }

    pub fn inverse(mut self, inverse: bool) -> Self {
        self.inverse = inverse;
        self
    }

    fn ids(mut self, ids: Option<HashSet<TrackID>>) -> Self {
        self.ids = ids;
        self
    }
}

impl FromStr for BaseTracksFields {
    type Err = String;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let s = s.trim();

        let (inverse, s) = if s.starts_with('!') {
            (true, &s[1..])
        } else {
            (false, s)
        };

        let ids: Result<HashSet<_>, _> = s
            .split(',')
            .map(str::trim)
            .filter(|s| !s.is_empty())
            .map(TrackID::from_str)
            .collect();

        let ids = ids?;

        if ids.is_empty() {
            return Err("Not found any track ID".to_string());
        }

        Ok(Self::new().inverse(inverse).ids(Some(ids)))
    }
}
