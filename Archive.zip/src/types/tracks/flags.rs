pub(in crate::types) mod from_arg_matches;

use super::{BaseTracksFlagsFields, TracksFlags, id::TrackID};
use std::collections::HashMap;
use std::str::FromStr;

impl TracksFlags {
    fn default_lim_true_defaults() -> u32 {
        1
    }

    fn default_lim_true_forceds() -> u32 {
        0
    }

    fn default_lim_true_enableds() -> u32 {
        u32::MAX
    }
}

impl BaseTracksFlagsFields {
    pub fn new() -> Self {
        Self {
            add: None,
            lim_true: 0,
            unmapped: None,
            map: None,
        }
    }

    pub fn add(mut self, add: Option<bool>) -> Self {
        self.add = add;
        self
    }

    fn lim_true(mut self, lim: u32) -> Self {
        self.lim_true = lim;
        self
    }

    fn unmapped(mut self, b: Option<bool>) -> Self {
        self.unmapped = b;
        self
    }

    fn map(mut self, map: Option<HashMap<TrackID, bool>>) -> Self {
        self.map = map;
        self
    }

    fn parse_bool(s: &str) -> Result<bool, String> {
        match s.trim().to_ascii_lowercase().as_str() {
            "1" | "true" | "on" => Ok(true),
            "0" | "false" | "off" => Ok(false),
            _ => Err(format!("Invalid bool key '{}'", s)),
        }
    }
}

impl FromStr for BaseTracksFlagsFields {
    type Err = String;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        if let Ok(b) = Self::parse_bool(s) {
            return Ok(Self::new().unmapped(Some(b)));
        }

        let map: Result<HashMap<TrackID, bool>, _> = s
            .split(',')
            .map(str::trim)
            .filter(|s| !s.is_empty())
            .map(|s| {
                let (id, b) = s.rsplit_once(':').unwrap_or((s, "true"));
                let id = TrackID::from_str(id);
                let b = Self::parse_bool(b);
                id.and_then(|id| b.map(|b| (id, b)))
            })
            .collect();

        let map = map?;

        Ok(Self::new().map(Some(map)))
    }
}
