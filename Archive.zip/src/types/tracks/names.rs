/*
use super::id::TrackID;
use std::collections::HashMap;
use std::str::FromStr;

pub struct TrackNames {
    add: bool,
    unmapped: Option<String>,
    map: HashMap<TrackID, String>,
}

impl TrackNames {
    pub fn new() -> Self {
        Self {
            add: true,
            unmapped: None,
            map: HashMap::new(),
        }
    }

    pub fn add(mut self, b: bool) -> Self {
        self.add = b;
        self
    }

    fn unmapped(mut self, name: Option<String>) -> Self {
        self.unmapped = name;
        self
    }
}
*/

/*

impl FromStr for TrackNames {
    type Err = String;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let s = s.trim();




        /*
        let trimmed = s.trim();

        let (start, end) = match Self::detect_delimiter(trimmed) {
            Some((delimiter, count)) if count > 1 => {
                return Err(format!(
                    "Too many '{}' delimiters in input: '{}'",
                    delimiter, s
                ));
            }
            Some((delimiter, _)) => Self::parse_with_delimiter(trimmed, delimiter)?,
            None => Self::parse_single_or_empty(trimmed)?,
        };
        */

        Ok(Self { start, end })
    }
}
*/

/*
pub(in crate::types) enum TrackNamesArg {
    AddNames,
    Names,
}

impl ClapArgID for TrackNames {
    type Arg = TrackNamesArg;

    fn as_str(arg: Self::Arg) -> &'static str {
        match arg {
            TrackNamesArg::AddNames => "add_names",
            TrackNamesArg::Names => "names",
        }
    }
}

impl clap::FromArgMatches for TrackNames {
    fn from_arg_matches(matches: &ArgMatches) -> Result<Self, Error> {
        let mut matches = matches.clone();
        Self::from_arg_matches_mut(&mut matches)
    }

    fn update_from_arg_matches(&mut self, matches: &ArgMatches) -> Result<(), Error> {
        let mut matches = matches.clone();
        self.update_from_arg_matches_mut(&mut matches)
    }

    fn from_arg_matches_mut(matches: &mut ArgMatches) -> Result<Self, Error> {
        let dir = match matches
        .try_remove_one::<PathBuf>(Self::as_str(InputArg::Dir))
        .map_err(|e| Error::raw(ErrorKind::InvalidValue, e.to_string()))?
        {
            Some(path) => path,
            None => Self::default_dir()
            .map_err(|e| Error::raw(ErrorKind::ValueValidation, e.to_string()))?,
        };

        /*
        let range = match matches
        .try_remove_one::<RangeU32>(Self::as_str(InputArg::Range))
        .map_err(|e| Error::raw(ErrorKind::ValueValidation, e.to_string()))?
        {
            Some(rng) => rng,
            None => Self::default_range(),
        };

        let up = match matches
        .try_remove_one::<u32>(Self::as_str(InputArg::Up))
        .map_err(|e| Error::raw(ErrorKind::ValueValidation, e.to_string()))?
        {
            Some(u) => u,
            None => Self::default_up(),
        };

        let check = match matches
        .try_remove_one::<u32>(Self::as_str(InputArg::Check))
        .map_err(|e| Error::raw(ErrorKind::ValueValidation, e.to_string()))?
        {
            Some(u) => u,
            None => Self::default_check(),
        };

        let skip = matches
        .try_remove_one::<GlobSet>(Self::as_str(InputArg::Skip))
        .map_err(|e| Error::raw(ErrorKind::ValueValidation, e.to_string()))?;

        Ok(Self {
            dir,
            range,
            up,
            check,
            skip,
        })
        */
    }

    fn update_from_arg_matches_mut(&mut self, matches: &mut ArgMatches) -> Result<(), Error> {
        *self = Self::from_arg_matches_mut(matches)?;
        Ok(())
    }
}
*/
